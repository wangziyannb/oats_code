# 双分支 AWQ：一次性量化与迭代内 Frobenius 选轮

本目录整理两套已经实际运行的方法。`src/` 可作为独立代码目录使用，
不依赖外层 my_wanda 仓库的 Python 模块。模型和大型检查点仍需另行提供。
`run.py` 是统一串行入口，默认跑 rank 32 后再跑 rank 128，不覆盖已有结果。
本次整理不重新执行完整模型实验。

## 1. 方法与文件

| 方法 | 核心代码 | 执行入口 |
|---|---|---|
| 迭代完成后，主干＋两个低秩因子一次性量化 | `src/scripts/awq_residue_allbranch_w4.py` | `run.py posthoc_allbranch` |
| 迭代内同时量化主干和两个低秩因子，Frobenius 选轮 | `src/lib/dual_awq.py` | `run.py inloop_frobenius` |

PyTorch 权重都按 `[out_features, in_features]` 保存：

```text
output = linear(X, S) + linear(linear(X, first), second)
S      = module.sp.weight
first  = module.lr.l1.weight  # 旧 post-hoc 脚本记为 A
second = module.lr.l2.weight  # 旧 post-hoc 脚本记为 B
Delta  = second @ first
```

辅助代码：

- `src/scripts/awq_residue_sparse_w4.py`：一次性版本复用的校准、缩放、掩码量化工具；
  统一入口不运行其中“仅量化主干”的 main。
- `src/scripts/eval_int4_weightonly_ppl_cmqa.py` 和 `src/main.py`：一次性版本使用的
  模型加载与复合层重建依赖；统一入口只测 PPL。
- `src/scripts/run_llama2_ppl_experiment.py`：FP16 基线生成、迭代内校准、评测、导出。
- `src/scripts/eval_posthoc_awq_ppl.py`：重载一次性量化检查点，严格检查后测 PPL。
- `src/lib/prune.py`：原始 Wanda 投影、SVD 和复合层实现。
- `third_party/llm-awq/`：固定版本官方 AWQ Python 源码与许可证，未包含编译内核。

这里不包含 `dual_awq_refit_second` 新方法，也不包含最早按输出 MSE 选轮的实验入口。
底层归档函数仍保留原有 output_mse 选项以保持源文件一致；统一入口显式锁定 Frobenius。

## 2. 一次性双分支量化

先完成原始 FP16 的 `lr_wanda_iter_alllinear`，再加载其 checkpoint：

```text
FP16 迭代剪枝 -> 固定 S、first、second
-> 低秩预平衡 / 外部输入尺度搜索
-> rank 通道等价缩放搜索（用整条量化分支输出评分）
-> clipping -> 量化 S、first、second -> 保存 -> 重载测 PPL
```

关键函数依次是 `prebalance_factors`、`search_external_allbranch_scale`、
`search_rank_gauge_scale`、`auto_clip_dense_layer` 和 `process_layer`。
外部缩放同时覆盖主干和 first；内部缩放成对作用于 first/second。
second 的 clipping 使用量化 first 产生的实际中间输入。
量化后不重新 SVD、不进行外层残差反馈，也没有 second 最小二乘重拟合。

使用旧脚本原有 PileVal 校准、20 点尺度搜索与 clipping；seed=42，
收集 128 段合格文本后拼接成本次实际 65×512 tokens。
主干 W4G128、first W4G128、**两个 rank 的 second 都为 W4G32**。
尺度会融合到相邻层/复合分支中，必须保存完整模型 state_dict。

## 3. 迭代内双分支量化，Frobenius 选轮

使用历史 Frobenius 实验的准确源代码快照，而不是后续重拟合版本：

```text
初始化 SVD 低秩因子，并量化两个因子
每轮：
    residual = W - second_q @ first_q
    S = Wanda_2:4(residual)
    S_q = AWQ_style_fake_quant(S)
    second, first = SVD_rank_r(W - S_q)
    first_q, second_q = search_pair(first, second, X, target)
    Delta_q = second_q @ first_q          # 反馈给下一轮
    error = ||W - S_q - Delta_q||_F / ||W||_F
保留 error 最小的一轮
```

`search_pair` 每轮重新统计量化 first 的中间激活，并按完整两因子输出 MSE
选择尺度。**尺度候选按输出 MSE 评分；最终选哪一轮按 Frobenius 误差评分。**
主干每轮量化，主干尺度每 10 轮刷新；低秩尺度每次 SVD 后刷新。
最多 200 轮、tol=1e-8、seed=0；C4 128×2048 校准，每个投影采 512 个激活 token；
20 点搜索，不使用 clipping。

历史配置请求 G128，并取 `min(128, in_features)`：主干/first 均 G128，
**second 在 rank 32 为 G32，在 rank 128 为 G128**。分组沿输入列，每个输出行独立。
两个 rank 均无尾组；不整除则报错，不补零。
归档版故意保留这一历史设置，因此没有后来添加的 `--second_group_size` 参数。

有效权重在原输入坐标中保存，逆尺度已折入因子；重载时不要再次缩放。
这两套都是 AWQ-style 假量化，保存的是反量化浮点权重，不是打包 INT4 推理内核。

## 4. 环境与运行命令

在本目录执行。已安装环境可直接 `conda activate wanda_final`。
新环境可按仓库环境创建，再补齐辅助依赖：

```bash
conda env create -f src/environment.yml -n wanda_final
conda activate wanda_final
python -m pip install -r requirements-extra.txt
```

`tested_versions.json` 记录本机实际包版本。官方 AWQ 版本为
`d6e797a42b9ef7778de8ee2352116e0f48a78d61`，代码已随包附带。
PPL-only 不需要运行 lm-eval/CMQA。模型目录需有完整 Llama2-7B HF 权重和 tokenizer；
校准与 WikiText-2 数据需能下载或命中已有缓存。

本机直接复用既有 FP16 检查点，运行一次性双分支量化：

```bash
python run.py posthoc_allbranch \
  --model /home/lzhang45/Llama-2-7b-hf \
  --fp16-root /home/lzhang45/my_wanda/out_ckpt/llama2_ppl \
  --ranks 32 128 --output-root ./runs_posthoc
```

在其他机器没有 FP16 检查点时，先生成；紧接着使用同一个 output-root：

```bash
python run.py prepare_fp16 --model /path/to/Llama-2-7b-hf --output-root ./runs
python run.py posthoc_allbranch --model /path/to/Llama-2-7b-hf --output-root ./runs
```

运行历史 Frobenius 双分支迭代：

```bash
python run.py inloop_frobenius \
  --model /home/lzhang45/Llama-2-7b-hf \
  --ranks 32 128 --output-root ./runs_inloop
```

给任意命令加 `--dry-run` 可查看完整底层参数而不加载模型。
`--gpu 0` 指定单张物理 GPU。输出包含日志、逐轮记录（迭代版）、指标、
配置和 `rebuildable_ckpt.pt`。同一用户同一 GPU 的包内入口有互斥锁；
外部另开的实验仍需自行避免并发。

## 5. 已有实测结果与对照限制

Llama2-7B、2:4、WikiText-2 raw test、PPL 长度 128、batch=1、FP16/SDPA 评测：

| 方法 | rank 32 PPL | rank 128 PPL | second 组宽 |
|---|---:|---:|---|
| 一次性：主干＋两个因子 | 30.9579 | 25.3256 | 32 / 32 |
| 迭代内双分支，Frobenius 选轮 | 29.0278 | 44.4270 | 32 / 128 |

除了量化时机，校准数据、clipping、尺度处理和 rank128 的 second 组宽也不同。
**不能把这张表解释成只改变“是否迭代内量化”的严格消融。**
`results/` 收录已有指标和配置/量化报告；大型模型、检查点和全部逐轮日志不放进代码包，
原始路径保存在结果文件中。本次整理没有新增 PPL 结果。

## 6. 溯源和检查

`source_origins.json` 记录来源，`SHA256SUMS.json` 覆盖包内文件。
Frobenius 的五个记录源文件与历史 manifest SHA256 一致。
post-hoc 算法源文件保持原样；共享加载辅助函数已核对 AST 一致。
唯一的打包适配是从附带的 `third_party/llm-awq/REVISION` 读取版本号，
避免没有 `.git` 时误记录外层仓库的版本，不改变量化计算。

可运行包内历史单元与小模型集成测试：

```bash
cd src
AWQ_REFERENCE=../third_party/llm-awq/awq/quantize/quantizer.py \
  python -m unittest discover -s tests -p 'test_dual_awq*.py' -v
```

模型及其他受限资源按各自许可使用。仓库 LICENSE 在 `src/LICENSE`；
官方 AWQ LICENSE 在 `third_party/llm-awq/LICENSE`。
