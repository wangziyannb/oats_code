import ast
import io
import os
from pathlib import Path
import unittest
from unittest.mock import patch

import torch
import torch.nn.functional as F

from lib.dual_awq import (AWQConfig, effective_group_size, fake_quant, fit_dual_awq,
                          output_mse, pair_output, quantize_linear,
                          quantize_pair_at_scales, search_pair)
from lib.prune import MyLinear, MyLowRankBranch, MySparseLinear


class DualAWQTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(13)
        self.cfg = AWQConfig(group_size=8, grid=5, row_chunk=7)
        self.x = torch.randn(23, 16) * torch.linspace(0.1, 4, 16)
        self.first = torch.randn(4, 16)
        self.second = torch.randn(12, 4)

    def test_official_quantizer_parity(self):
        path = Path(os.environ.get("AWQ_REFERENCE", "/home/lzhang45/references/llm-awq/quantizer.py"))
        if not path.exists():
            self.skipTest("Set AWQ_REFERENCE to the pinned official quantizer.py")
        tree = ast.parse(path.read_text())
        function = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                        and node.name == "pseudo_quantize_tensor")
        module = ast.Module(body=[function], type_ignores=[])
        scope = {"torch": torch}
        exec(compile(ast.fix_missing_locations(module), str(path), "exec"), scope)
        for width in (32, 128, 256):
            weight = torch.randn(17, width)
            group = min(width, 128)
            expected = scope["pseudo_quantize_tensor"](weight, n_bit=4, zero_point=True,
                                                        q_group_size=group)
            actual = fake_quant(weight, AWQConfig())
            torch.testing.assert_close(actual, expected, rtol=0, atol=0)

    def test_unquantized_shared_input_and_rank_scaling_are_equivalent(self):
        sparse = torch.randn(12, 16)
        d = torch.exp(torch.randn(16))
        h = torch.exp(torch.randn(4))
        original = F.linear(self.x, sparse) + pair_output(self.x, self.first, self.second)
        scaled = F.linear(self.x / d, sparse * d) + pair_output(
            self.x / d, self.first * d / h[:, None], self.second * h)
        torch.testing.assert_close(original, scaled)
        with patch("lib.dual_awq.fake_quant", side_effect=lambda w, *a, **k: w):
            q1, q2 = quantize_pair_at_scales(self.first, self.second, d, h, self.cfg)
            sp = quantize_linear(sparse, d, self.cfg)
        torch.testing.assert_close(original, F.linear(self.x, sp) + pair_output(self.x, q1, q2))

    def test_sparse_mask_survives_quantization_and_folding(self):
        weight = torch.randn(16, 128)
        weight.reshape(16, -1, 4)[:, :, :2] = 0
        weight[0, 2] = 1e-9
        result = quantize_linear(weight, torch.exp(torch.randn(128)), AWQConfig(), True)
        self.assertTrue(torch.equal(weight == 0, result == 0))
        self.assertTrue(((result == 0).reshape(16, -1, 4).sum(-1) == 2).all())
        self.assertTrue(torch.isfinite(result).all())

    def test_pair_uses_current_quantized_intermediate_and_output_loss(self):
        import lib.dual_awq as module
        target = pair_output(self.x, self.first, self.second) + torch.randn(23, 12)
        observed_inputs = []
        real_candidates = module.scale_candidates

        def capture(x, grid):
            observed_inputs.append(x.clone())
            return real_candidates(x, grid)

        with patch("lib.dual_awq.scale_candidates", side_effect=capture):
            q1, q2, scales, info = search_pair(self.first, self.second, self.x, target, self.cfg)
        self.assertEqual(len(observed_inputs), 2)
        torch.testing.assert_close(observed_inputs[0], self.x)
        pre_rank1, _ = quantize_pair_at_scales(self.first, self.second, scales["first_input"],
                                               torch.ones(4), self.cfg)
        torch.testing.assert_close(observed_inputs[1], F.linear(self.x, pre_rank1), rtol=0, atol=0)
        self.assertFalse(torch.equal(observed_inputs[1], F.linear(self.x, self.first)))
        self.assertAlmostEqual(info["pair_mse"], float(output_mse(pair_output(self.x, q1, q2), target)))
        self.assertLessEqual(info["pair_mse"], info["first_search_mse"])
        self.assertEqual(info["second_group_size"], 4)

    def test_feedback_uses_quantized_pair_and_quantized_sparse_target(self):
        wd = torch.randn(12, 16)
        mask = torch.zeros_like(wd, dtype=torch.bool)
        mask.reshape(12, -1, 4)[:, :, :2] = True
        metrics, svd_targets, pairs, sparse_weights = [], [], [], []

        def svd(weight, rank):
            svd_targets.append(weight.clone())
            return self.second.clone(), self.first.clone()

        def quant_pair(*args):
            multiplier = len(pairs) + 2
            first_q = self.first / multiplier
            second_q = self.second / multiplier
            pairs.append((first_q, second_q))
            return first_q, second_q, {}, {"pair_mse": float(multiplier)}

        def sparse_search(weight, *args):
            q = weight * 0.75
            sparse_weights.append(q)
            return q, torch.ones(16), {}

        def make_mask(metric, *args, **kwargs):
            metrics.append(metric.clone())
            return mask

        with patch("lib.prune._build_prune_mask", side_effect=make_mask), \
             patch("lib.dual_awq.search_pair", side_effect=quant_pair), \
             patch("lib.dual_awq.search_sparse", side_effect=sparse_search):
            fit_dual_awq(wd, torch.ones(1, 16), self.x, 4, 2, 0,
                         AWQConfig(group_size=8, sparse_refresh=1), svd=svd)
        self.assertEqual(len(pairs), 3)
        for i in range(2):
            first_q, second_q = pairs[i]
            torch.testing.assert_close(metrics[i], (wd - second_q @ first_q).abs())
            torch.testing.assert_close(svd_targets[i + 1], wd - sparse_weights[i])

    def test_effective_weights_roundtrip_requires_no_scale_reapplication(self):
        q1, q2, _, _ = search_pair(self.first, self.second, self.x,
                                   pair_output(self.x, self.first, self.second), self.cfg)
        sparse = torch.randn(12, 16)

        def build():
            return MyLinear(MySparseLinear.from_dense(sparse, use_semi_structured=False),
                            MyLowRankBranch.from_factors(q1, q2))

        original, restored = build(), build()
        buffer = io.BytesIO()
        torch.save(original.state_dict(), buffer)
        buffer.seek(0)
        restored.load_state_dict(torch.load(buffer, weights_only=True), strict=True)
        torch.testing.assert_close(original(self.x), restored(self.x), rtol=0, atol=0)
        self.assertEqual(effective_group_size(32, 128), 32)
        self.assertEqual(effective_group_size(128, 128), 128)
        with self.assertRaises(ValueError):
            effective_group_size(130, 128)

    def test_final_frobenius_selection_rejects_unobserved_weight_growth(self):
        # One calibration token cannot observe the other input directions.
        # The first candidate fits it perfectly but has a large spurious
        # weight. Pair scoring remains output-based; final selection is an
        # independent choice, and must not change the feedback trajectory.
        wd = torch.eye(4)
        x = torch.tensor([[1., 0., 0., 0.]])
        second = torch.tensor([[1.], [0.], [0.], [0.]])
        firsts = [torch.zeros(1, 4), torch.tensor([[1., 10., 0., 0.]]),
                  torch.tensor([[.5, 0., 0., 0.]])]
        runs = {}
        for criterion in ("output_mse", "frobenius"):
            calls, records = [], []

            def pair_search(first, second_arg, inputs, target, config):
                first_q = firsts[len(calls)].clone()
                calls.append(target.clone())
                loss = float(output_mse(pair_output(inputs, first_q, second), target))
                return first_q, second.clone(), {}, {"pair_mse": loss}

            def sparse_search(weight, *args):
                return torch.zeros_like(weight), torch.ones(4), {}

            with patch("lib.dual_awq.search_pair", side_effect=pair_search), \
                 patch("lib.dual_awq.search_sparse", side_effect=sparse_search):
                result = fit_dual_awq(
                    wd, torch.ones(1, 4), x, 1, 2, 0,
                    AWQConfig(group_size=4, sparse_refresh=1), report=records.append,
                    svd=lambda weight, rank: (second, firsts[0]), selection=criterion)
            runs[criterion] = result, records, calls
        by_output, by_frob = runs["output_mse"][0], runs["frobenius"][0]
        self.assertEqual(by_output["selected_iteration"], 1)
        self.assertEqual(by_frob["selected_iteration"], 2)
        self.assertLess(by_frob["rel_frob_err"], by_output["rel_frob_err"])
        self.assertGreater(by_frob["output_mse"], by_output["output_mse"])
        self.assertEqual(runs["output_mse"][1], runs["frobenius"][1])
        for left, right in zip(runs["output_mse"][2], runs["frobenius"][2]):
            torch.testing.assert_close(left, right, rtol=0, atol=0)


if __name__ == "__main__":
    unittest.main()
