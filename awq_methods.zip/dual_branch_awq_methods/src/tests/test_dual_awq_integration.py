"""GPU integration of calibration, seven projections, export and strict reload."""
import argparse
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import torch
from transformers import LlamaConfig, LlamaForCausalLM
from lib.prune import MyLinear
from scripts.run_llama2_ppl_experiment import audit_dual_model, load_base, prune_dual, reload_checkpoint


@unittest.skipUnless(torch.cuda.is_available(), "CUDA integration test")
class DualAWQIntegrationTest(unittest.TestCase):
    @torch.no_grad()
    def test_both_ranks_and_checkpoint_reload(self):
        torch.set_num_threads(2)
        for rank in (32, 128):
            with self.subTest(rank=rank), tempfile.TemporaryDirectory() as folder:
                torch.manual_seed(123)
                root = Path(folder)
                config = LlamaConfig(vocab_size=256, hidden_size=256, intermediate_size=512,
                    num_hidden_layers=1, num_attention_heads=4, num_key_value_heads=4,
                    max_position_embeddings=128, attention_dropout=0.0)
                # Load through the production path. Calling .half() on an already
                # constructed model also casts rotary buffers, unlike HF loading.
                fixture = LlamaForCausalLM(config)
                fixture.save_pretrained(root / "base")
                del fixture
                args = argparse.Namespace(model=str(root / "base"), device="cuda:0",
                    attn_implementation="sdpa", seqlen=32, nsamples=2, seed=0, w_bits=4,
                    group_size=128, scale_grid=3, sparse_scale_refresh=1, awq_tokens=16,
                    output=root, rank_k=rank, alt_iters=2, alt_tol=0,
                    dual_selection="frobenius")
                model = load_base(args)
                loader = [(torch.randint(0, 256, (1, 32)), None) for _ in range(2)]
                with patch("scripts.run_llama2_ppl_experiment.get_loaders", return_value=(loader, None)):
                    metadata = prune_dual(args, model, None)
                self.assertEqual(len(metadata["modules"]), 7)
                self.assertEqual(metadata["selection"], "relative_frobenius")
                self.assertEqual(metadata["pair_candidate_selection"], "full_branch_calibration_output_mse")
                self.assertTrue(all(item["iterate_selection"] == "frobenius"
                                    for item in metadata["modules"].values()))
                self.assertEqual(audit_dual_model(model, rank)["violations_2of4"], 0)
                for module in model.modules():
                    if isinstance(module, MyLinear):
                        self.assertEqual(module.lr.l1.weight.shape[0], rank)
                        self.assertTrue(torch.isfinite(module.sp.weight).all())
                        zeros = (module.sp.weight == 0).reshape(module.out_features, -1, 4).sum(-1)
                        self.assertTrue((zeros == 2).all())
                probe = loader[0][0].cuda()
                expected = model(probe).logits
                path = root / "checkpoint.pt"
                torch.save({"method": "dual_awq", "quantization": metadata,
                            "state_dict": {k: v.cpu() for k, v in model.state_dict().items()}}, path)
                del model
                restored = reload_checkpoint(args, path)
                torch.testing.assert_close(expected, restored(probe).logits, rtol=0, atol=0)
                del restored
                torch.cuda.empty_cache()


if __name__ == "__main__":
    unittest.main()
