import argparse
import os
import time
from datetime import datetime
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from importlib.metadata import version

from lib.prune import (
    prune_wanda,
    prune_magnitude,
    prune_sparsegpt,
    prune_ablate,
    prune_wanda_lowrank_alt_alllinear,
    prune_wanda_lowrank_alt_actsvd_alllinear,
    prune_wanda_lowrank_alt_fullx_actsvd_alllinear,
    prune_wanda_lowrank_alt_fullcov_actsvd_alllinear,
    prune_quad_lowrank_alt_fullx_actsvd_alllinear,
    prune_quad_lowrank_alt_fullcov_actsvd_alllinear,
    prune_wanda_svd_alllinear,
    check_sparsity,
    find_layers, finalize_fused_only,
)

from lib.eval import eval_ppl, eval_zero_shot, lm_simple_eval

print('torch', version('torch'))
print('transformers', version('transformers'))
print('accelerate', version('accelerate'))
print('# of gpus: ', torch.cuda.device_count())



import json
def _state_dict_to_cpu(state_dict: dict) -> dict:
    cpu_sd = {}
    for k, v in state_dict.items():
        cpu_sd[k] = v.detach().cpu() if torch.is_tensor(v) else v
    return cpu_sd

def save_rebuildable_checkpoint(save_dir: str, model, tokenizer, args) -> str:
    os.makedirs(save_dir, exist_ok=True)
    ckpt_path = os.path.join(save_dir, "rebuildable_ckpt.pt")

    ckpt = {
        "base_model": args.model,
        "prune_method": args.prune_method,
        "sparsity_type": args.sparsity_type,
        "sparsity_ratio": float(args.sparsity_ratio),
        "rank_k": int(getattr(args, "rank_k", 0)),
        "state_dict": _state_dict_to_cpu(model.state_dict()),
        "meta": vars(args),
    }

    torch.save(ckpt, ckpt_path)
    tokenizer.save_pretrained(save_dir)

    # 可选：再写一个 json，便于快速看信息
    with open(os.path.join(save_dir, "rebuildable_meta.json"), "w", encoding="utf-8") as f:
        json.dump({k: ckpt[k] for k in ["base_model","prune_method","sparsity_type","sparsity_ratio"]},
                  f, ensure_ascii=False, indent=2)

    print(f"[save] rebuildable checkpoint saved to: {ckpt_path}")
    return ckpt_path




def get_llm(model_name, cache_dir="llm_weights"):
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16,
        cache_dir=cache_dir,
        low_cpu_mem_usage=True,
        device_map="auto"
    )
    model.seqlen = 2048
    #model.seqlen = model.config.max_position_embeddings
    return model

import os
import torch
from transformers import AutoTokenizer, LlamaForCausalLM
from lib.prune import MyLinear, MyLowRankBranch, MySparseLinear
def replace_llama_linears(model, rank_k: int, sparsity_type: str, use_semi_structured: bool = True):
    """
    把 HF Llama 的 q/k/v/o + gate/up/down 的 nn.Linear 替换成 MyLinear(sp + lr)
    rank_k / sparsity_type 从 ckpt 里读，保证结构和 ckpt 对齐。
    """
    layers = model.model.layers
    for layer in layers:
        attn = layer.self_attn
        for name in ["q_proj", "k_proj", "v_proj", "o_proj"]:
            lin = getattr(attn, name)
            dtype = lin.weight.dtype
            device = lin.weight.device

            sp = MySparseLinear(
                lin.in_features, lin.out_features, bias=False,
                sparsity_type=sparsity_type,
                use_semi_structured=use_semi_structured,
                keep_dense_weight=True,
            ).to(device=device, dtype=dtype)

            lr = None
            if rank_k and rank_k > 0:
                lr = MyLowRankBranch(lin.in_features, lin.out_features, rank_k).to(device=device, dtype=dtype)

            setattr(attn, name, MyLinear(sp=sp, lr=lr, bias=None).to(device=device, dtype=dtype))

        mlp = layer.mlp
        for name in ["gate_proj", "up_proj", "down_proj"]:
            lin = getattr(mlp, name)
            dtype = lin.weight.dtype
            device = lin.weight.device

            sp = MySparseLinear(
                lin.in_features, lin.out_features, bias=False,
                sparsity_type=sparsity_type,
                use_semi_structured=use_semi_structured,
                keep_dense_weight=True,
            ).to(device=device, dtype=dtype)

            lr = None
            if rank_k and rank_k > 0:
                lr = MyLowRankBranch(lin.in_features, lin.out_features, rank_k).to(device=device, dtype=dtype)

            setattr(mlp, name, MyLinear(sp=sp, lr=lr, bias=None).to(device=device, dtype=dtype))

def load_model(name=None, device="cuda:0", checkpoint_path=None, cache_dir="llm_weights"):
    ckpt = None

    if checkpoint_path is not None:
        if os.path.isdir(checkpoint_path):
            checkpoint_path = os.path.join(checkpoint_path, "rebuildable_ckpt.pt")
        ckpt = torch.load(checkpoint_path, map_location="cpu")

        # 优先用 ckpt 里保存的 base_model
        if name is None:
            name = ckpt.get("base_model", None)

    if name is None:
        raise ValueError("`name` is None. Please provide --model or save base_model into ckpt.")

    # tokenizer 优先从 ckpt 目录读（因为你 save_ckpt 时也 save 了 tokenizer）
    tok_src = name
    if checkpoint_path is not None:
        ckpt_dir = os.path.dirname(checkpoint_path)
        if os.path.exists(os.path.join(ckpt_dir, "tokenizer_config.json")):
            tok_src = ckpt_dir

    tok = AutoTokenizer.from_pretrained(tok_src, use_fast=False)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token

    # 尽量和原 get_llm 行为一致
    try:
        model = AutoModelForCausalLM.from_pretrained(
            name,
            torch_dtype=torch.float16,
            cache_dir=cache_dir,
            low_cpu_mem_usage=True,
        )
    except Exception:
        model = AutoModelForCausalLM.from_pretrained(
            name,
            torch_dtype=torch.float16,
            cache_dir=cache_dir,
            low_cpu_mem_usage=True,
        )

    model.seqlen = 2048

    if ckpt is not None and "state_dict" in ckpt:
        sd = ckpt["state_dict"]
        rank_k = int(ckpt.get("rank_k", 0))
        sparsity_type = str(ckpt.get("sparsity_type", "2:4"))
        prune_method = ckpt.get("prune_method", "")

        print(f"[load] prune_method={prune_method}, rank_k={rank_k}, sparsity_type={sparsity_type}")

        if prune_method not in [
            "lr_wanda_iter_alllinear",
            "lr_wanda_iter_actsvd_alllinear",
            "lr_wanda_iter_fullx_actsvd_alllinear",
            "lr_wanda_iter_fullcov_actsvd_alllinear",
            "lr_quad_iter_fullx_actsvd_alllinear",
            "lr_quad_iter_fullcov_actsvd_alllinear",
            "wanda_svd_alllinear",
            "",
        ]:
            print(f"[warn] current replace_llama_linears may not match prune_method={prune_method}")

        # 1) 先替换结构，让模型里出现 .sp / .lr 参数
        replace_llama_linears(
            model,
            rank_k=rank_k,
            sparsity_type=sparsity_type,
            use_semi_structured=True,
        )

        # 2) 再加载权重
        load_ret = model.load_state_dict(sd, strict=False)
        if hasattr(load_ret, "missing_keys"):
            missing = load_ret.missing_keys
            unexpected = load_ret.unexpected_keys
        else:
            missing, unexpected = load_ret

        print(f"[load_state_dict] missing={len(missing)} unexpected={len(unexpected)}")
        if len(missing) > 0:
            print("[missing sample]", missing[:20])
        if len(unexpected) > 0:
            print("[unexpected sample]", unexpected[:20])

        # 3) 挪到 device
        model = model.to(device)
        model.eval()

        # 4) semi-structured packing（必须在 CUDA 上）
        total = 0
        packed = 0
        if "cuda" in str(device):
            for m in model.modules():
                if isinstance(m, MySparseLinear):
                    total += 1
                    # m.prepare()
                    if hasattr(m, "_weight_ss") and m._weight_ss is not None:
                        packed += 1

            torch.cuda.empty_cache()

        total_mylinear = sum(1 for m in model.modules() if isinstance(m, MyLinear))
        print(f"Packed MySparseLinear: {packed}/{total}")
        print(f"Total MyLinear: {total_mylinear}")
        return model, tok
    else:
        model = model.to(device)
        model.eval()
    return model, tok

def load_model_inject(name=None, device="cuda:0", checkpoint_path=None, cache_dir="llm_weights", injected_param_dict_path=None):
    ckpt = None

    if checkpoint_path is not None:
        if os.path.isdir(checkpoint_path):
            checkpoint_path = os.path.join(checkpoint_path, "rebuildable_ckpt.pt")
        ckpt = torch.load(checkpoint_path, map_location="cpu")

        # 优先用 ckpt 里保存的 base_model
        if name is None:
            name = ckpt.get("base_model", None)

    if name is None:
        raise ValueError("`name` is None. Please provide --model or save base_model into ckpt.")

    # tokenizer 优先从 ckpt 目录读（因为你 save_ckpt 时也 save 了 tokenizer）
    tok_src = name
    if checkpoint_path is not None:
        ckpt_dir = os.path.dirname(checkpoint_path)
        if os.path.exists(os.path.join(ckpt_dir, "tokenizer_config.json")):
            tok_src = ckpt_dir

    tok = AutoTokenizer.from_pretrained(tok_src, use_fast=False)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token

    # 尽量和原 get_llm 行为一致
    try:
        model = AutoModelForCausalLM.from_pretrained(
            name,
            torch_dtype=torch.float16,
            cache_dir=cache_dir,
            low_cpu_mem_usage=True,
        )
    except Exception:
        model = AutoModelForCausalLM.from_pretrained(
            name,
            torch_dtype=torch.float16,
            cache_dir=cache_dir,
            low_cpu_mem_usage=True,
        )

    model.seqlen = 2048

    inject_source = torch.load(injected_param_dict_path, map_location="cpu")

    if ckpt is not None and "state_dict" in ckpt:
        sd = ckpt["state_dict"]

        for k,v in inject_source.items():
            sd[k] = v
            # print()

        rank_k = int(ckpt.get("rank_k", 0))
        sparsity_type = str(ckpt.get("sparsity_type", "2:4"))
        prune_method = ckpt.get("prune_method", "")

        print(f"[load] prune_method={prune_method}, rank_k={rank_k}, sparsity_type={sparsity_type}")

        if prune_method not in [
            "lr_wanda_iter_alllinear",
            "lr_wanda_iter_actsvd_alllinear",
            "lr_wanda_iter_fullx_actsvd_alllinear",
            "lr_wanda_iter_fullcov_actsvd_alllinear",
            "lr_quad_iter_fullx_actsvd_alllinear",
            "lr_quad_iter_fullcov_actsvd_alllinear",
            "wanda_svd_alllinear",
            "",
        ]:
            print(f"[warn] current replace_llama_linears may not match prune_method={prune_method}")

        # 1) 先替换结构，让模型里出现 .sp / .lr 参数
        replace_llama_linears(
            model,
            rank_k=rank_k,
            sparsity_type=sparsity_type,
            use_semi_structured=True,
        )

        # 2) 再加载权重
        load_ret = model.load_state_dict(sd, strict=False)
        if hasattr(load_ret, "missing_keys"):
            missing = load_ret.missing_keys
            unexpected = load_ret.unexpected_keys
        else:
            missing, unexpected = load_ret

        print(f"[load_state_dict] missing={len(missing)} unexpected={len(unexpected)}")
        if len(missing) > 0:
            print("[missing sample]", missing[:20])
        if len(unexpected) > 0:
            print("[unexpected sample]", unexpected[:20])

        # 3) 挪到 device
        model = model.to(device)
        model.eval()

        # 4) semi-structured packing（必须在 CUDA 上）
        total = 0
        packed = 0
        if "cuda" in str(device):
            for m in model.modules():
                if isinstance(m, MySparseLinear):
                    total += 1
                    # m.prepare()
                    if hasattr(m, "_weight_ss") and m._weight_ss is not None:
                        packed += 1

            torch.cuda.empty_cache()

        total_mylinear = sum(1 for m in model.modules() if isinstance(m, MyLinear))
        print(f"Packed MySparseLinear: {packed}/{total}")
        print(f"Total MyLinear: {total_mylinear}")
        # finalize_fused_only(model)
        return model, tok

    model = model.to(device)
    model.eval()
    return model, tok

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, help='LLaMA model')
    parser.add_argument('--seed', type=int, default=0, help='Seed for sampling the calibration data.')
    parser.add_argument('--nsamples', type=int, default=128, help='Number of calibration samples.')
    parser.add_argument('--sparsity_ratio', type=float, default=0, help='Sparsity level')
    parser.add_argument("--sparsity_type", type=str, choices=["unstructured", "4:8", "2:4"])
    parser.add_argument(
        "--prune_method",
        type=str,
        choices=[
            "magnitude",
            "wanda",
            "sparsegpt",
            "lr_wanda_iter_alllinear",
            "lr_wanda_iter_actsvd_alllinear",
            "lr_wanda_iter_fullx_actsvd_alllinear",
            "lr_wanda_iter_fullcov_actsvd_alllinear",
            "lr_quad_iter_fullx_actsvd_alllinear",
            "lr_quad_iter_fullcov_actsvd_alllinear",
            "wanda_svd_alllinear",
            "ablate_mag_seq",
            "ablate_wanda_seq",
            "ablate_mag_iter",
            "ablate_wanda_iter",
            "search",
        ],
    )
    parser.add_argument("--cache_dir", default="llm_weights", type=str )
    parser.add_argument('--use_variant', action="store_true", help="whether to use the wanda variant described in the appendix")
    parser.add_argument('--save', type=str, default=None, help='Path to save results.')
    parser.add_argument('--save_model', type=str, default=None, help='Path to save the pruned model.')

    parser.add_argument("--eval_cmqa", action="store_true")
    parser.add_argument(
        "--skip_mmlu",
        action="store_true",
        help="When --eval_cmqa is set, skip the extra MMLU evaluation and run only the CMQA task suite.",
    )
    parser.add_argument("--eval_medqa", action="store_true")

    parser.add_argument(
        "--rank_k",
        type=int,
        default=128,
        help="Rank k for low-rank approximation",
    )
    parser.add_argument('--alt_iters', type=int, default=10, help='Max alternating iterations for low-rank Wanda pruning.')
    parser.add_argument('--alt_tol', type=float, default=1e-4, help='Early stop tolerance on relative Frobenius error (alternating).')
    parser.add_argument('--alt_rel_tol', type=float, default=0.0, help='Relative early stop tolerance on per-iteration improvement.')
    parser.add_argument('--alt_min_iters', type=int, default=2, help='Minimum alternating iterations before early stopping can trigger.')
    parser.add_argument('--alt_patience', type=int, default=1, help='Consecutive plateau iterations required before early stopping.')
    parser.add_argument('--full_actsvd_niter', type=int, default=2, help='Randomized subspace iterations for full-X/full-cov actSVD.')
    parser.add_argument('--full_actsvd_oversample', type=int, default=8, help='Oversampling dimension for full-X/full-cov actSVD.')
    parser.add_argument('--fullx_chunk_tokens', type=int, default=4096, help='Token chunk size when streaming raw X for full-X actSVD.')
    parser.add_argument('--quad_chunk_rows', type=int, default=128, help='Row chunk size for covariance-aware local 2:4 sparse solver.')
    parser.add_argument(
        '--fullx_store_dtype',
        type=str,
        default='float16',
        choices=['float16', 'bfloat16', 'float32'],
        help='CPU storage dtype for raw activation batches in full-X actSVD.',
    )
    parser.add_argument('--save_ckpt', type=str, default=None, help='Directory to save a rebuildable torch checkpoint (recommended for custom modules).')

    parser.add_argument('--load_ckpt', type=str, default=None,
                        help='Path to rebuildable_ckpt.pt or its directory')
    parser.add_argument('--injected_param_dict_path', type=str, default=None,
                        help='Path to another checkpoint where you want to inject param_dicts to the template ckpt in --load_ckpt.')
    args = parser.parse_args()

    # Setting seeds for reproducibility
    np.random.seed(args.seed)
    torch.random.manual_seed(args.seed)

    # Handling n:m sparsity
    prune_n, prune_m = 0, 0
    if args.sparsity_type != "unstructured":
        assert args.sparsity_ratio == 0.5, "sparsity ratio must be 0.5 for structured N:M sparsity"
        prune_n, prune_m = map(int, args.sparsity_type.split(":"))

    model_name = args.model.split("/")[-1]
    if args.load_ckpt is not None:
        ckpt_path = args.load_ckpt
        if os.path.isdir(ckpt_path):
            ckpt_path = os.path.join(ckpt_path, "rebuildable_ckpt.pt")
        ckpt_meta = torch.load(ckpt_path, map_location="cpu")
        if args.model is None:
            args.model = ckpt_meta.get("base_model", None)
        print(f"loading model from rebuildable ckpt: {ckpt_path}")

        if args.injected_param_dict_path is not None:
            model, tokenizer = load_model_inject(args.model, device="cuda:0", checkpoint_path=ckpt_path, injected_param_dict_path=args.injected_param_dict_path)
        else:
            model, tokenizer = load_model(args.model, device="cuda:0", checkpoint_path=ckpt_path)
    else:
        print(f"loading llm model {args.model}")
        model = get_llm(args.model, args.cache_dir)
        model.eval()
        tokenizer = AutoTokenizer.from_pretrained(args.model, use_fast=False)

    device = torch.device("cuda:0")
    if "30b" in args.model or "65b" in args.model: # for 30b and 65b we use device_map to load onto multiple A6000 GPUs, thus the processing here.
        device = model.hf_device_map["lm_head"]
    print("use device ", device)

    if args.load_ckpt is None:
        if args.sparsity_ratio != 0:
            print("pruning starts")
            prune_start = time.time()
            print(f"[timing] pruning_started_at {datetime.now().isoformat(timespec='seconds')}")
            if args.prune_method == "wanda":
                prune_wanda(args, model, tokenizer, device, prune_n=prune_n, prune_m=prune_m)
            elif args.prune_method == "magnitude":
                prune_magnitude(args, model, tokenizer, device, prune_n=prune_n, prune_m=prune_m)
            elif args.prune_method == "sparsegpt":
                prune_sparsegpt(args, model, tokenizer, device, prune_n=prune_n, prune_m=prune_m)
            elif args.prune_method == "lr_wanda_iter_alllinear":
                prune_wanda_lowrank_alt_alllinear(args, model, tokenizer, device,prune_n=prune_n, prune_m=prune_m)
            elif args.prune_method == "lr_wanda_iter_actsvd_alllinear":
                prune_wanda_lowrank_alt_actsvd_alllinear(args, model, tokenizer, device,prune_n=prune_n, prune_m=prune_m)
            elif args.prune_method == "lr_wanda_iter_fullx_actsvd_alllinear":
                prune_wanda_lowrank_alt_fullx_actsvd_alllinear(args, model, tokenizer, device, prune_n=prune_n, prune_m=prune_m)
            elif args.prune_method == "lr_wanda_iter_fullcov_actsvd_alllinear":
                prune_wanda_lowrank_alt_fullcov_actsvd_alllinear(args, model, tokenizer, device, prune_n=prune_n, prune_m=prune_m)
            elif args.prune_method == "lr_quad_iter_fullx_actsvd_alllinear":
                prune_quad_lowrank_alt_fullx_actsvd_alllinear(args, model, tokenizer, device, prune_n=prune_n, prune_m=prune_m)
            elif args.prune_method == "lr_quad_iter_fullcov_actsvd_alllinear":
                prune_quad_lowrank_alt_fullcov_actsvd_alllinear(args, model, tokenizer, device, prune_n=prune_n, prune_m=prune_m)
            elif args.prune_method == "wanda_svd_alllinear":
                prune_wanda_svd_alllinear(args, model, tokenizer, device,prune_n=prune_n, prune_m=prune_m)
            elif "ablate" in args.prune_method:
                prune_ablate(args, model, tokenizer, device, prune_n=prune_n, prune_m=prune_m)
            prune_seconds = time.time() - prune_start
            print(f"[timing] pruning_finished_at {datetime.now().isoformat(timespec='seconds')}")
            print(f"[timing] pruning_wall_seconds {prune_seconds:.2f}")

    ################################################################
    print("*"*30)
    sparsity_ratio = check_sparsity(model)
    print(f"sparsity sanity check {sparsity_ratio:.4f}")
    print("*"*30)
    ################################################################
    ppl_test = eval_ppl(args, model, tokenizer, device)
    print(f"wikitext perplexity {ppl_test}")

    if not os.path.exists(args.save):
        os.makedirs(args.save)
    save_filepath = os.path.join(args.save, f"log_{args.prune_method}.txt")

    with open(save_filepath, "w") as f:
        print("method\tactual_sparsity\tppl_test", file=f, flush=True)
        print(f"{args.prune_method}\t{sparsity_ratio:.4f}\t{ppl_test:.4f}", file=f, flush=True)

    if args.save_ckpt:
        save_rebuildable_checkpoint(args.save_ckpt, model, tokenizer, args)

    if args.save_model:
        model.save_pretrained(args.save_model)
        tokenizer.save_pretrained(args.save_model)
        #Torch.save(model,’model.bin’)

    if args.eval_cmqa:
        from addict import Dict
        cmqa_eval_options = {
            "output_path": args.save,
            "tasks": ["openbookqa", "arc_easy", "winogrande", "hellaswag", "arc_challenge", "piqa", "boolq"],
            "num_fewshot": [0],
            "max_length": 4096,
            "apply_chat_template": False,
            "fewshot_as_multiturn": False,
            "enable_thinking": False,
        }
        lm_simple_eval(Dict(cmqa_eval_options), model, tokenizer, "lm_eval_result")

        if not args.skip_mmlu:
            mmlu_eval_options = {
                "output_path": args.save,
                "tasks": ["mmlu"],
                "num_fewshot": [5],
                "max_length": 4096,
                "apply_chat_template": False,
                "fewshot_as_multiturn": False,
                "enable_thinking": False,
            }
            lm_simple_eval(Dict(mmlu_eval_options), model, tokenizer, "mmlu_eval_result")


if __name__ == '__main__':
    main()
