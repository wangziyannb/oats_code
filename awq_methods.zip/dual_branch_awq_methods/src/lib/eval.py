# Import necessary modules
import json
import logging
import time
import types
from pathlib import Path
from typing import List, Dict

import numpy as np
import torch
import torch.nn as nn

# Import get_loaders function from data module within the same directory
from .data import get_loaders 

from collections import defaultdict
import fnmatch

logger = logging.getLogger(__name__)

# Function to evaluate perplexity (ppl) on a specified model and tokenizer
def eval_ppl(args, model, tokenizer, device=torch.device("cuda:0")):
    # Set dataset
    dataset = "wikitext2"

    # Print status
    print(f"evaluating on {dataset}")

    # Get the test loader
    # _, testloader = get_loaders(
    #     dataset, seed=0, seqlen=model.seqlen, tokenizer=tokenizer
    # )
    ppl_seqlen = int(getattr(args, "ppl_seqlen", 128))
    _, testloader = get_loaders(
        dataset, seed=0, seqlen=ppl_seqlen, tokenizer=tokenizer
    )

    # Evaluate ppl in no grad context to avoid updating the model
    with torch.no_grad():
        ppl_test = eval_ppl_wikitext(
            model, testloader, 1, device, seqlen=ppl_seqlen
        )
    return ppl_test 

# Function to evaluate perplexity (ppl) specifically on the wikitext dataset
def eval_ppl_wikitext_train(model, trainloader, bs=1, device=None):
    # Get input IDs
    # testenc = testenc.input_ids

    # Calculate number of samples
    # nsamples = testenc.numel() // model.seqlen
    nsamples = len(trainloader)

    # List to store negative log likelihoods
    nlls = []
    print(f"nsamples {nsamples}")

    # Loop through each batch
    for i in range(0,nsamples,bs):
        if i % 50 == 0:
            print(f"sample {i}")

        # Calculate end index
        j = min(i+bs, nsamples)

        # Prepare inputs and move to device
        # inputs = testenc[:,(i * model.seqlen):(j * model.seqlen)].to(device)
        inputs = trainloader[i][0].to(device)
        inputs = inputs.reshape(j-i, model.seqlen)

        # Forward pass through the model
        lm_logits = model(inputs).logits

        # Shift logits and labels for next token prediction
        shift_logits = lm_logits[:, :-1, :].contiguous()
        shift_labels = inputs[:, 1:]

        # Compute loss
        loss_fct = nn.CrossEntropyLoss()
        loss = loss_fct(shift_logits.reshape(-1, shift_logits.size(-1)), shift_labels.reshape(-1))

        # Calculate negative log likelihood
        neg_log_likelihood = loss.float() * model.seqlen * (j-i)

        # Append to list of negative log likelihoods
        nlls.append(neg_log_likelihood)

    # Compute perplexity
    ppl = torch.exp(torch.stack(nlls).sum() / (nsamples * model.seqlen))

    # Empty CUDA cache to save memory
    torch.cuda.empty_cache()

    return ppl.item()

# Function to evaluate perplexity (ppl) specifically on the wikitext dataset
def eval_ppl_wikitext(model, testenc, bs=1, device=None, seqlen=128):
    # Get input IDs
    testenc = testenc.input_ids

    # Calculate number of samples
    #nsamples = testenc.numel() // model.seqlen
    seqlen = int(seqlen)
    nsamples = testenc.numel() // seqlen


    # List to store negative log likelihoods
    nlls = []
    print(f"nsamples {nsamples}")

    # Loop through each batch
    for i in range(0,nsamples,bs):
        if i % 50 == 0:
            print(f"sample {i}")

        # Calculate end index
        j = min(i+bs, nsamples)

        # Prepare inputs and move to device
        #inputs = testenc[:,(i * model.seqlen):(j * model.seqlen)].to(device)
        #inputs = inputs.reshape(j-i, model.seqlen)
        inputs = testenc[:,(i * seqlen):(j * seqlen)].to(device)
        inputs = inputs.reshape(j-i, seqlen)
        # Forward pass through the model
        lm_logits = model(inputs).logits

        # Shift logits and labels for next token prediction
        shift_logits = lm_logits[:, :-1, :].contiguous()
        shift_labels = inputs[:, 1:]

        # Compute loss
        loss_fct = nn.CrossEntropyLoss()
        loss = loss_fct(shift_logits.reshape(-1, shift_logits.size(-1)), shift_labels.reshape(-1))

        # Calculate negative log likelihood
        neg_log_likelihood = loss.float() * seqlen * (j-i)

        # Append to list of negative log likelihoods
        nlls.append(neg_log_likelihood)

    # Compute perplexity
    ppl = torch.exp(torch.stack(nlls).sum() / (nsamples * seqlen))

    # Empty CUDA cache to save memory
    torch.cuda.empty_cache()

    return ppl.item()


def eval_zero_shot(model_name, model, tokenizer, task_list=["boolq","rte","hellaswag","winogrande","arc_challenge","arc_easy","openbookqa"], 
        num_fewshot=0, use_accelerate=False, add_special_tokens=False):
    from lm_eval import tasks, evaluator 
    def pattern_match(patterns, source_list):
        task_names = set()
        for pattern in patterns:
            for matching in fnmatch.filter(source_list, pattern):
                task_names.add(matching)
        return list(task_names)
    task_names = pattern_match(task_list, tasks.ALL_TASKS)
    model_args = f"pretrained={model_name},cache_dir=./llm_weights"
    limit = None 
    if "70b" in model_name or "65b" in model_name:
        limit = 2000
    if use_accelerate:
        model_args = f"pretrained={model_name},cache_dir=./llm_weights,use_accelerate=True"
    results = evaluator.simple_evaluate(
        model="hf-causal-experimental",
        model_args=model_args,
        tasks=task_names,
        num_fewshot=num_fewshot,
        batch_size=None,
        device=None,
        no_cache=True,
        limit=limit,
        description_dict={},
        decontamination_ngrams_path=None,
        check_integrity=False,
        pretrained_model=model,
        tokenizer=tokenizer, 
        add_special_tokens=add_special_tokens
    )

    return results

def lm_simple_eval(lm_eval_options, model, tokenizer, result_name):
    import lm_eval
    from lm_eval import simple_evaluate
    if not isinstance(lm_eval_options.num_fewshot, list):
        lm_eval_options.num_fewshot = [lm_eval_options.num_fewshot]
    for num_fewshot in lm_eval_options.num_fewshot:
        wrapped_model = lm_eval.models.huggingface.HFLM(model, tokenizer=tokenizer,
                                                        # batch_size=lm_eval_options.batch_size if lm_eval_options.batch_size and quick else 'auto',
                                                        batch_size=getattr(lm_eval_options, "batch_size", "auto") or "auto",
                                                        max_length=lm_eval_options.max_length if lm_eval_options.max_length else None)

        # monkey patch for qwen3
        if 'Qwen3' in model.config.name_or_path:
            import jinja2
            def apply_chat_template(
                    self, chat_history: List[Dict[str, str]], add_generation_prompt: bool = True
            ) -> str:
                """
                Method to apply a chat template to a list of chat history between user and model.
                """
                try:
                    chat_templated = self.tokenizer.apply_chat_template(
                        chat_history,
                        tokenize=False,
                        add_generation_prompt=add_generation_prompt,
                        continue_final_message=not add_generation_prompt,
                        enable_thinking=lm_eval_options.enable_thinking if lm_eval_options.enable_thinking else False
                    )
                except jinja2.exceptions.TemplateError:
                    logger.warning(
                        "Failed to apply chat template. removing the system role in chat history."
                    )
                    chat_history = [msg for msg in chat_history if msg["role"] != "system"]
                    chat_templated = self.tokenizer.apply_chat_template(
                        chat_history,
                        tokenize=False,
                        add_generation_prompt=add_generation_prompt,
                        continue_final_message=not add_generation_prompt,
                        enable_thinking=lm_eval_options.enable_thinking if lm_eval_options.enable_thinking else False
                    )
                return chat_templated

            wrapped_model.apply_chat_template = types.MethodType(apply_chat_template,
                                                                 wrapped_model)

        results = lm_eval.simple_evaluate(  # call simple_evaluate
            model=wrapped_model,
            tasks=lm_eval_options.tasks,
            num_fewshot=num_fewshot if num_fewshot else None,
            log_samples=False,
            apply_chat_template=lm_eval_options.apply_chat_template if lm_eval_options.apply_chat_template else False,
            fewshot_as_multiturn=True,
        )

        def _handle_non_serializable(o):
            if isinstance(o, np.int64) or isinstance(o, np.int32):
                return int(o)
            elif isinstance(o, set):
                return list(o)
            else:
                return str(o)

        path = Path(lm_eval_options.output_path)
        # check if file or 'dir/results.json' exists
        if path.is_file():
            raise FileExistsError(f"File already exists at {path}")
        output_path_file = path.joinpath(f"{str(num_fewshot if num_fewshot else 'None')}_{result_name}.json")
        if path.suffix in (".json", ".jsonl"):
            output_path_file = path
            path.parent.mkdir(parents=True, exist_ok=True)
            path = path.parent
        else:
            path.mkdir(parents=True, exist_ok=True)
        dumped = json.dumps(
            results, indent=2, default=_handle_non_serializable, ensure_ascii=False
        )
        output_path_file.open("w", encoding="utf-8").write(dumped)
        logger.info(
            f"lm_eval complete. See report in {str(num_fewshot)}_{result_name}.json located in {lm_eval_options.output_path}")
