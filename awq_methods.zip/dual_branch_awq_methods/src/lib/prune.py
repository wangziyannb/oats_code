import time
import heapq
import sys
import warnings
import types
import contextvars
import gc
import csv
import os
import itertools
from contextlib import nullcontext
from typing import Dict, Optional, Tuple, List

import torch
import torch.nn as nn
import torch.nn.functional as F

from torch.sparse.semi_structured import (
    SparseSemiStructuredTensorCUTLASS,
    SparseSemiStructuredTensorCUSPARSELT,
)

from .sparsegpt import SparseGPT
from .layerwrapper import WrappedGPT
from .data import get_loaders
from .ablate import AblateGPT

# ---- optional custom kernels (ablation v1 does NOT require them) ----
try:
    sys.path.insert(0, "/mnt/my_wanda/fused_epilogue")
    import fused_epilogue as fe  # noqa: F401
    from fused_epilogue import fused_gu_epilogue  # noqa: F401
    from fused_epilogue import fused_qkv_epilogue  # noqa: F401
    from fused_epilogue import fused_add_epilogue  # noqa: F401
except Exception:
    fe = None
    fused_gu_epilogue = None
    fused_qkv_epilogue = None
    fused_add_epilogue = None

def find_layers(module, layers=[nn.Linear], name=''):
    """
    Recursively find the layers of a certain type in a module.

    Args:
        module (nn.Module): PyTorch module.
        layers (list): List of layer types to find.
        name (str): Name of the module.

    Returns:
        dict: Dictionary of layers of the given type(s) within the module.
    """
    #这里修改type(module)，方便兼容自己的自定义模块
    #if type(module) in layers:
    #    return {name: module}
    if isinstance(module, tuple(layers)):
        return {name: module}
    res = {}
    for name1, child in module.named_children():
        res.update(find_layers(
            child, layers=layers, name=name + '.' + name1 if name != '' else name1
        ))
    return res

# def check_sparsity(model):
#     use_cache = model.config.use_cache
#     model.config.use_cache = False
#
#     layers = model.model.layers
#     count = 0
#     total_params = 0
#     for i in range(len(layers)):
#         layer = layers[i]
#         subset = find_layers(layer)
#
#         sub_count = 0
#         sub_params = 0
#         for name in subset:
#             W = subset[name].weight.data
#             count += (W==0).sum().item()
#             total_params += W.numel()
#
#             sub_count += (W==0).sum().item()
#             sub_params += W.numel()
#
#         print(f"layer {i} sparsity {float(sub_count)/sub_params:.6f}")
#
#     model.config.use_cache = use_cache
#     return float(count)/total_params

def check_sparsity(model):
    use_cache = model.config.use_cache
    model.config.use_cache = False

    layers = model.model.layers
    count = 0
    total_params = 0

    for i in range(len(layers)):
        layer = layers[i]

        # If the layer has MyLinear, compute sparsity over the sparse branch only.
        mylinears = [m for m in layer.modules() if isinstance(m, MyLinear)]
        if len(mylinears) > 0:
            sub_count = 0
            sub_params = 0
            for m in mylinears:
                W = m.sp.weight.data
                sub_count += (W == 0).sum().item()
                sub_params += W.numel()

            # Aggregate
            count += sub_count
            total_params += sub_params
            print(f"layer {i} sparsity {float(sub_count)/sub_params:.6f}")
            continue

        # Fallback: old behavior (sum over all nn.Linear).
        subset = find_layers(layer)
        sub_count = 0
        sub_params = 0
        for name in subset:
            W = subset[name].weight.data
            sub_count += (W == 0).sum().item()
            sub_params += W.numel()
        count += sub_count
        total_params += sub_params
        print(f"layer {i} sparsity {float(sub_count)/sub_params:.6f}")

    model.config.use_cache = use_cache
    return float(count)/total_params


def prepare_calibration_input(model, dataloader, nsamples, seqlen):
    """
    Prepare inputs for model calibration.

    Args:
        model (nn.Module): The model to prepare inputs for.
        dataloader (DataLoader): DataLoader object to fetch input data.
        device (torch.device): Device on which the model is loaded.

    Returns:
        inps (torch.Tensor): Input tensor for calibration.
        outs (torch.Tensor): Output tensor for calibration.
        attention_mask (torch.Tensor): Attention mask tensor.
        position_ids (torch.Tensor): Position IDs tensor.
    """
    use_cache = model.config.use_cache
    model.config.use_cache = False
    try:
        layers = model.model.layers
    except AttributeError:
        try:
            layers = model.base_model.layers
        except AttributeError:
            layers = model.base_model.decoder.layers
    if "model.embed_tokens" in getattr(model, 'hf_device_map', {}):
        device = model.hf_device_map["model.embed_tokens"]
    else:
        device = model.device
    dtype = next(iter(model.parameters())).dtype
    # dtype = torch.float
    inps = torch.zeros((nsamples, seqlen, model.config.hidden_size), dtype=dtype, device=device)
    inps.requires_grad = False
    cache = {'i': 0, 'attention_mask': None, "position_ids": None, "cache_position": None, "position_embeddings": None}

    class Catcher(nn.Module):
        def __init__(self, module):
            super().__init__()
            self.module = module
            # Qwen3's model-level forward selects the causal mask from this
            # decoder-layer attribute before invoking the layer.  Preserve it
            # while the first layer is temporarily wrapped for calibration.
            if hasattr(module, "attention_type"):
                self.attention_type = module.attention_type
            if hasattr(module, "self_attn"):
                self.self_attn = module.self_attn
            elif hasattr(module, "attn"):
                self.attn = module.attn

        def forward(self, inp, **kwargs):
            inps[cache['i']] = inp
            cache['i'] += 1
            cache['attention_mask'] = kwargs['attention_mask']
            cache['position_ids'] = kwargs['position_ids']
            if 'cache_position' in kwargs and 'position_embeddings' in kwargs:
                cache['cache_position'] = kwargs['cache_position']
                cache['position_embeddings'] = kwargs['position_embeddings']
            raise ValueError

    layers[0] = Catcher(layers[0])
    for batch in dataloader:
        try:
            # model(torch.rand_like(batch[0].to(device)))
            model(batch[0].to(device))
        except ValueError:
            pass
    layers[0] = layers[0].module

    outs = torch.zeros_like(inps)
    attention_mask = cache['attention_mask']
    position_ids = cache['position_ids']
    model.config.use_cache = use_cache

    if 'cache_position' in cache and 'position_embeddings' in cache:
        cache_position = cache['cache_position']
        position_embeddings = cache['position_embeddings']
        return inps, outs, attention_mask, position_ids, cache_position, position_embeddings
    return inps, outs, attention_mask, position_ids


def return_given_alpha(alpha, sort_res, W_metric, tmp_metric, sum_before):
    thres_cumsum = sum_before * alpha
    sort_mask = tmp_metric <= thres_cumsum.reshape((-1,1))
    thres = torch.gather(sort_res[0], dim=1, index=sort_mask.sum(dim=1, keepdims=True)-1)
    W_mask = (W_metric <= thres)
    cur_sparsity = (W_mask==True).sum() / W_mask.numel()
    return W_mask, cur_sparsity

def prune_magnitude(args, model, tokenizer, device=torch.device("cuda:0"), prune_n=0, prune_m=0):
    layers = model.model.layers

    for i in range(len(layers)):
        layer = layers[i]
        subset = find_layers(layer)

        for name in subset:
            W = subset[name].weight.data
            W_metric = torch.abs(W)
            if prune_n != 0:
                W_mask = (torch.zeros_like(W)==1)
                for ii in range(W_metric.shape[1]):
                    if ii % prune_m == 0:
                        tmp = W_metric[:,ii:(ii+prune_m)].float()
                        W_mask.scatter_(1,ii+torch.topk(tmp, prune_n,dim=1, largest=False)[1], True)
            else:
                thresh = torch.sort(W_metric.flatten().cuda())[0][int(W.numel()*args.sparsity_ratio)].cpu()
                W_mask = (W_metric<=thresh)

            W[W_mask] = 0

def prune_wanda(args, model, tokenizer, device=torch.device("cuda:0"), prune_n=0, prune_m=0):
    use_cache = model.config.use_cache
    model.config.use_cache = False

    print("loading calibdation data")
    dataloader, _ = get_loaders("c4",nsamples=args.nsamples,seed=args.seed,seqlen=model.seqlen,tokenizer=tokenizer)
    print("dataset loading complete")
    with torch.no_grad():
        #inps, outs, attention_mask, position_ids = prepare_calibration_input(model, dataloader, device)
        returned_data = prepare_calibration_input(model, dataloader, args.nsamples, model.seqlen)
        inps, outs, attention_mask, position_ids = returned_data[:4]

    layers = model.model.layers
    for i in range(len(layers)):
        layer = layers[i]
        subset = find_layers(layer)

        if f"model.layers.{i}" in model.hf_device_map:   ## handle the case for llama-30B and llama-65B, when the device map has multiple GPUs;
            dev = model.hf_device_map[f"model.layers.{i}"]
            inps, outs, attention_mask, position_ids = inps.to(dev), outs.to(dev), attention_mask.to(dev), position_ids.to(dev)


        wrapped_layers = {}
        for name in subset:
            wrapped_layers[name] = WrappedGPT(subset[name])

        def add_batch(name):
            def tmp(_, inp, out):
                wrapped_layers[name].add_batch(inp[0].data, out.data)
            return tmp

        rotary_emb = model.model.rotary_emb
        handles = []
        for name in wrapped_layers:
            handles.append(subset[name].register_forward_hook(add_batch(name)))
        for j in range(args.nsamples):
            with torch.no_grad():
                #outs[j] = layer(inps[j].unsqueeze(0), attention_mask=attention_mask, position_ids=position_ids)[0]
                position_embeddings = rotary_emb(inps[j], position_ids)
                outs[j] = layer(
                    inps[j].unsqueeze(0),
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    position_embeddings=position_embeddings
                )[0]
        for h in handles:
            h.remove()

        for name in subset:
            print(f"pruning layer {i} name {name}")
            W_metric = torch.abs(subset[name].weight.data) * torch.sqrt(wrapped_layers[name].scaler_row.reshape((1,-1)))

            W_mask = (torch.zeros_like(W_metric) == 1)  ## initialize a mask to be all False
            if prune_n != 0:
                # structured n:m sparsity
                for ii in range(W_metric.shape[1]):
                    if ii % prune_m == 0:
                        tmp = W_metric[:,ii:(ii+prune_m)].float()
                        W_mask.scatter_(1,ii+torch.topk(tmp, prune_n,dim=1, largest=False)[1], True)
            else:
                sort_res = torch.sort(W_metric, dim=-1, stable=True)

                if args.use_variant:
                    # wanda variant
                    tmp_metric = torch.cumsum(sort_res[0], dim=1)
                    sum_before = W_metric.sum(dim=1)

                    alpha = 0.4
                    alpha_hist = [0., 0.8]
                    W_mask, cur_sparsity = return_given_alpha(alpha, sort_res, W_metric, tmp_metric, sum_before)
                    while (torch.abs(cur_sparsity - args.sparsity_ratio)>0.001) and (alpha_hist[1]-alpha_hist[0]>=0.001):
                        if cur_sparsity > args.sparsity_ratio:
                            alpha_new = (alpha + alpha_hist[0]) / 2.0
                            alpha_hist[1] = alpha
                        else:
                            alpha_new = (alpha + alpha_hist[1]) / 2.0
                            alpha_hist[0] = alpha

                        alpha = alpha_new
                        W_mask, cur_sparsity = return_given_alpha(alpha, sort_res, W_metric, tmp_metric, sum_before)
                    print(f"alpha found {alpha} sparsity {cur_sparsity:.6f}")
                else:
                    # unstructured pruning
                    indices = sort_res[1][:,:int(W_metric.shape[1]*args.sparsity_ratio)]
                    W_mask.scatter_(1, indices, True)

            subset[name].weight.data[W_mask] = 0  ## set weights to zero

        for j in range(args.nsamples):
            with torch.no_grad():
                #outs[j] = layer(inps[j].unsqueeze(0), attention_mask=attention_mask, position_ids=position_ids)[0]
                position_embeddings = rotary_emb(inps[j], position_ids)
                outs[j] = layer(
                    inps[j].unsqueeze(0),
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    position_embeddings=position_embeddings
                )[0]
        inps, outs = outs, inps

    model.config.use_cache = use_cache
    torch.cuda.empty_cache()


@torch.no_grad()
def prune_sparsegpt(args, model, tokenizer, dev, prune_n=0, prune_m=0):
    ## SparseGPT code available at: https://github.com/IST-DASLab/sparsegpt/tree/f5c25005a61f96a0933ca2f95705a963585aafaa
    print('Starting ...')
    dataloader, _ = get_loaders("c4",nsamples=args.nsamples,seed=args.seed,seqlen=model.seqlen,tokenizer=tokenizer)

    use_cache = model.config.use_cache
    model.config.use_cache = False
    layers = model.model.layers

    if "model.embed_tokens" in model.hf_device_map:
        dev = model.hf_device_map["model.embed_tokens"]

    dtype = next(iter(model.parameters())).dtype
    inps = torch.zeros(
        (args.nsamples, model.seqlen, model.config.hidden_size), dtype=dtype, device=dev
    )
    cache = {'i': 0, 'attention_mask': None, "position_ids": None}

    class Catcher(nn.Module):
        def __init__(self, module):
            super().__init__()
            self.module = module
        def forward(self, inp, **kwargs):
            inps[cache['i']] = inp
            cache['i'] += 1
            cache['attention_mask'] = kwargs['attention_mask']
            cache['position_ids'] = kwargs['position_ids']
            raise ValueError
    layers[0] = Catcher(layers[0])
    for batch in dataloader:
        try:
            model(batch[0].to(dev))
        except ValueError:
            pass
    layers[0] = layers[0].module
    torch.cuda.empty_cache()

    outs = torch.zeros_like(inps)
    attention_mask = cache['attention_mask']
    position_ids = cache['position_ids']

    print('Ready.')

    for i in range(len(layers)):
        layer = layers[i]
        if f"model.layers.{i}" in model.hf_device_map:
            dev = model.hf_device_map[f"model.layers.{i}"]
            print(f"layer {i} device {dev}")
            inps, outs, attention_mask, position_ids = inps.to(dev), outs.to(dev), attention_mask.to(dev), position_ids.to(dev)

        subset = find_layers(layer)

        gpts = {}
        for name in subset:
            gpts[name] = SparseGPT(subset[name])

        def add_batch(name):
            def tmp(_, inp, out):
                gpts[name].add_batch(inp[0].data, out.data)
            return tmp

        handles = []
        for name in gpts:
            handles.append(subset[name].register_forward_hook(add_batch(name)))

        for j in range(args.nsamples):
            outs[j] = layer(inps[j].unsqueeze(0), attention_mask=attention_mask, position_ids=position_ids)[0]
        for h in handles:
            h.remove()

        for name in gpts:
            print(i, name)
            print('Pruning ...')

            gpts[name].fasterprune(args.sparsity_ratio, prune_n=prune_n, prune_m=prune_m, percdamp=0.01, blocksize=128)
            gpts[name].free()

        for j in range(args.nsamples):
            outs[j] = layer(inps[j].unsqueeze(0), attention_mask=attention_mask, position_ids=position_ids)[0]

        layers[i] = layer
        torch.cuda.empty_cache()

        inps, outs = outs, inps

    model.config.use_cache = use_cache
    torch.cuda.empty_cache()



@torch.no_grad()
def prune_ablate(args, model, tokenizer, dev, prune_n=0, prune_m=0):
    ## SparseGPT code available at: https://github.com/IST-DASLab/sparsegpt/tree/f5c25005a61f96a0933ca2f95705a963585aafaa
    print('Starting ...')
    dataloader, _ = get_loaders("c4",nsamples=args.nsamples,seed=args.seed,seqlen=model.seqlen,tokenizer=tokenizer)

    use_cache = model.config.use_cache
    model.config.use_cache = False
    layers = model.model.layers

    if "model.embed_tokens" in model.hf_device_map:
        dev = model.hf_device_map["model.embed_tokens"]

    dtype = next(iter(model.parameters())).dtype
    inps = torch.zeros(
        (args.nsamples, model.seqlen, model.config.hidden_size), dtype=dtype, device=dev
    )
    cache = {'i': 0, 'attention_mask': None, "position_ids": None}

    class Catcher(nn.Module):
        def __init__(self, module):
            super().__init__()
            self.module = module
        def forward(self, inp, **kwargs):
            inps[cache['i']] = inp
            cache['i'] += 1
            cache['attention_mask'] = kwargs['attention_mask']
            cache['position_ids'] = kwargs['position_ids']
            raise ValueError
    layers[0] = Catcher(layers[0])
    for batch in dataloader:
        try:
            model(batch[0].to(dev))
        except ValueError:
            pass
    layers[0] = layers[0].module
    torch.cuda.empty_cache()

    outs = torch.zeros_like(inps)
    attention_mask = cache['attention_mask']
    position_ids = cache['position_ids']

    print('Ready.')

    for i in range(len(layers)):
        layer = layers[i]
        if f"model.layers.{i}" in model.hf_device_map:
            dev = model.hf_device_map[f"model.layers.{i}"]
            print(f"layer {i} device {dev}")
            inps, outs, attention_mask, position_ids = inps.to(dev), outs.to(dev), attention_mask.to(dev), position_ids.to(dev)

        subset = find_layers(layer)

        gpts = {}
        for name in subset:
            gpts[name] = AblateGPT(subset[name])

        def add_batch(name):
            def tmp(_, inp, out):
                gpts[name].add_batch(inp[0].data, out.data)
            return tmp

        handles = []
        for name in gpts:
            handles.append(subset[name].register_forward_hook(add_batch(name)))

        for j in range(args.nsamples):
            outs[j] = layer(inps[j].unsqueeze(0), attention_mask=attention_mask, position_ids=position_ids)[0]
        for h in handles:
            h.remove()

        for name in gpts:
            print(i, name)
            print('Pruning ...')

            if args.prune_method == "ablate_wanda_seq":
                prune_mask = gpts[name].get_wanda_mask(args.sparsity_ratio, prune_n, prune_m)
            elif args.prune_method == "ablate_mag_seq":
                prune_mask = gpts[name].get_mag_mask(args.sparsity_ratio, prune_n, prune_m)
            elif "iter" in args.prune_method:
                prune_mask = None

            gpts[name].fasterprune(args, args.sparsity_ratio, mask=prune_mask, prune_n=prune_n, prune_m=prune_m, percdamp=0.01, blocksize=128)
            gpts[name].free()

        for j in range(args.nsamples):
            outs[j] = layer(inps[j].unsqueeze(0), attention_mask=attention_mask, position_ids=position_ids)[0]

        layers[i] = layer
        torch.cuda.empty_cache()

        inps, outs = outs, inps

    model.config.use_cache = use_cache
    torch.cuda.empty_cache()




def _set_submodule(root: nn.Module, name: str, module: nn.Module) -> None:
    """用自定义的module模块 替换原模型的 root.name层"""
    parts = name.split(".")
    parent = root
    #访问路径上除最后一个元素， 其实目的就是拿到父路径
    for p in parts[:-1]:
        parent = getattr(parent, p)
    setattr(parent, parts[-1], module)


def _build_prune_mask(W_metric, sparsity_ratio, prune_n=0, prune_m=0, chunk_rows=512):
    """
    Return boolean mask (True means prune -> set to 0).
    Memory-safe for N:M by chunking rows to avoid huge topk indices.
    """
    if prune_n != 0:
        out_features, in_features = W_metric.shape
        assert in_features % prune_m == 0
        n_groups = in_features // prune_m

        mask = torch.empty((out_features, in_features), device=W_metric.device, dtype=torch.bool)

        for rs in range(0, out_features, chunk_rows):
            re = min(out_features, rs + chunk_rows)

            # view, no big alloc
            g = W_metric[rs:re].reshape(re - rs, n_groups, prune_m)

            idx = torch.topk(g, k=prune_n, dim=-1, largest=False).indices

            mg = torch.zeros_like(g, dtype=torch.bool)
            mg.scatter_(-1, idx, True)

            mask[rs:re] = mg.reshape(re - rs, in_features)

            # help allocator
            del idx, mg

        return mask

    # unstructured branch (keep your original)
    sort_res = torch.sort(W_metric, dim=-1, stable=True)
    k = int(W_metric.shape[1] * sparsity_ratio)
    k = max(0, min(k, W_metric.shape[1]))
    indices = sort_res.indices[:, :k]
    mask = torch.zeros_like(W_metric, dtype=torch.bool)
    mask.scatter_(1, indices, True)
    return mask


def _build_quad_nm_prune_mask(
        R: torch.Tensor,
        input_cov: torch.Tensor,
        prune_n: int,
        prune_m: int,
        *,
        chunk_rows: int = 128,
) -> torch.Tensor:
    """Local covariance-aware N:M mask.

    For each row and each N:M input block, choose the N pruned positions that
    minimize e_g^T C_g e_g, where e_g contains the residual weights removed from
    that block and C_g is the corresponding activation second-moment block.
    """
    if R.dim() != 2:
        raise ValueError("quad N:M pruning expects a 2D matrix")
    if int(prune_n) <= 0:
        raise ValueError("quad N:M pruning requires structured prune_n > 0")
    if int(prune_m) <= 0 or int(prune_n) > int(prune_m):
        raise ValueError(f"invalid N:M pattern prune_n={prune_n}, prune_m={prune_m}")
    if int(prune_n) != 2 or int(prune_m) != 4:
        raise NotImplementedError("quad local solver is currently implemented for 2:4 sparsity")

    out_features, in_features = R.shape
    if in_features % prune_m != 0:
        raise ValueError(f"in_features={in_features} must be divisible by prune_m={prune_m}")

    C = input_cov.to(device=R.device, dtype=torch.float32)
    if C.shape != (in_features, in_features):
        raise ValueError(f"input_cov shape={tuple(C.shape)}, expected {(in_features, in_features)}")

    n_groups = in_features // prune_m
    group_idx = torch.arange(in_features, device=R.device).reshape(n_groups, prune_m)
    C_blocks = C[group_idx.unsqueeze(2), group_idx.unsqueeze(1)]
    C_blocks = 0.5 * (C_blocks + C_blocks.transpose(-1, -2))

    patterns = []
    for cols in itertools.combinations(range(prune_m), prune_n):
        p = torch.zeros((prune_m,), device=R.device, dtype=torch.float32)
        p[list(cols)] = 1.0
        patterns.append(p)
    pattern_float = torch.stack(patterns, dim=0)
    pattern_bool = pattern_float.to(dtype=torch.bool)

    mask = torch.empty((out_features, in_features), device=R.device, dtype=torch.bool)
    R_float = R.float()
    chunk_rows = max(1, int(chunk_rows))

    for rs in range(0, out_features, chunk_rows):
        re = min(out_features, rs + chunk_rows)
        Rg = R_float[rs:re].reshape(re - rs, n_groups, prune_m)
        removed = Rg.unsqueeze(2) * pattern_float.reshape(1, 1, -1, prune_m)
        scores = torch.einsum("rgpm,gmn,rgpn->rgp", removed, C_blocks, removed)
        best = torch.argmin(scores, dim=-1)
        mask[rs:re] = pattern_bool[best].reshape(re - rs, in_features)
        del Rg, removed, scores, best

    return mask


def _rank_k_svd_factors(
        M: torch.Tensor,
        rank_k: int,
        niter: int = 8,
        backend: str = "lowrank",
) -> Tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
    """Compute rank-k factors for M (out_features x in_features).

    Returns (B, A) such that  M ≈ B @ A,
      - B: (out_features, k)
      - A: (k, in_features)

    The factors are returned in the same dtype/device as M.
    """
    if M.dim() != 2:
        raise ValueError("SVD expects a 2D matrix")
    k = int(rank_k)
    if k <= 0:
        return None, None

    m, n = M.shape
    k = min(k, m, n)

    orig_dtype = M.dtype
    M_work = M
    if orig_dtype in (torch.float16, torch.bfloat16):
        M_work = M.float()

    try:
        # svd_lowrank is much faster than full SVD.
        if str(backend) == "linalg":
            U, S, Vh = torch.linalg.svd(M_work, full_matrices=False)
            U = U[:, :k]
            S = S[:k]
            Vh = Vh[:k, :]
            B = (U * S.unsqueeze(0))
            A = Vh
        else:
            U, S, V = torch.svd_lowrank(M_work, q=k, niter=niter)
            # U: (m,k), S: (k,), V: (n,k)
            B = (U * S.unsqueeze(0))
            A = V.transpose(0, 1)
    except Exception:
        # fallback
        U, S, Vh = torch.linalg.svd(M_work, full_matrices=False)
        U = U[:, :k]
        S = S[:k]
        Vh = Vh[:k, :]
        B = (U * S.unsqueeze(0))
        A = Vh

    return B.to(orig_dtype), A.to(orig_dtype)


def _rank_k_act_svd_factors(
        M: torch.Tensor,
        scaler_row: torch.Tensor,
        rank_k: int,
        niter: int = 8,
        eps: float = 1e-12,
) -> Tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
    """Activation-aware rank-k factors using Wanda's diagonal activation stats.

    This approximates min ||(M - B @ A) @ X||_F by replacing X X^T with the
    diagonal activation second moment stored in scaler_row. Equivalently, SVD is
    applied to M * sqrt(diag(scaler_row)), then the right factor is unscaled.
    """
    if M.dim() != 2:
        raise ValueError("SVD expects a 2D matrix")
    k = int(rank_k)
    if k <= 0:
        return None, None

    m, n = M.shape
    k = min(k, m, n)
    orig_dtype = M.dtype

    scale = torch.sqrt(scaler_row.reshape(-1).to(device=M.device, dtype=torch.float32))
    if scale.numel() != n:
        raise ValueError(f"scaler_row has {scale.numel()} columns, expected {n}")

    active = scale > eps
    if not bool(active.any()):
        return _rank_k_svd_factors(M, rank_k, niter=niter)

    M_scaled = M.float() * scale.reshape(1, -1)

    try:
        U, S, V = torch.svd_lowrank(M_scaled, q=k, niter=niter)
        B = U * S.unsqueeze(0)
        A_scaled = V.transpose(0, 1)
    except Exception:
        U, S, Vh = torch.linalg.svd(M_scaled, full_matrices=False)
        U = U[:, :k]
        S = S[:k]
        Vh = Vh[:k, :]
        B = U * S.unsqueeze(0)
        A_scaled = Vh

    safe_scale = torch.where(active, scale, torch.ones_like(scale))
    A = A_scaled / safe_scale.reshape(1, -1)
    A[:, ~active] = 0
    return B.to(orig_dtype), A.to(orig_dtype)


def _fullx_store_dtype_from_name(name: str) -> torch.dtype:
    name = str(name).lower()
    if name in ("fp32", "float32"):
        return torch.float32
    if name in ("bf16", "bfloat16"):
        return torch.bfloat16
    if name in ("fp16", "float16", "half"):
        return torch.float16
    raise ValueError(f"Unsupported --fullx_store_dtype={name!r}")


def _flatten_linear_input(inp: torch.Tensor) -> Tuple[torch.Tensor, int]:
    """Return linear input as [tokens, in_features] plus original batch size."""
    if inp.dim() == 2:
        batch_size = 1
        return inp.reshape(-1, inp.shape[-1]), batch_size
    if inp.dim() == 3:
        batch_size = inp.shape[0]
        return inp.reshape(-1, inp.shape[-1]), batch_size
    raise ValueError(f"Expected a 2D/3D linear input tensor, got shape={tuple(inp.shape)}")


class _ActivationStats:
    """Wanda diagonal stats plus optional full-X / full-cov activation data."""

    def __init__(
            self,
            layer: nn.Linear,
            *,
            collect_cov: bool = False,
            collect_x: bool = False,
            x_store_dtype: torch.dtype = torch.float16,
    ):
        self.layer = layer
        self.dev = layer.weight.device
        self.columns = int(layer.weight.data.shape[1])
        self.scaler_row = torch.zeros((self.columns), device=self.dev, dtype=torch.float32)
        self.input_cov = (
            torch.zeros((self.columns, self.columns), device=self.dev, dtype=torch.float32)
            if collect_cov
            else None
        )
        self.input_batches: Optional[List[torch.Tensor]] = [] if collect_x else None
        self.x_store_dtype = x_store_dtype
        self.nsamples = 0

    def add_batch(self, inp: torch.Tensor, out: torch.Tensor) -> None:
        del out
        x, batch_size = _flatten_linear_input(inp)
        x_float = x.to(device=self.dev, dtype=torch.float32)

        old = self.nsamples
        new = old + int(batch_size)
        if new <= 0:
            return

        if old > 0:
            ratio = old / new
            self.scaler_row.mul_(ratio)
            if self.input_cov is not None:
                self.input_cov.mul_(ratio)

        self.scaler_row.add_(x_float.pow(2).sum(dim=0) / new)
        if self.input_cov is not None:
            self.input_cov.addmm_(x_float.transpose(0, 1), x_float, beta=1.0, alpha=1.0 / new)
        if self.input_batches is not None:
            self.input_batches.append(x.detach().to(device="cpu", dtype=self.x_store_dtype, copy=True))

        self.nsamples = new

    def free(self) -> None:
        self.input_cov = None
        if self.input_batches is not None:
            self.input_batches.clear()
        self.input_batches = None


def _top_eigenvectors_psd_operator(
        matvec,
        dim: int,
        rank_k: int,
        *,
        device: torch.device,
        niter: int = 2,
        oversample: int = 8,
) -> torch.Tensor:
    """Randomized top eigenspace for a symmetric positive semidefinite operator."""
    k = min(int(rank_k), int(dim))
    if k <= 0:
        return torch.empty((dim, 0), device=device, dtype=torch.float32)

    q = min(dim, max(k, k + int(oversample)))
    omega = torch.randn((dim, q), device=device, dtype=torch.float32)
    Y = matvec(omega)
    Q, _ = torch.linalg.qr(Y, mode="reduced")

    for _ in range(max(0, int(niter))):
        Y = matvec(Q)
        Q, _ = torch.linalg.qr(Y, mode="reduced")

    small = Q.transpose(0, 1) @ matvec(Q)
    small = 0.5 * (small + small.transpose(0, 1))
    evals, evecs = torch.linalg.eigh(small)
    idx = torch.argsort(evals, descending=True)[:k]
    U = Q @ evecs[:, idx]
    U, _ = torch.linalg.qr(U, mode="reduced")
    return U[:, :k]


def _rank_k_projected_factors_from_output_eigenspace(
        M: torch.Tensor,
        U: torch.Tensor,
) -> Tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
    if U.numel() == 0:
        return None, None
    orig_dtype = M.dtype
    M_float = M.float()
    B = U.to(device=M.device, dtype=torch.float32)
    A = B.transpose(0, 1) @ M_float
    return B.to(orig_dtype), A.to(orig_dtype)


def _rank_k_fullcov_act_svd_factors(
        M: torch.Tensor,
        input_cov: torch.Tensor,
        rank_k: int,
        niter: int = 2,
        oversample: int = 8,
        eps: float = 1e-12,
) -> Tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
    """Rank-k factors minimizing ||(M - B @ A) X||_F from full C = X X^T."""
    if M.dim() != 2:
        raise ValueError("SVD expects a 2D matrix")
    k = int(rank_k)
    if k <= 0:
        return None, None

    m, n = M.shape
    k = min(k, m, n)
    C = input_cov.to(device=M.device, dtype=torch.float32)
    if C.shape != (n, n):
        raise ValueError(f"input_cov shape={tuple(C.shape)}, expected {(n, n)}")
    if float(torch.diagonal(C).sum().item()) <= eps:
        return _rank_k_svd_factors(M, rank_k, niter=max(1, int(niter)))

    M_float = M.float()

    def matvec(V: torch.Tensor) -> torch.Tensor:
        return M_float @ (C @ (M_float.transpose(0, 1) @ V))

    U = _top_eigenvectors_psd_operator(
        matvec,
        m,
        k,
        device=M.device,
        niter=niter,
        oversample=oversample,
    )
    return _rank_k_projected_factors_from_output_eigenspace(M, U)


def _rank_k_fullx_act_svd_factors(
        M: torch.Tensor,
        input_batches: List[torch.Tensor],
        rank_k: int,
        niter: int = 2,
        oversample: int = 8,
        chunk_tokens: int = 4096,
) -> Tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
    """Rank-k factors minimizing ||(M - B @ A) X||_F by streaming raw X batches."""
    if M.dim() != 2:
        raise ValueError("SVD expects a 2D matrix")
    k = int(rank_k)
    if k <= 0:
        return None, None
    if input_batches is None or len(input_batches) == 0:
        return _rank_k_svd_factors(M, rank_k, niter=max(1, int(niter)))

    m, n = M.shape
    k = min(k, m, n)
    M_float = M.float()
    chunk_tokens = max(1, int(chunk_tokens))

    def matvec(V: torch.Tensor) -> torch.Tensor:
        MTV = M_float.transpose(0, 1) @ V
        out = torch.zeros((m, V.shape[1]), device=M.device, dtype=torch.float32)
        for X_cpu in input_batches:
            X = X_cpu.to(device=M.device, dtype=torch.float32, non_blocking=True)
            for start in range(0, X.shape[0], chunk_tokens):
                X_chunk = X[start:start + chunk_tokens]
                Z = X_chunk @ MTV
                out.add_(M_float @ (X_chunk.transpose(0, 1) @ Z))
            del X
        return out

    U = _top_eigenvectors_psd_operator(
        matvec,
        m,
        k,
        device=M.device,
        niter=niter,
        oversample=oversample,
    )
    return _rank_k_projected_factors_from_output_eigenspace(M, U)


def _cov_weighted_norm(M: torch.Tensor, input_cov: torch.Tensor) -> torch.Tensor:
    M_float = M.float()
    C = input_cov.to(device=M.device, dtype=torch.float32)
    value = ((M_float @ C) * M_float).sum()
    return torch.sqrt(torch.clamp(value, min=0.0))


def _fullx_output_norm(M: torch.Tensor, input_batches: List[torch.Tensor], chunk_tokens: int = 4096) -> torch.Tensor:
    M_float = M.float()
    total = torch.zeros((), device=M.device, dtype=torch.float32)
    chunk_tokens = max(1, int(chunk_tokens))
    for X_cpu in input_batches:
        X = X_cpu.to(device=M.device, dtype=torch.float32, non_blocking=True)
        for start in range(0, X.shape[0], chunk_tokens):
            X_chunk = X[start:start + chunk_tokens]
            Y = X_chunk @ M_float.transpose(0, 1)
            total.add_(Y.pow(2).sum())
        del X
    return torch.sqrt(torch.clamp(total, min=0.0))


def _alt_early_stop_update(
        *,
        iteration: int,
        prev_err_value: float,
        err_value: float,
        stale_iters: int,
        args,
) -> Tuple[float, bool, int, str]:
    improvement = prev_err_value - err_value
    alt_tol = max(float(getattr(args, "alt_tol", 0.0)), 0.0)
    alt_rel_tol = max(float(getattr(args, "alt_rel_tol", 0.0)), 0.0)
    alt_min_iters = max(int(getattr(args, "alt_min_iters", 2)), 1)
    alt_patience = max(int(getattr(args, "alt_patience", 1)), 1)

    threshold = alt_tol
    reason = ""
    if alt_rel_tol > 0:
        rel_threshold = alt_rel_tol * max(abs(prev_err_value), 1e-12)
        if rel_threshold > threshold:
            threshold = rel_threshold
            reason = "rel_tol"
    if reason == "":
        reason = "abs_tol"

    plateau = iteration >= alt_min_iters and improvement <= threshold
    stale_iters = stale_iters + 1 if plateau else 0
    stopped = stale_iters >= alt_patience
    if stopped and improvement <= 0:
        reason = "nonpositive_improvement"
    return improvement, stopped, stale_iters, reason if stopped else ""


def _quantile(values: List[float], q: float) -> float:
    if len(values) == 0:
        return float("nan")
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    pos = (len(ordered) - 1) * q
    lo = int(pos)
    hi = min(lo + 1, len(ordered) - 1)
    weight = pos - lo
    return ordered[lo] * (1.0 - weight) + ordered[hi] * weight


def _write_alt_convergence_outputs(records: List[Dict], args) -> None:
    """Persist aggregate convergence data and a rebuttal-ready plot."""
    if len(records) == 0:
        print("[alt] no convergence records collected; skipping convergence outputs.")
        return

    save_dir = getattr(args, "save", None)
    if save_dir is None:
        print("[alt] args.save is None; skipping convergence outputs.")
        return

    os.makedirs(save_dir, exist_ok=True)
    history_path = os.path.join(save_dir, "alt_convergence_history.csv")
    summary_path = os.path.join(save_dir, "alt_convergence_summary.csv")
    png_path = os.path.join(save_dir, "alt_convergence.png")
    pdf_path = os.path.join(save_dir, "alt_convergence.pdf")

    history_fields = [
        "layer",
        "module",
        "iter",
        "rel_frob_err",
        "improvement",
        "stopped",
        "stop_iter",
        "rank_k",
        "alt_tol",
        "alt_rel_tol",
        "alt_min_iters",
        "alt_patience",
        "stop_reason",
        "act_aware_svd",
        "act_svd_kind",
        "sparse_step_kind",
    ]
    with open(history_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=history_fields)
        writer.writeheader()
        for rec in records:
            writer.writerow({field: rec.get(field, "") for field in history_fields})

    err_by_iter: Dict[int, List[float]] = {}
    module_meta: Dict[Tuple[int, str], Dict] = {}
    for rec in records:
        iteration = int(rec["iter"])
        err_by_iter.setdefault(iteration, []).append(float(rec["rel_frob_err"]))
        key = (int(rec["layer"]), str(rec["module"]))
        meta = module_meta.setdefault(
            key,
            {
                "stop_iter": int(rec.get("stop_iter", iteration)),
                "early_stopped": False,
            },
        )
        meta["stop_iter"] = int(rec.get("stop_iter", meta["stop_iter"]))
        meta["early_stopped"] = bool(meta["early_stopped"] or rec.get("stopped", False))

    stop_counts: Dict[int, int] = {}
    early_stop_counts: Dict[int, int] = {}
    max_iter_reached_counts: Dict[int, int] = {}
    for meta in module_meta.values():
        stop_iter = int(meta["stop_iter"])
        stop_counts[stop_iter] = stop_counts.get(stop_iter, 0) + 1
        if meta["early_stopped"]:
            early_stop_counts[stop_iter] = early_stop_counts.get(stop_iter, 0) + 1
        else:
            max_iter_reached_counts[stop_iter] = max_iter_reached_counts.get(stop_iter, 0) + 1

    max_summary_iter = max(max(err_by_iter), max(stop_counts))
    summary_rows = []
    for iteration in range(1, max_summary_iter + 1):
        vals = err_by_iter.get(iteration, [])
        if vals:
            mean_err = sum(vals) / len(vals)
            median_err = _quantile(vals, 0.5)
            q1_err = _quantile(vals, 0.25)
            q3_err = _quantile(vals, 0.75)
        else:
            mean_err = median_err = q1_err = q3_err = ""

        summary_rows.append(
            {
                "iter": iteration,
                "mean_rel_frob_err": mean_err,
                "median_rel_frob_err": median_err,
                "q1_rel_frob_err": q1_err,
                "q3_rel_frob_err": q3_err,
                "num_modules_with_error": len(vals),
                "stop_iter_count": stop_counts.get(iteration, 0),
                "early_stop_count": early_stop_counts.get(iteration, 0),
                "max_iter_reached_count": max_iter_reached_counts.get(iteration, 0),
            }
        )

    summary_fields = [
        "iter",
        "mean_rel_frob_err",
        "median_rel_frob_err",
        "q1_rel_frob_err",
        "q3_rel_frob_err",
        "num_modules_with_error",
        "stop_iter_count",
        "early_stop_count",
        "max_iter_reached_count",
    ]
    with open(summary_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=summary_fields)
        writer.writeheader()
        writer.writerows(summary_rows)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        plot_rows = [row for row in summary_rows if row["num_modules_with_error"] > 0]
        plot_iters = [row["iter"] for row in plot_rows]
        mean_errs = [row["mean_rel_frob_err"] for row in plot_rows]
        median_errs = [row["median_rel_frob_err"] for row in plot_rows]
        q1_errs = [row["q1_rel_frob_err"] for row in plot_rows]
        q3_errs = [row["q3_rel_frob_err"] for row in plot_rows]

        fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.2), constrained_layout=True)

        axes[0].plot(plot_iters, median_errs, label="Median", color="#1f77b4", linewidth=2.2)
        axes[0].fill_between(plot_iters, q1_errs, q3_errs, color="#1f77b4", alpha=0.18, label="IQR")
        axes[0].plot(plot_iters, mean_errs, label="Mean", color="#d62728", linewidth=1.8, linestyle="--")
        axes[0].set_xlabel("Alternating iteration")
        axes[0].set_ylabel("Relative Frobenius error")
        axes[0].set_title("Convergence of alternating optimization")
        axes[0].grid(True, alpha=0.25)
        axes[0].legend(frameon=False)

        stop_iters = sorted(stop_counts)
        stop_values = [stop_counts[it] for it in stop_iters]
        axes[1].bar(stop_iters, stop_values, color="#4c78a8", width=0.85)
        axes[1].set_xlabel("Stop/final iteration")
        axes[1].set_ylabel("# Linear modules")
        axes[1].set_title("Iterations needed before stopping")
        axes[1].grid(True, axis="y", alpha=0.25)

        fig.savefig(png_path, dpi=300)
        fig.savefig(pdf_path)
        plt.close(fig)
        print(f"[alt] convergence plot saved to: {png_path}")
        print(f"[alt] convergence plot saved to: {pdf_path}")
    except Exception as e:
        print(f"[alt] failed to create convergence plot: {type(e).__name__}: {e}")

    print(f"[alt] convergence history saved to: {history_path}")
    print(f"[alt] convergence summary saved to: {summary_path}")



class MySparseLinear(nn.Module):
    """Sparse branch for structured (e.g. 2:4) sparse GEMM.

    Notes:
    - If CUDA + 2:4 is available, we try to pack the weight via
      torch.sparse.to_sparse_semi_structured, which routes matmul to cuSPARSELt.
    - If packing fails or running on CPU, we fall back to dense F.linear.
    """

    def __init__(
            self,
            in_features: int,
            out_features: int,
            bias: bool = False,
            *,
            sparsity_type: str = "2:4",
            use_semi_structured: bool = True,
            keep_dense_weight: bool = True,
    ):
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.sparsity_type = str(sparsity_type)
        self.use_semi_structured = bool(use_semi_structured)
        self.keep_dense_weight = bool(keep_dense_weight)

        self.weight = nn.Parameter(torch.empty(self.out_features, self.in_features))
        self.bias = None #强制设为None
        self._weight_ss = None  # cached packed weight (SparseSemiStructuredTensor)

    def drop_dense(self) -> None:
        # 释放 dense weight，节省显存（只要你不需要 fallback）
        if self.weight is not None:
            try:
                self.register_parameter("weight", None)
            except Exception:
                self.weight = None

    @classmethod
    def from_dense(
            cls,
            W_sp: torch.Tensor,
            *,
            sparsity_type: str = "2:4",
            use_semi_structured: bool = True,
            keep_dense_weight: bool = True,
    ) -> "MySparseLinear":
        out_features, in_features = W_sp.shape
        mod = cls(
            in_features=in_features,
            out_features=out_features,
            sparsity_type=sparsity_type,
            use_semi_structured=use_semi_structured,
            keep_dense_weight=keep_dense_weight,
        )
        mod.to(device=W_sp.device, dtype=W_sp.dtype)
        mod.weight.data.copy_(W_sp)
        mod.prepare()
        if not keep_dense_weight:
            mod.drop_dense()
        return mod


    def prepare(self) -> None:
        if self._weight_ss is not None:
            return  # 已经 pack 过就别重复 pack（除非你有特殊需求）

        if not self.use_semi_structured:
            return
        if (self.weight is None) or (not self.weight.is_cuda) or (self.weight.dim() != 2):
            return
        if self.sparsity_type not in ("2:4", "4:8"):
            return

        try:
            # print(type(self.weight))
            # print(self.weight.dtype)
            self._weight_ss = torch.sparse.to_sparse_semi_structured(self.weight)
            # print(type(self._weight_ss))
            # print(self._weight_ss.dtype) bfloat16
            # print(self._weight_ss.__class__.__name__) CUTLASS
            #self._weight_ss = SparseSemiStructuredTensorCUSPARSELT.from_dense(self.weight)
            #self._weight_ss = SparseSemiStructuredTensorCUTLASS.from_dense(self.weight)
        except Exception as e:
            warnings.warn(
                f"[MySparseLinear] to_sparse_semi_structured failed; fallback dense. "
                f"{type(e).__name__}: {e}"
            )
            self._weight_ss = None


    def forward(self, x: torch.Tensor) -> torch.Tensor:
        w = self._weight_ss if self._weight_ss is not None else self.weight
        # 大模型输入通常是 [B, S, H]，但考虑到semi_sparsity所以safe起见展平为 2D 做矩阵乘法
        orig_shape = x.shape
        x2 = x.reshape(-1, x.shape[-1])
        y2 = F.linear(x2, w, bias=None)
        y = y2.reshape(*orig_shape[:-1], self.out_features)
        # print("[qkv_sp] x.shape", x.shape, "x.stride", x.stride())
        # print("[qkv_sp] x2.shape", x2.shape, "x2.stride", x2.stride(), "contig", x2.is_contiguous())
        # print("[qkv_sp] y2.shape", y2.shape, "y2.stride", y2.stride(), "contig", y2.is_contiguous())
        # print("[qkv_sp] y.shape", y.shape, "y.stride", y.stride(), "contig", y.is_contiguous())
        return y




class MyLowRankBranch(nn.Module):
    """Low-rank residual branch: L2(L1(x))."""
    PROFILE = False
    def __init__(self, in_features: int, out_features: int, rank: int):
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.rank = int(rank)
        if self.rank <= 0:
            self.l1 = None
            self.l2 = None
        else:
            self.l1 = nn.Linear(self.in_features, self.rank, bias=False)
            self.l2 = nn.Linear(self.rank, self.out_features, bias=False)

    @classmethod
    def from_factors(cls, A: torch.Tensor, B: torch.Tensor) -> "MyLowRankBranch":
        """Create from factors (B, A) where DeltaW = B @ A."""

        rank, in_features = A.shape
        out_features, rank2 = B.shape
        if rank2 != rank:
            raise ValueError(f"Factor rank mismatch: A is ({rank},{in_features}), B is ({out_features},{rank2})")

        mod = cls(in_features=in_features, out_features=out_features, rank=rank)
        mod.to(device=B.device, dtype=B.dtype)
        assert mod.l1 is not None and mod.l2 is not None
        mod.l1.weight.data.copy_(A)
        mod.l2.weight.data.copy_(B)
        return mod

    # def forward(self, x: torch.Tensor) -> torch.Tensor:
    #     if self.rank <= 0 or self.l1 is None or self.l2 is None:
    #         # return zeros with correct shape
    #         return x.new_zeros(*x.shape[:-1], self.out_features)
    #     return self.l2(self.l1(x))
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        rf = torch.profiler.record_function if MyLowRankBranch.PROFILE else nullcontext

        with rf("MyLR::down"):
            h = self.l1(x)
        with rf("MyLR::up"):
            y = self.l2(h)
        return y



class MyLinear(nn.Module):
    """Final replacement layer: sparse branch + low-rank branch (+ optional bias)."""
    PROFILE = False
    def __init__(
            self,
            sp: MySparseLinear,
            lr: Optional[MyLowRankBranch] = None,
            *,
            bias: Optional[torch.Tensor] = None,
    ):
        super().__init__()
        self.sp = sp
        self.lr = lr
        self.in_features = sp.in_features
        self.out_features = sp.out_features
        if bias is None:
            self.bias = None
        else:
            self.bias = nn.Parameter(bias.clone().detach())

    # @property
    # def weight(self):
    #     # Dense-equivalent weight (read-only view)
    #     W = self.sp.weight
    #     if self.lr is not None and self.lr.rank > 0:
    #         W = W + (self.lr.l2.weight @ self.lr.l1.weight)
    #     return W

    # def forward(self, x: torch.Tensor) -> torch.Tensor:
    #     y = self.sp(x)
    #     if self.lr is not None:
    #         y = y + self.lr(x)
    #     if self.bias is not None:
    #         y = y + self.bias
    #     return y
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        rf = torch.profiler.record_function if MyLinear.PROFILE else nullcontext

        with rf("MyLinear::sp"):
            y = self.sp(x)

        if self.lr is not None:
            with rf("MyLinear::lr"):
                y = y + self.lr(x)

        if self.bias is not None:
            y = y + self.bias
        return y



class MyLowRankGroup(nn.Module):
    PROFILE = False

    def __init__(self, in_features: int, out_features: int, rank: int, groups: int, *,
                 device: torch.device, dtype: torch.dtype):
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.rank = int(rank)
        self.groups = int(groups)

        self.l1_cat = nn.Parameter(torch.empty(self.groups * self.rank, self.in_features, device=device, dtype=dtype))  # [G*r, in]
        self.l2_stack = nn.Parameter(torch.empty(self.groups, self.out_features, self.rank, device=device, dtype=dtype)) # [G, out, r]
        self.register_buffer("l2_stack_T", torch.empty(0, device=device, dtype=dtype), persistent=False)                # [G, r, out]

    @classmethod
    def from_branches(cls, branches: List[MyLowRankBranch]) -> "MyLowRankGroup":
        if len(branches) == 0:
            raise ValueError("from_branches expects non-empty branches")

        b0 = branches[0]
        if b0.l1 is None or b0.l2 is None or b0.rank <= 0:
            raise ValueError("branches[0] has no low-rank weights")

        rank = b0.l1.out_features
        in_features = b0.l1.in_features
        out_features = b0.l2.out_features

        for b in branches:
            if b.l1 is None or b.l2 is None or b.rank <= 0:
                raise ValueError("All branches must have valid low-rank weights")
            if b.l1.in_features != in_features or b.l1.out_features != rank or b.l2.out_features != out_features:
                raise ValueError("Grouped low-rank requires same in/out/rank for all branches")

        device = b0.l1.weight.device
        dtype = b0.l1.weight.dtype
        mod = cls(in_features, out_features, rank, len(branches), device=device, dtype=dtype)

        with torch.no_grad():
            mod.l1_cat.copy_(torch.cat([b.l1.weight for b in branches], dim=0))     # [G*r, in]
            mod.l2_stack.copy_(torch.stack([b.l2.weight for b in branches], dim=0)) # [G, out, r]
            mod.prepare()
        return mod

    @torch.no_grad()
    def prepare(self) -> None:
        self.l2_stack_T = self.l2_stack.transpose(1, 2).contiguous()  # [G, r, out]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        rf = torch.profiler.record_function if MyLowRankGroup.PROFILE else nullcontext
        if x.dim() != 3:
            raise ValueError(f"MyLowRankGroup expects [B,S,H], got {tuple(x.shape)}")
        B, S, H = x.shape
        if H != self.in_features:
            raise ValueError(f"in_features mismatch: x[-1]={H} vs {self.in_features}")

        BS = B * S
        with rf("MyLRGroup::down"):
            x2 = x.reshape(BS, H)
            mid = F.linear(x2, self.l1_cat)                         # [BS, G*r]
            mid = mid.view(BS, self.groups, self.rank)              # [BS, G, r]
            mid = mid.transpose(0, 1).contiguous()                  # [G, BS, r]

        with rf("MyLRGroup::up"):
            Bt = self.l2_stack_T if self.l2_stack_T.numel() else self.l2_stack.transpose(1, 2)
            out = torch.bmm(mid, Bt)                                # [G, BS, out]
            out = out.view(self.groups, B, S, self.out_features)    # [G, B, S, out]
        return out

    def forward_down(self, x: torch.Tensor) -> torch.Tensor:
        # 返回 rank 中间态: [G, B, S, r] (G=2 for GU)
        if x.dim() != 3:
            raise ValueError(f"MyLowRankGroup expects [B,S,H], got {tuple(x.shape)}")
        B, S, H = x.shape
        if H != self.in_features:
            raise ValueError(f"in_features mismatch: x[-1]={H} vs {self.in_features}")

        BS = B * S
        x2 = x.reshape(BS, H)
        mid = F.linear(x2, self.l1_cat)            # [BS, G*r]
        mid = mid.view(BS, self.groups, self.rank) # [BS, G, r]
        mid = mid.transpose(0, 1).contiguous()     # [G, BS, r]
        return mid.view(self.groups, B, S, self.rank).contiguous()



# ----------------------------
# Fused mode switch (keep name)
# ----------------------------
_FUSED_MODE: bool = True

def set_fused_mode(enabled: bool = True) -> None:
    global _FUSED_MODE
    _FUSED_MODE = bool(enabled)

def get_fused_mode() -> bool:
    return _FUSED_MODE



_CTX_QKV: contextvars.ContextVar[Optional[Tuple[torch.Tensor, ...]]] = contextvars.ContextVar("qkv_fused", default=None)


# ----------------------------
# one global LR stream (overlap with current stream)
# ----------------------------
_LR_STREAM = None
def _get_lr_stream():
    global _LR_STREAM
    if _LR_STREAM is None:
        _LR_STREAM = torch.cuda.Stream()
    return _LR_STREAM


# ----------------------------
# helpers
# ----------------------------
def _get_llama_layers(model: nn.Module):
    if hasattr(model, "model") and hasattr(model.model, "layers"):
        return model.model.layers
    if hasattr(model, "base_model") and hasattr(model.base_model, "layers"):
        return model.base_model.layers
    if hasattr(model, "base_model") and hasattr(model.base_model, "decoder") and hasattr(model.base_model.decoder, "layers"):
        return model.base_model.decoder.layers
    if hasattr(model, "layers"):
        return model.layers
    raise RuntimeError("Cannot find transformer layers.")

def _unwrap_mylinear(m):
    cur = m
    for _ in range(8):
        if isinstance(cur, MyLinear):
            return cur
        if hasattr(cur, "base"):
            cur = cur.base
        else:
            break
    return None

def _dense_weight(sp) -> torch.Tensor:
    if not hasattr(sp, "weight") or sp.weight is None or sp.weight.numel() == 0:
        raise RuntimeError("sp.weight missing/empty; cannot fuse")
    return sp.weight


# ============================================================
# Wrappers
# ============================================================
class _NoFallback(nn.Module):
    def __init__(self, name: str):
        super().__init__()
        self.name = name
    def forward(self, *args, **kwargs):
        raise RuntimeError(f"[NoFallback] {self.name} should NOT be called in fused-only mode.")


class _QKVProjFused(nn.Module):
    """q/k/v: fused-only wrapper, return qkv[g] from ctx; NO base, NO fallback."""
    def __init__(self, *, out_features: int, group_index: int):
        super().__init__()
        self.group_index = int(group_index)
        self.out_features = int(out_features)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if not get_fused_mode():
            raise RuntimeError("[FusedOnly] fused_mode=False but q/k/v are fused-only wrappers.")
        qkv = _CTX_QKV.get()
        if qkv is None:
            raise RuntimeError("[FusedOnly] _CTX_QKV miss. Patch forward not working?")
        return qkv[self.group_index]  # [B,S,H]

class _AddProjFused(nn.Module):
    """
    For o_proj / down_proj (fused-only):
      - lr(x) 在 lr_stream 上计算
      - sp(x) 在当前 stream 上计算
      - 当前 stream 等待 lr_stream
      - fused_add_epilogue(sp_out, lr_out) 合并 (+ bias)
    NO fallback.
    """
    def __init__(self, base: MyLinear, name: str):
        super().__init__()
        self.base = base
        self.name = name
        self.in_features = base.in_features
        self.out_features = base.out_features

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if not get_fused_mode():
            raise RuntimeError(f"[FusedOnly] fused_mode=False but {self.name} is fused-only.")
        if self.base.lr is None:
            raise RuntimeError(f"[FusedOnly] {self.name}: base.lr is None (expected low-rank branch).")
        if not callable(fused_add_epilogue):
            raise RuntimeError("fused_add_epilogue not available")
        if not x.is_cuda:
            raise RuntimeError(f"[FusedOnly] {self.name}: CUDA required for stream overlap.")

        cur_stream = torch.cuda.current_stream()
        lr_stream  = _get_lr_stream()

        # 1) lr 分支丢到 lr_stream（先建立依赖：lr_stream 等待当前流到达此处）
        lr_stream.wait_stream(cur_stream)
        with torch.cuda.stream(lr_stream):
            lr_out = self.base.lr(x)   # [B,S,out]

        # 2) sp 分支留在当前流
        sp_out = self.base.sp(x)       # [B,S,out]

        # 3) 当前流等待 lr_stream 完成
        cur_stream.wait_stream(lr_stream)

        # 关键：告诉 allocator 这个 tensor 会在 cur_stream 上被使用，避免跨流复用导致隐蔽错误
        lr_out.record_stream(cur_stream)

        # 4) epilogue add（在当前流）
        y = fused_add_epilogue(sp_out, lr_out)
        if self.base.bias is not None:
            y = y + self.base.bias
        return y






# ============================================================
# Patch attention.forward (QKV fusion + qkv_epilogue + stream overlap)
# ============================================================
def _patch_attention_forward(attn: nn.Module):
    tag = "_orig_forward_ablation_qkv_epi_stream_nofallback"
    if hasattr(attn, tag):
        return

    orig_forward = attn.forward
    setattr(attn, tag, orig_forward)

    def patched_forward(self, hidden_states, *args, **kwargs):
        if not get_fused_mode():
            raise RuntimeError("[FusedOnly] fused_mode=False but attention patched fused-only.")
        if (not hasattr(self, "qkv_sp")) or (not hasattr(self, "low_rank_qkv")):
            raise RuntimeError("[FusedOnly] attention missing qkv_sp/low_rank_qkv.")
        if not hidden_states.is_cuda:
            raise RuntimeError("[FusedOnly] CUDA required for stream-overlap.")
        if not callable(fused_qkv_epilogue):
            raise RuntimeError("fused_qkv_epilogue not available")

        cur_stream = torch.cuda.current_stream()
        lr_stream  = _get_lr_stream()

        # 1) lr 分支放到 lr_stream
        lr_stream.wait_stream(cur_stream)
        with torch.cuda.stream(lr_stream):
            lr = self.low_rank_qkv(hidden_states)      # [3,B,S,H]

        # 2) sp 分支留在当前 stream
        sp_mid = self.qkv_sp(hidden_states)            # [B,S,3H]

        # 3) 等 lr 完成，再做 epilogue（在当前 stream）
        cur_stream.wait_stream(lr_stream)
        lr.record_stream(cur_stream)  # ★ 重要：跨 stream 使用，避免 allocator 复用风险

        # qkv = fused_qkv_epilogue(sp_mid, lr)           # [3,B,S,H]
        # tok = _CTX_QKV.set(qkv)
        q, k, v = fused_qkv_epilogue(sp_mid, lr)
        del sp_mid, lr
        tok = _CTX_QKV.set((q, k, v))
        del q, k, v
        try:
            return getattr(self, tag)(hidden_states, *args, **kwargs)
        finally:
            _CTX_QKV.reset(tok)

    attn.forward = types.MethodType(patched_forward, attn)




# ============================================================
# Patch mlp.forward (Gate/Up fusion + gu_epilogue + stream overlap)
# ============================================================
def _patch_mlp_forward(mlp: nn.Module):
    tag = "_orig_forward_ablation_gu_epi_stream_nofallback"
    if hasattr(mlp, tag):
        return

    orig_forward = mlp.forward
    setattr(mlp, tag, orig_forward)

    def patched_forward(self, hidden_states, *args, **kwargs):
        if not get_fused_mode():
            raise RuntimeError("[FusedOnly] fused_mode=False but mlp patched fused-only.")
        if (not hasattr(self, "gu_sp")) or (not hasattr(self, "low_rank_gu")):
            raise RuntimeError("[FusedOnly] mlp missing gu_sp/low_rank_gu.")
        if not hidden_states.is_cuda:
            raise RuntimeError("[FusedOnly] CUDA required for stream-overlap.")
        if not callable(fused_gu_epilogue):
            raise RuntimeError("fused_gu_epilogue not available")

        cur_stream = torch.cuda.current_stream()
        lr_stream  = _get_lr_stream()

        # 1) lr 分支放到 lr_stream
        lr_stream.wait_stream(cur_stream)
        with torch.cuda.stream(lr_stream):
            lr = self.low_rank_gu(hidden_states)       # [2,B,S,I]

        # 2) sp 分支留在当前 stream
        sp_mid = self.gu_sp(hidden_states)             # [B,S,2I]

        # 3) wait lr + record_stream，再做 epilogue + down_proj
        cur_stream.wait_stream(lr_stream)
        lr.record_stream(cur_stream)

        I = lr.shape[-1]
        # act = fused_gu_epilogue(sp_mid, lr, I)         # [B,S,I] (内部已做 swiglu)
        # return self.down_proj(act)                     # down_proj 仍然可以是 _AddProjFused（你 wrap 了就走 add_epilogue）
        act = fused_gu_epilogue(sp_mid, lr, I)
        del sp_mid, lr
        y = self.down_proj(act)
        del act
        return y

    mlp.forward = types.MethodType(patched_forward, mlp)




# ============================================================
# Main entry (keep name)
# ============================================================
@torch.no_grad()
def enable_fused_qkv_gu_sparse_and_lr(model: nn.Module) -> None:
    if not callable(fused_qkv_epilogue):
        raise RuntimeError("fused_qkv_epilogue not available")
    if not callable(fused_gu_epilogue):
        raise RuntimeError("fused_gu_epilogue not available")
    if not callable(fused_add_epilogue):
        raise RuntimeError("fused_add_epilogue not available")

    layers = _get_llama_layers(model)

    for layer in layers:
        # ---- Attention ----
        attn = getattr(layer, "self_attn", None) or getattr(layer, "attn", None)
        if attn is not None and hasattr(attn, "q_proj") and hasattr(attn, "k_proj") and hasattr(attn, "v_proj"):
            q0 = _unwrap_mylinear(attn.q_proj)
            k0 = _unwrap_mylinear(attn.k_proj)
            v0 = _unwrap_mylinear(attn.v_proj)
            if q0 is not None and k0 is not None and v0 is not None:
                if q0.lr is None or k0.lr is None or v0.lr is None:
                    raise RuntimeError("Expected q/k/v to have low-rank branches.")

                H  = q0.out_features
                Wq = _dense_weight(q0.sp)
                Wk = _dense_weight(k0.sp)
                Wv = _dense_weight(v0.sp)

                Wqkv = torch.empty((3 * H, Wq.shape[1]), device=Wq.device, dtype=Wq.dtype)
                Wqkv[0:H].copy_(Wq)
                Wqkv[H:2*H].copy_(Wk)
                Wqkv[2*H:3*H].copy_(Wv)
                Wqkv = Wqkv.contiguous()

                attn.qkv_sp = MySparseLinear.from_dense(
                    Wqkv,
                    sparsity_type=getattr(q0.sp, "sparsity_type", "2:4"),
                    use_semi_structured=getattr(q0.sp, "use_semi_structured", True),
                    keep_dense_weight=True,
                )
                attn.low_rank_qkv = MyLowRankGroup.from_branches([q0.lr, k0.lr, v0.lr])

                # ✅ q/k/v fused-only（不引用 base）
                attn.q_proj = _QKVProjFused(out_features=H, group_index=0)
                attn.k_proj = _QKVProjFused(out_features=H, group_index=1)
                attn.v_proj = _QKVProjFused(out_features=H, group_index=2)

                # ✅ o_proj 用 add_epilogue（注意：这个 wrapper 会持有 o0.base，是需要的）
                o0 = _unwrap_mylinear(getattr(attn, "o_proj", None))
                if o0 is not None and o0.lr is not None:
                    attn.o_proj = _AddProjFused(o0, name="attn.o_proj")

                _patch_attention_forward(attn)

        # ---- MLP ----
        mlp = getattr(layer, "mlp", None)
        if mlp is not None and hasattr(mlp, "gate_proj") and hasattr(mlp, "up_proj") and hasattr(mlp, "down_proj"):
            g0 = _unwrap_mylinear(mlp.gate_proj)
            u0 = _unwrap_mylinear(mlp.up_proj)
            if g0 is not None and u0 is not None:
                if g0.lr is None or u0.lr is None:
                    raise RuntimeError("Expected gate/up to have low-rank branches.")

                I  = g0.out_features
                H2 = g0.in_features
                Wg = _dense_weight(g0.sp)
                Wu = _dense_weight(u0.sp)

                Wgu = torch.empty((2 * I, H2), device=Wg.device, dtype=Wg.dtype)
                Wgu[0:I].copy_(Wg)
                Wgu[I:2*I].copy_(Wu)
                Wgu = Wgu.contiguous()

                mlp.gu_sp = MySparseLinear.from_dense(
                    Wgu,
                    sparsity_type=getattr(g0.sp, "sparsity_type", "2:4"),
                    use_semi_structured=getattr(g0.sp, "use_semi_structured", True),
                    keep_dense_weight=True,
                )
                mlp.low_rank_gu = MyLowRankGroup.from_branches([g0.lr, u0.lr])

                # ✅ down_proj 用 add_epilogue
                d0 = _unwrap_mylinear(mlp.down_proj)
                if d0 is not None and d0.lr is not None:
                    mlp.down_proj = _AddProjFused(d0, name="mlp.down_proj")

                _patch_mlp_forward(mlp)

                # ✅ gate/up 不再使用：替换成 NoFallback（释放旧权重并防止误用）
                mlp.gate_proj = _NoFallback("mlp.gate_proj (unused)")
                mlp.up_proj   = _NoFallback("mlp.up_proj (unused)")

    import gc
    gc.collect()
    torch.cuda.empty_cache()




# ============================================================
# finalize (keep name)
# ============================================================
@torch.no_grad()
def finalize_fused_only(model: nn.Module) -> None:
    """
    fused-only + Route A:
      - low_rank_qkv/gu: prepare() 生成 l2_stack_T，然后删除 l2_stack（去掉重复存储）
      - 所有 MySparseLinear: prepare() -> 必须全部 packed 成功（无 fallback），再 drop_dense()
    """
    import gc

    layers = _get_llama_layers(model)

    # 1) low-rank group：prepare + drop l2_stack
    dropped_l2 = 0
    for layer in layers:
        attn = getattr(layer, "self_attn", None) or getattr(layer, "attn", None)
        if attn is not None and hasattr(attn, "low_rank_qkv"):
            g = attn.low_rank_qkv
            g.prepare()
            if getattr(g, "l2_stack", None) is not None:
                g.register_parameter("l2_stack", None)
                dropped_l2 += 1

        mlp = getattr(layer, "mlp", None)
        if mlp is not None and hasattr(mlp, "low_rank_gu"):
            g = mlp.low_rank_gu
            g.prepare()
            if getattr(g, "l2_stack", None) is not None:
                g.register_parameter("l2_stack", None)
                dropped_l2 += 1

    # 2) sparse：确保全部 packed
    total_sp = 0
    packed_sp = 0
    for m in model.modules():
        if isinstance(m, MySparseLinear):
            total_sp += 1
            if getattr(m, "_weight_ss", None) is None:
                m.prepare()
            if getattr(m, "_weight_ss", None) is not None:
                packed_sp += 1

    if packed_sp != total_sp:
        raise RuntimeError(f"[FusedOnly] MySparseLinear not fully packed: {packed_sp}/{total_sp}")

    # 3) drop_dense（无 fallback：全部都可以删）
    dropped_dense = 0
    for m in model.modules():
        if isinstance(m, MySparseLinear) and getattr(m, "weight", None) is not None:
            m.drop_dense()
            dropped_dense += 1

    # 4) 统计 l2_stack_T 大小
    l2t_bytes = 0
    for n, b in model.named_buffers():
        if n.endswith("l2_stack_T"):
            l2t_bytes += b.numel() * b.element_size()

    gc.collect()
    torch.cuda.empty_cache()

    # print("\n==== finalize_fused_only (stream overlap, no add_epilogue, no fallback) ====")
    # print(f"Dropped l2_stack params: {dropped_l2}")
    # print(f"MySparseLinear total   : {total_sp}")
    # print(f"MySparseLinear packed  : {packed_sp}")
    # print(f"Dropped dense weights  : {dropped_dense}")
    # print(f"l2_stack_T total       : {l2t_bytes/1024**2:.2f} MiB")
    # print("==========================================================================\n")













@torch.no_grad()
def prune_wanda_lowrank_alt_alllinear(
        args,
        model,
        tokenizer,
        device=torch.device("cuda:0"),
        prune_n: int = 0,
        prune_m: int = 0,
):
    use_cache = model.config.use_cache
    model.config.use_cache = False

    rank_k = int(getattr(args, "rank_k", 0))
    if rank_k < 0:
        raise ValueError("--rank_k must be > 0 for lr_wanda_iter_alllinear")

    alt_iters = int(getattr(args, "alt_iters", 2))
    alt_tol = float(getattr(args, "alt_tol", 1e-4))
    if alt_iters <= 0:
        raise ValueError("--alt_iters must be >= 1")

    if prune_n != 0:
        if prune_m <= 0:
            raise ValueError("For structured N:M pruning, prune_m must be > 0")
        if prune_n > prune_m:
            raise ValueError(f"prune_n must be <= prune_m, got prune_n={prune_n}, prune_m={prune_m}")

    print("loading calibdation data")
    dataloader, _ = get_loaders(
        "c4",
        nsamples=args.nsamples,
        seed=args.seed,
        seqlen=model.seqlen,
        tokenizer=tokenizer,
    )
    print("dataset loading complete")

    returned_data = prepare_calibration_input(model, dataloader, args.nsamples, model.seqlen)
    inps, outs, attention_mask, position_ids = returned_data[:4]

    layers = model.model.layers
    hf_device_map = getattr(model, "hf_device_map", {})
    rotary_emb = model.model.rotary_emb
    alt_convergence_records: List[Dict] = []

    for i in range(len(layers)):
        layer = layers[i]

        # 修改：拿到该 block 内所有 Linear
        subset_all = find_layers(layer)
        subset = subset_all                      # 不再过滤 down_proj

        # move to mapped device if needed
        if f"model.layers.{i}" in hf_device_map:
            dev = hf_device_map[f"model.layers.{i}"]
            inps = inps.to(dev)
            outs = outs.to(dev)
            attention_mask = attention_mask.to(dev)
            position_ids = position_ids.to(dev)

        if len(subset) == 0:
            # still need forward to propagate calibration activations
            for j in range(args.nsamples):
                position_embeddings = rotary_emb(inps[j], position_ids)
                outs[j] = layer(
                    inps[j].unsqueeze(0),
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    position_embeddings=position_embeddings,
                )[0]
            inps, outs = outs, inps
            continue

        # Wanda stat collection
        wrapped_layers = {name: WrappedGPT(subset[name]) for name in subset}

        def add_batch(name):
            def tmp(_, inp, out):
                wrapped_layers[name].add_batch(inp[0].data, out.data)
            return tmp

        handles = []
        for name in wrapped_layers:
            handles.append(subset[name].register_forward_hook(add_batch(name)))

        # forward pass to collect stats
        for j in range(args.nsamples):
            position_embeddings = rotary_emb(inps[j], position_ids)
            outs[j] = layer(
                inps[j].unsqueeze(0),
                attention_mask=attention_mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )[0]

        for h in handles:
            h.remove()

        # 这里会对该 block 内每个 Linear 做： (a) residual Wanda prune + (b) low-rank fit
        # NOTE: We DO NOT write back dense W_approx anymore.
        replacements: Dict[str, nn.Module] = {}
        for name, lin in subset.items():
            Wd = lin.weight.data
            bias = lin.bias.data if getattr(lin, "bias", None) is not None else None

            scaler = wrapped_layers[name].scaler_row.reshape((1, -1))
            sqrt_scaler = torch.sqrt(scaler)

            # init Delta (low-rank) as dense, but keep factors for the final replacement
            B, A = _rank_k_svd_factors(Wd, rank_k)
            Delta = (B.float() @ A.float()).to(Wd.dtype) if (B is not None and A is not None) else torch.zeros_like(Wd)

            prev_err = None
            Ws = None
            denom = Wd.float().norm() + 1e-12

            B_best, A_best = B, A
            Ws_best = None
            best_err_value = None
            module_records: List[Dict] = []
            stop_iter = None
            for it in range(alt_iters):
                # (a) prune residual: 固定 ΔW，更新 Ws
                R = Wd - Delta
                W_metric = torch.abs(R) * sqrt_scaler  # Wanda metric on residual
                mask = _build_prune_mask(W_metric, args.sparsity_ratio, prune_n=prune_n, prune_m=prune_m)

                Ws = R.clone()
                Ws[mask] = 0

                # (b) fit low-rank to target: 固定 Ws，更新 ΔW
                target = Wd - Ws
                B_new, A_new = _rank_k_svd_factors(target, rank_k)
                Delta_new = (B_new.float() @ A_new.float()).to(Wd.dtype) if (B_new is not None and A_new is not None) else torch.zeros_like(Wd)

                W_approx = Ws + Delta_new
                err = (Wd - W_approx).float().norm() / denom

                err_value = float(err.item())
                improvement_value = None
                stopped = False
                if best_err_value is None or err_value < best_err_value:
                    best_err_value = err_value
                    Ws_best = Ws.clone()
                    B_best, A_best = B_new, A_new
                if prev_err is None:
                    print(f"[alt] layer {i} {name} iter {it+1}/{alt_iters}: rel_frob_err={err_value:.6e}")
                else:
                    improvement_value = float((prev_err - err).item())
                    print(f"[alt] layer {i} {name} iter {it+1}/{alt_iters}: rel_frob_err={err_value:.6e} (Δ={improvement_value:+.2e})")
                    if abs(improvement_value) < alt_tol:
                        stopped = True
                        stop_iter = it + 1
                        module_records.append(
                            {
                                "layer": i,
                                "module": name,
                                "iter": it + 1,
                                "rel_frob_err": err_value,
                                "improvement": improvement_value,
                                "stopped": stopped,
                                "stop_iter": "",
                                "rank_k": rank_k,
                                "alt_tol": alt_tol,
                            }
                        )
                        Delta = Delta_new
                        prev_err = err
                        break

                module_records.append(
                    {
                        "layer": i,
                        "module": name,
                        "iter": it + 1,
                        "rel_frob_err": err_value,
                        "improvement": improvement_value,
                        "stopped": stopped,
                        "stop_iter": "",
                        "rank_k": rank_k,
                        "alt_tol": alt_tol,
                    }
                )
                Delta = Delta_new
                prev_err = err

            if stop_iter is None:
                stop_iter = len(module_records)
            for rec in module_records:
                rec["stop_iter"] = stop_iter
            alt_convergence_records.extend(module_records)

            if Ws is None:
                Ws = Wd - Delta
            elif Ws_best is not None:
                Ws = Ws_best

            # Build composite module (sparse Ws + low-rank residual) and replace later.
            sp = MySparseLinear.from_dense(
                Ws,
                sparsity_type=getattr(args, "sparsity_type", "2:4"),
                use_semi_structured=((prune_n != 0) and (not bool(getattr(args, "disable_semi_structured", False)))),
                keep_dense_weight=True,
            )
            lr = MyLowRankBranch.from_factors(A_best, B_best) if (A_best is not None and B_best is not None) else None
            replacements[name] = MyLinear(sp=sp, lr=lr, bias=bias)

            del Ws, Ws_best, Delta, W_metric, mask

        # Apply replacements after finishing this block (avoid interfering with iteration over subset).
        for n, new_mod in replacements.items():
            _set_submodule(layer, n, new_mod)

        # propagate for next block using updated weights
        for j in range(args.nsamples):
            position_embeddings = rotary_emb(inps[j], position_ids)
            outs[j] = layer(
                inps[j].unsqueeze(0),
                attention_mask=attention_mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )[0]
        inps, outs = outs, inps

    _write_alt_convergence_outputs(alt_convergence_records, args)
    model.config.use_cache = use_cache
    torch.cuda.empty_cache()


@torch.no_grad()
def prune_wanda_lowrank_alt_actsvd_alllinear(
        args,
        model,
        tokenizer,
        device=torch.device("cuda:0"),
        prune_n: int = 0,
        prune_m: int = 0,
):
    use_cache = model.config.use_cache
    model.config.use_cache = False

    rank_k = int(getattr(args, "rank_k", 0))
    if rank_k < 0:
        raise ValueError("--rank_k must be >= 0 for lr_wanda_iter_actsvd_alllinear")

    alt_iters = int(getattr(args, "alt_iters", 2))
    if alt_iters <= 0:
        raise ValueError("--alt_iters must be >= 1")

    if prune_n != 0:
        if prune_m <= 0:
            raise ValueError("For structured N:M pruning, prune_m must be > 0")
        if prune_n > prune_m:
            raise ValueError(f"prune_n must be <= prune_m, got prune_n={prune_n}, prune_m={prune_m}")

    print(
        "[alt-actsvd] config "
        f"rank_k={rank_k} alt_iters={alt_iters} alt_tol={float(getattr(args, 'alt_tol', 0.0)):.3e} "
        f"alt_rel_tol={float(getattr(args, 'alt_rel_tol', 0.0)):.3e} "
        f"alt_min_iters={int(getattr(args, 'alt_min_iters', 2))} "
        f"alt_patience={int(getattr(args, 'alt_patience', 1))}"
    )
    print("loading calibdation data")
    dataloader, _ = get_loaders(
        "c4",
        nsamples=args.nsamples,
        seed=args.seed,
        seqlen=model.seqlen,
        tokenizer=tokenizer,
    )
    print("dataset loading complete")

    returned_data = prepare_calibration_input(model, dataloader, args.nsamples, model.seqlen)
    inps, outs, attention_mask, position_ids = returned_data[:4]

    layers = model.model.layers
    hf_device_map = getattr(model, "hf_device_map", {})
    rotary_emb = model.model.rotary_emb
    alt_convergence_records: List[Dict] = []

    for i in range(len(layers)):
        layer = layers[i]
        subset = find_layers(layer)
        print(f"[alt-actsvd] layer {i}/{len(layers)-1} modules={len(subset)}")

        if f"model.layers.{i}" in hf_device_map:
            dev = hf_device_map[f"model.layers.{i}"]
            inps = inps.to(dev)
            outs = outs.to(dev)
            attention_mask = attention_mask.to(dev)
            position_ids = position_ids.to(dev)

        if len(subset) == 0:
            for j in range(args.nsamples):
                position_embeddings = rotary_emb(inps[j], position_ids)
                outs[j] = layer(
                    inps[j].unsqueeze(0),
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    position_embeddings=position_embeddings,
                )[0]
            inps, outs = outs, inps
            continue

        wrapped_layers = {name: WrappedGPT(subset[name]) for name in subset}

        def add_batch(name):
            def tmp(_, inp, out):
                wrapped_layers[name].add_batch(inp[0].data, out.data)
            return tmp

        handles = []
        for name in wrapped_layers:
            handles.append(subset[name].register_forward_hook(add_batch(name)))

        for j in range(args.nsamples):
            position_embeddings = rotary_emb(inps[j], position_ids)
            outs[j] = layer(
                inps[j].unsqueeze(0),
                attention_mask=attention_mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )[0]

        for h in handles:
            h.remove()

        replacements: Dict[str, nn.Module] = {}
        for name, lin in subset.items():
            Wd = lin.weight.data
            bias = lin.bias.data if getattr(lin, "bias", None) is not None else None

            scaler = wrapped_layers[name].scaler_row.reshape((1, -1))
            sqrt_scaler = torch.sqrt(scaler).to(device=Wd.device, dtype=torch.float32)

            B, A = _rank_k_act_svd_factors(Wd, scaler, rank_k)
            Delta = (B.float() @ A.float()).to(Wd.dtype) if (B is not None and A is not None) else torch.zeros_like(Wd)

            prev_err_value = None
            stale_iters = 0
            Ws = None
            denom = (Wd.float() * sqrt_scaler).norm() + 1e-12

            B_best, A_best = B, A
            Ws_best = None
            best_err_value = None
            module_records: List[Dict] = []
            stop_iter = None
            stop_reason = ""
            for it in range(alt_iters):
                iteration = it + 1

                R = Wd - Delta
                W_metric = torch.abs(R) * sqrt_scaler
                mask = _build_prune_mask(W_metric, args.sparsity_ratio, prune_n=prune_n, prune_m=prune_m)

                Ws = R.clone()
                Ws[mask] = 0

                target = Wd - Ws
                B_new, A_new = _rank_k_act_svd_factors(target, scaler, rank_k)
                Delta_new = (B_new.float() @ A_new.float()).to(Wd.dtype) if (B_new is not None and A_new is not None) else torch.zeros_like(Wd)

                W_approx = Ws + Delta_new
                err = ((Wd - W_approx).float() * sqrt_scaler).norm() / denom
                err_value = float(err.item())
                improvement_value = None
                stopped = False

                if prev_err_value is None:
                    print(f"[alt-actsvd] layer {i} {name} iter {iteration}/{alt_iters}: act_rel_err={err_value:.6e}")
                else:
                    improvement_value, stopped, stale_iters, stop_reason = _alt_early_stop_update(
                        iteration=iteration,
                        prev_err_value=prev_err_value,
                        err_value=err_value,
                        stale_iters=stale_iters,
                        args=args,
                    )
                    msg = (
                        f"[alt-actsvd] layer {i} {name} iter {iteration}/{alt_iters}: "
                        f"act_rel_err={err_value:.6e} (Δ={improvement_value:+.2e}, stale={stale_iters})"
                    )
                    if stopped:
                        msg += f" early_stop={stop_reason}"
                    print(msg)

                module_records.append(
                    {
                        "layer": i,
                        "module": name,
                        "iter": iteration,
                        "rel_frob_err": err_value,
                        "improvement": improvement_value,
                        "stopped": stopped,
                        "stop_iter": "",
                        "rank_k": rank_k,
                        "alt_tol": float(getattr(args, "alt_tol", 0.0)),
                        "alt_rel_tol": float(getattr(args, "alt_rel_tol", 0.0)),
                        "alt_min_iters": int(getattr(args, "alt_min_iters", 2)),
                        "alt_patience": int(getattr(args, "alt_patience", 1)),
                        "stop_reason": stop_reason if stopped else "",
                        "act_aware_svd": True,
                        "act_svd_kind": "diag",
                    }
                )

                if best_err_value is None or err_value < best_err_value:
                    best_err_value = err_value
                    Ws_best = Ws.clone()
                    B_best, A_best = B_new, A_new
                Delta = Delta_new
                prev_err_value = err_value
                if stopped:
                    stop_iter = iteration
                    break

            if stop_iter is None:
                stop_iter = len(module_records)
            for rec in module_records:
                rec["stop_iter"] = stop_iter
            alt_convergence_records.extend(module_records)

            if Ws is None:
                Ws = Wd - Delta
            elif Ws_best is not None:
                Ws = Ws_best

            sp = MySparseLinear.from_dense(
                Ws,
                sparsity_type=getattr(args, "sparsity_type", "2:4"),
                use_semi_structured=(prune_n != 0),
                keep_dense_weight=True,
            )
            lr = MyLowRankBranch.from_factors(A_best, B_best) if (A_best is not None and B_best is not None) else None
            replacements[name] = MyLinear(sp=sp, lr=lr, bias=bias)

            del Ws, Ws_best, Delta, W_metric, mask

        for n, new_mod in replacements.items():
            _set_submodule(layer, n, new_mod)

        for j in range(args.nsamples):
            position_embeddings = rotary_emb(inps[j], position_ids)
            outs[j] = layer(
                inps[j].unsqueeze(0),
                attention_mask=attention_mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )[0]
        inps, outs = outs, inps
        torch.cuda.empty_cache()

    _write_alt_convergence_outputs(alt_convergence_records, args)
    model.config.use_cache = use_cache
    torch.cuda.empty_cache()


def _full_actsvd_factors(
        M: torch.Tensor,
        stats: _ActivationStats,
        rank_k: int,
        *,
        act_svd_kind: str,
        niter: int,
        oversample: int,
        chunk_tokens: int,
) -> Tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
    if act_svd_kind == "fullcov":
        if stats.input_cov is None:
            raise ValueError("fullcov actSVD requires input_cov")
        return _rank_k_fullcov_act_svd_factors(
            M,
            stats.input_cov,
            rank_k,
            niter=niter,
            oversample=oversample,
        )
    if act_svd_kind == "fullx":
        if stats.input_batches is None:
            raise ValueError("fullx actSVD requires stored input batches")
        return _rank_k_fullx_act_svd_factors(
            M,
            stats.input_batches,
            rank_k,
            niter=niter,
            oversample=oversample,
            chunk_tokens=chunk_tokens,
        )
    raise ValueError(f"Unsupported act_svd_kind={act_svd_kind!r}")


def _full_actsvd_norm(
        M: torch.Tensor,
        stats: _ActivationStats,
        *,
        act_svd_kind: str,
        chunk_tokens: int,
) -> torch.Tensor:
    if act_svd_kind == "fullcov":
        if stats.input_cov is None:
            raise ValueError("fullcov actSVD requires input_cov")
        return _cov_weighted_norm(M, stats.input_cov)
    if act_svd_kind == "fullx":
        if stats.input_batches is None:
            raise ValueError("fullx actSVD requires stored input batches")
        return _fullx_output_norm(M, stats.input_batches, chunk_tokens=chunk_tokens)
    raise ValueError(f"Unsupported act_svd_kind={act_svd_kind!r}")


@torch.no_grad()
def _prune_wanda_lowrank_alt_fullactsvd_alllinear(
        args,
        model,
        tokenizer,
        device=torch.device("cuda:0"),
        prune_n: int = 0,
        prune_m: int = 0,
        *,
        act_svd_kind: str,
        sparse_step_kind: str = "wanda",
):
    if act_svd_kind not in ("fullx", "fullcov"):
        raise ValueError(f"act_svd_kind must be 'fullx' or 'fullcov', got {act_svd_kind!r}")
    if sparse_step_kind not in ("wanda", "quad"):
        raise ValueError(f"sparse_step_kind must be 'wanda' or 'quad', got {sparse_step_kind!r}")

    use_cache = model.config.use_cache
    model.config.use_cache = False

    rank_k = int(getattr(args, "rank_k", 0))
    if rank_k < 0:
        raise ValueError(f"--rank_k must be >= 0 for lr_wanda_iter_{act_svd_kind}_actsvd_alllinear")

    alt_iters = int(getattr(args, "alt_iters", 2))
    if alt_iters <= 0:
        raise ValueError("--alt_iters must be >= 1")

    if prune_n != 0:
        if prune_m <= 0:
            raise ValueError("For structured N:M pruning, prune_m must be > 0")
        if prune_n > prune_m:
            raise ValueError(f"prune_n must be <= prune_m, got prune_n={prune_n}, prune_m={prune_m}")
    if sparse_step_kind == "quad" and (prune_n != 2 or prune_m != 4):
        raise ValueError("quad sparse step currently requires --sparsity_type 2:4")

    full_niter = int(getattr(args, "full_actsvd_niter", 2))
    full_oversample = int(getattr(args, "full_actsvd_oversample", 8))
    chunk_tokens = int(getattr(args, "fullx_chunk_tokens", 4096))
    quad_chunk_rows = int(getattr(args, "quad_chunk_rows", 128))
    x_store_dtype = _fullx_store_dtype_from_name(getattr(args, "fullx_store_dtype", "float16"))
    tag = f"alt-{act_svd_kind}-actsvd" if sparse_step_kind == "wanda" else f"alt-quad-{act_svd_kind}-actsvd"

    print(
        f"[{tag}] config "
        f"rank_k={rank_k} alt_iters={alt_iters} alt_tol={float(getattr(args, 'alt_tol', 0.0)):.3e} "
        f"alt_rel_tol={float(getattr(args, 'alt_rel_tol', 0.0)):.3e} "
        f"alt_min_iters={int(getattr(args, 'alt_min_iters', 2))} "
        f"alt_patience={int(getattr(args, 'alt_patience', 1))} "
        f"full_actsvd_niter={full_niter} full_actsvd_oversample={full_oversample} "
        f"fullx_chunk_tokens={chunk_tokens} fullx_store_dtype={x_store_dtype} "
        f"sparse_step_kind={sparse_step_kind} quad_chunk_rows={quad_chunk_rows}"
    )
    print("loading calibdation data")
    dataloader, _ = get_loaders(
        "c4",
        nsamples=args.nsamples,
        seed=args.seed,
        seqlen=model.seqlen,
        tokenizer=tokenizer,
    )
    print("dataset loading complete")

    returned_data = prepare_calibration_input(model, dataloader, args.nsamples, model.seqlen)
    inps, outs, attention_mask, position_ids = returned_data[:4]

    layers = model.model.layers
    hf_device_map = getattr(model, "hf_device_map", {})
    rotary_emb = model.model.rotary_emb
    alt_convergence_records: List[Dict] = []

    for i in range(len(layers)):
        layer = layers[i]
        subset = find_layers(layer)
        print(f"[{tag}] layer {i}/{len(layers)-1} modules={len(subset)}")

        if f"model.layers.{i}" in hf_device_map:
            dev = hf_device_map[f"model.layers.{i}"]
            inps = inps.to(dev)
            outs = outs.to(dev)
            attention_mask = attention_mask.to(dev)
            position_ids = position_ids.to(dev)

        if len(subset) == 0:
            for j in range(args.nsamples):
                position_embeddings = rotary_emb(inps[j], position_ids)
                outs[j] = layer(
                    inps[j].unsqueeze(0),
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    position_embeddings=position_embeddings,
                )[0]
            inps, outs = outs, inps
            continue

        wrapped_layers = {
            name: _ActivationStats(
                subset[name],
                collect_cov=(act_svd_kind == "fullcov" or sparse_step_kind == "quad"),
                collect_x=(act_svd_kind == "fullx"),
                x_store_dtype=x_store_dtype,
            )
            for name in subset
        }

        def add_batch(name):
            def tmp(_, inp, out):
                wrapped_layers[name].add_batch(inp[0].data, out.data)
            return tmp

        handles = []
        for name in wrapped_layers:
            handles.append(subset[name].register_forward_hook(add_batch(name)))

        for j in range(args.nsamples):
            position_embeddings = rotary_emb(inps[j], position_ids)
            outs[j] = layer(
                inps[j].unsqueeze(0),
                attention_mask=attention_mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )[0]

        for h in handles:
            h.remove()

        replacements: Dict[str, nn.Module] = {}
        for name, lin in subset.items():
            stats = wrapped_layers[name]
            Wd = lin.weight.data
            bias = lin.bias.data if getattr(lin, "bias", None) is not None else None

            scaler = stats.scaler_row.reshape((1, -1))
            sqrt_scaler = torch.sqrt(scaler).to(device=Wd.device, dtype=torch.float32)

            B, A = _full_actsvd_factors(
                Wd,
                stats,
                rank_k,
                act_svd_kind=act_svd_kind,
                niter=full_niter,
                oversample=full_oversample,
                chunk_tokens=chunk_tokens,
            )
            Delta = (B.float() @ A.float()).to(Wd.dtype) if (B is not None and A is not None) else torch.zeros_like(Wd)

            prev_err_value = None
            stale_iters = 0
            Ws = None
            denom = _full_actsvd_norm(Wd, stats, act_svd_kind=act_svd_kind, chunk_tokens=chunk_tokens) + 1e-12

            B_best, A_best = B, A
            Ws_best = None
            best_err_value = None
            module_records: List[Dict] = []
            stop_iter = None
            stop_reason = ""
            for it in range(alt_iters):
                iteration = it + 1

                R = Wd - Delta
                W_metric = None
                if sparse_step_kind == "quad":
                    if stats.input_cov is None:
                        raise ValueError("quad sparse step requires input_cov")
                    mask = _build_quad_nm_prune_mask(
                        R,
                        stats.input_cov,
                        prune_n=prune_n,
                        prune_m=prune_m,
                        chunk_rows=quad_chunk_rows,
                    )
                else:
                    W_metric = torch.abs(R) * sqrt_scaler
                    mask = _build_prune_mask(W_metric, args.sparsity_ratio, prune_n=prune_n, prune_m=prune_m)

                Ws = R.clone()
                Ws[mask] = 0

                target = Wd - Ws
                B_new, A_new = _full_actsvd_factors(
                    target,
                    stats,
                    rank_k,
                    act_svd_kind=act_svd_kind,
                    niter=full_niter,
                    oversample=full_oversample,
                    chunk_tokens=chunk_tokens,
                )
                Delta_new = (B_new.float() @ A_new.float()).to(Wd.dtype) if (B_new is not None and A_new is not None) else torch.zeros_like(Wd)

                W_approx = Ws + Delta_new
                err = _full_actsvd_norm(
                    Wd - W_approx,
                    stats,
                    act_svd_kind=act_svd_kind,
                    chunk_tokens=chunk_tokens,
                ) / denom
                err_value = float(err.item())
                improvement_value = None
                stopped = False

                if prev_err_value is None:
                    print(f"[{tag}] layer {i} {name} iter {iteration}/{alt_iters}: {act_svd_kind}_rel_err={err_value:.6e}")
                else:
                    improvement_value, stopped, stale_iters, stop_reason = _alt_early_stop_update(
                        iteration=iteration,
                        prev_err_value=prev_err_value,
                        err_value=err_value,
                        stale_iters=stale_iters,
                        args=args,
                    )
                    msg = (
                        f"[{tag}] layer {i} {name} iter {iteration}/{alt_iters}: "
                        f"{act_svd_kind}_rel_err={err_value:.6e} (Δ={improvement_value:+.2e}, stale={stale_iters})"
                    )
                    if stopped:
                        msg += f" early_stop={stop_reason}"
                    print(msg)

                module_records.append(
                    {
                        "layer": i,
                        "module": name,
                        "iter": iteration,
                        "rel_frob_err": err_value,
                        "improvement": improvement_value,
                        "stopped": stopped,
                        "stop_iter": "",
                        "rank_k": rank_k,
                        "alt_tol": float(getattr(args, "alt_tol", 0.0)),
                        "alt_rel_tol": float(getattr(args, "alt_rel_tol", 0.0)),
                        "alt_min_iters": int(getattr(args, "alt_min_iters", 2)),
                        "alt_patience": int(getattr(args, "alt_patience", 1)),
                        "stop_reason": stop_reason if stopped else "",
                        "act_aware_svd": True,
                        "act_svd_kind": act_svd_kind,
                        "sparse_step_kind": sparse_step_kind,
                    }
                )

                if best_err_value is None or err_value < best_err_value:
                    best_err_value = err_value
                    Ws_best = Ws.clone()
                    B_best, A_best = B_new, A_new
                Delta = Delta_new
                prev_err_value = err_value
                if stopped:
                    stop_iter = iteration
                    break

            if stop_iter is None:
                stop_iter = len(module_records)
            for rec in module_records:
                rec["stop_iter"] = stop_iter
            alt_convergence_records.extend(module_records)

            if Ws is None:
                Ws = Wd - Delta
            elif Ws_best is not None:
                Ws = Ws_best

            sp = MySparseLinear.from_dense(
                Ws,
                sparsity_type=getattr(args, "sparsity_type", "2:4"),
                use_semi_structured=(prune_n != 0),
                keep_dense_weight=True,
            )
            lr = MyLowRankBranch.from_factors(A_best, B_best) if (A_best is not None and B_best is not None) else None
            replacements[name] = MyLinear(sp=sp, lr=lr, bias=bias)

            stats.free()
            del Ws, Ws_best, Delta, W_metric, mask
            torch.cuda.empty_cache()

        for n, new_mod in replacements.items():
            _set_submodule(layer, n, new_mod)

        for j in range(args.nsamples):
            position_embeddings = rotary_emb(inps[j], position_ids)
            outs[j] = layer(
                inps[j].unsqueeze(0),
                attention_mask=attention_mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )[0]
        inps, outs = outs, inps
        del wrapped_layers
        torch.cuda.empty_cache()

    _write_alt_convergence_outputs(alt_convergence_records, args)
    model.config.use_cache = use_cache
    torch.cuda.empty_cache()


@torch.no_grad()
def prune_wanda_lowrank_alt_fullx_actsvd_alllinear(
        args,
        model,
        tokenizer,
        device=torch.device("cuda:0"),
        prune_n: int = 0,
        prune_m: int = 0,
):
    return _prune_wanda_lowrank_alt_fullactsvd_alllinear(
        args,
        model,
        tokenizer,
        device=device,
        prune_n=prune_n,
        prune_m=prune_m,
        act_svd_kind="fullx",
        sparse_step_kind="wanda",
    )


@torch.no_grad()
def prune_wanda_lowrank_alt_fullcov_actsvd_alllinear(
        args,
        model,
        tokenizer,
        device=torch.device("cuda:0"),
        prune_n: int = 0,
        prune_m: int = 0,
):
    return _prune_wanda_lowrank_alt_fullactsvd_alllinear(
        args,
        model,
        tokenizer,
        device=device,
        prune_n=prune_n,
        prune_m=prune_m,
        act_svd_kind="fullcov",
        sparse_step_kind="wanda",
    )


@torch.no_grad()
def prune_quad_lowrank_alt_fullx_actsvd_alllinear(
        args,
        model,
        tokenizer,
        device=torch.device("cuda:0"),
        prune_n: int = 0,
        prune_m: int = 0,
):
    return _prune_wanda_lowrank_alt_fullactsvd_alllinear(
        args,
        model,
        tokenizer,
        device=device,
        prune_n=prune_n,
        prune_m=prune_m,
        act_svd_kind="fullx",
        sparse_step_kind="quad",
    )


@torch.no_grad()
def prune_quad_lowrank_alt_fullcov_actsvd_alllinear(
        args,
        model,
        tokenizer,
        device=torch.device("cuda:0"),
        prune_n: int = 0,
        prune_m: int = 0,
):
    return _prune_wanda_lowrank_alt_fullactsvd_alllinear(
        args,
        model,
        tokenizer,
        device=device,
        prune_n=prune_n,
        prune_m=prune_m,
        act_svd_kind="fullcov",
        sparse_step_kind="quad",
    )



@torch.no_grad()
def prune_wanda_svd_alllinear(args, model, tokenizer, device=torch.device("cuda:0"), prune_n=0, prune_m=0):
    use_cache = model.config.use_cache
    model.config.use_cache = False

    print("loading calibdation data")
    dataloader, _ = get_loaders(
        "c4", nsamples=args.nsamples, seed=args.seed, seqlen=model.seqlen, tokenizer=tokenizer
    )
    print("dataset loading complete")
    returned_data = prepare_calibration_input(model, dataloader, args.nsamples, model.seqlen)
    inps, outs, attention_mask, position_ids = returned_data[:4]

    layers = model.model.layers
    rotary_emb = model.model.rotary_emb
    for i in range(len(layers)):
        layer = layers[i]
        subset_all = find_layers(layer)
        subset = subset_all
        if f"model.layers.{i}" in model.hf_device_map:
            dev = model.hf_device_map[f"model.layers.{i}"]
            inps, outs, attention_mask, position_ids = (
                inps.to(dev),
                outs.to(dev),
                attention_mask.to(dev),
                position_ids.to(dev),
            )

        wrapped_layers = {name: WrappedGPT(subset[name]) for name in subset}

        def add_batch(name):
            def tmp(_, inp, out):
                wrapped_layers[name].add_batch(inp[0].data, out.data)
            return tmp

        handles = []
        for name in wrapped_layers:
            handles.append(subset[name].register_forward_hook(add_batch(name)))

        # Run once to collect Wanda stats
        for j in range(args.nsamples):
            position_embeddings = rotary_emb(inps[j], position_ids)
            outs[j] = layer(
                inps[j].unsqueeze(0),
                attention_mask=attention_mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )[0]

        for h in handles:
            h.remove()

        # Wanda prune, then SVD on pruning delta (one-shot) for each Linear.
        # NOTE: We replace nn.Linear with MyLinear(sp=Ws, lr=B@A) instead of densifying.
        replacements: Dict[str, nn.Module] = {}
        for name in subset:
            print(f"[wanda_svd_alllinear] layer {i} name {name}")
            lin = subset[name]
            W = lin.weight.data
            bias = lin.bias.data if getattr(lin, "bias", None) is not None else None

            W_metric = torch.abs(W) * torch.sqrt(wrapped_layers[name].scaler_row.reshape((1, -1)))
            W_mask = _build_prune_mask(W_metric, args.sparsity_ratio, prune_n=prune_n, prune_m=prune_m)

            # Ws: kept weights (sparse branch)
            Ws = W.clone()
            Ws[W_mask] = 0
            wanda_sparsity = float((Ws == 0).sum().item()) / Ws.numel()
            print(f"  wanda sparsity(sparse branch): {wanda_sparsity:.6f}")

            # DeltaB: removed part by Wanda (low-rank branch target)
            DeltaB = W.clone()
            DeltaB[~W_mask] = 0
            B, A = _rank_k_svd_factors(
                DeltaB,
                getattr(args, "rank_k", 64),
                backend=getattr(args, "oneshot_svd_backend", "lowrank"),
            )

            sp = MySparseLinear.from_dense(
                Ws,
                sparsity_type=getattr(args, "sparsity_type", "2:4"),
                use_semi_structured=(prune_n != 0),
                keep_dense_weight=True,
            )
            lr = MyLowRankBranch.from_factors(A, B) if (A is not None and B is not None) else None
            replacements[name] = MyLinear(sp=sp, lr=lr, bias=bias)

            del Ws, DeltaB, W_metric, W_mask

        # Apply replacements after finishing the block.
        for n, new_mod in replacements.items():
            _set_submodule(layer, n, new_mod)

        # Propagate outputs with updated weights
        for j in range(args.nsamples):
            position_embeddings = rotary_emb(inps[j], position_ids)
            outs[j] = layer(
                inps[j].unsqueeze(0),
                attention_mask=attention_mask,
                position_ids=position_ids,
                position_embeddings=position_embeddings,
            )[0]

        inps, outs = outs, inps

    model.config.use_cache = use_cache
    torch.cuda.empty_cache()
