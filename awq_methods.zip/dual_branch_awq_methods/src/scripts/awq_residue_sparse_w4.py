#!/usr/bin/env python3
"""Mask-preserving AWQ fake quantization for a Residue Pruning checkpoint.

This is an accuracy-only adapter for the additive Residue layer

    y = S x + B(Ax),

where S has a fixed 2:4 mask.  The official llm-awq implementation only
discovers ``nn.Linear`` modules and therefore cannot operate on ``MyLinear``
directly.  This adapter keeps the official AWQ calibration set, scale-search
objective, clipping search, and asymmetric W4-g128 fake quantizer, while:

* searching/quantizing the sparse branch S only;
* keeping A and B in FP16;
* applying AWQ's equivalent channel scaling to both additive branches; and
* projecting rounded-to-zero active weights to the nearest non-zero level so
  that the original 2:4 mask remains exact.

It does not provide an INT4 kernel and must not be used for throughput or
memory claims.
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import os
import random
import subprocess
import sys
import time
import types
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from lib.prune import MyLinear  # noqa: E402
from scripts.eval_int4_weightonly_ppl_cmqa import _load_residue_model  # noqa: E402


PROJECTION_NAMES = (
    "self_attn.q_proj",
    "self_attn.k_proj",
    "self_attn.v_proj",
    "self_attn.o_proj",
    "mlp.gate_proj",
    "mlp.up_proj",
    "mlp.down_proj",
)


@dataclass
class QuantStats:
    layer: int
    name: str
    numel: int
    active: int
    rounded_active_to_zero_before_projection: int
    mask_equal: bool
    groups_2_4: int
    violations_2_4: int
    mse: float
    max_abs_error: float


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--awq_repo", type=Path, default=Path("/mnt/llm-awq"))
    parser.add_argument("--output_checkpoint", type=Path)
    parser.add_argument("--output_json", type=Path, required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--dtype", default="fp16", choices=("fp16", "bf16"))
    parser.add_argument("--w_bit", type=int, default=4)
    parser.add_argument("--q_group_size", type=int, default=128)
    parser.add_argument("--n_samples", type=int, default=128)
    parser.add_argument("--seqlen", type=int, default=512)
    parser.add_argument("--scale_grid", type=int, default=20)
    parser.add_argument("--clip_grid", type=int, default=20)
    parser.add_argument("--clip_max_shrink", type=float, default=0.5)
    parser.add_argument("--clip_sample_tokens", type=int, default=512)
    parser.add_argument("--max_layers", type=int, default=0)
    parser.add_argument("--skip_clip", action="store_true")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def import_official_awq(awq_repo: Path):
    """Import the official fake-quant/calibration functions.

    llm-awq imports its compiled inference extension at package import time,
    even for the fake backend.  A module stub is sufficient here because this
    script never instantiates or calls a real-quant kernel class.
    """

    if not (awq_repo / "awq/quantize/quantizer.py").is_file():
        raise FileNotFoundError(f"Not an llm-awq checkout: {awq_repo}")
    sys.path.insert(0, str(awq_repo))
    sys.modules.setdefault(
        "awq_inference_engine", types.ModuleType("awq_inference_engine")
    )
    from awq.quantize.quantizer import pseudo_quantize_tensor
    from awq.utils.calib_data import get_calib_dataset

    revision_file = awq_repo / "REVISION"
    if revision_file.is_file():
        return pseudo_quantize_tensor, get_calib_dataset, revision_file.read_text().strip()
    try:
        commit = subprocess.check_output(
            ["git", "-C", str(awq_repo), "rev-parse", "HEAD"], text=True
        ).strip()
    except Exception:
        commit = "unknown"
    return pseudo_quantize_tensor, get_calib_dataset, commit


def tensor_output(output: Any) -> torch.Tensor:
    if isinstance(output, tuple):
        return output[0]
    if hasattr(output, "last_hidden_state"):
        return output.last_hidden_state
    return output


def move_tree(value: Any, device: torch.device) -> Any:
    if torch.is_tensor(value):
        return value.to(device)
    if isinstance(value, tuple):
        return tuple(move_tree(x, device) for x in value)
    if isinstance(value, list):
        return [move_tree(x, device) for x in value]
    if isinstance(value, dict):
        return {k: move_tree(v, device) for k, v in value.items()}
    return value


def require_residue(module: nn.Module, name: str) -> MyLinear:
    if not isinstance(module, MyLinear):
        raise TypeError(f"{name}: expected MyLinear, got {type(module).__name__}")
    if module.sp.weight is None:
        raise ValueError(f"{name}: sparse dense-view weight is missing")
    if module.lr is None or module.lr.l1 is None or module.lr.l2 is None:
        raise ValueError(f"{name}: rank-positive low-rank branch is missing")
    return module


def count_2_4(weight: torch.Tensor) -> Tuple[int, int]:
    if weight.ndim != 2 or weight.shape[1] % 4:
        return 0, 0
    zeros = weight.eq(0).reshape(weight.shape[0], -1, 4).sum(dim=-1)
    return zeros.numel(), int((zeros != 2).sum().item())


@torch.no_grad()
def mask_preserving_awq_quant(
    weight: torch.Tensor,
    official_pseudo_quantize_tensor,
    *,
    w_bit: int,
    group_size: int,
) -> Tuple[torch.Tensor, int, torch.Tensor, torch.Tensor]:
    """Official asymmetric fake quantization plus fixed-mask projection."""

    original_mask = weight.eq(0)
    quantized, scales, zeros = official_pseudo_quantize_tensor(
        weight,
        n_bit=w_bit,
        zero_point=True,
        q_group_size=group_size,
        get_scale_zp=True,
    )
    quantized = quantized.reshape(weight.shape[0], -1, group_size)
    grouped_weight = weight.reshape(weight.shape[0], -1, group_size)
    grouped_mask = original_mask.reshape(weight.shape[0], -1, group_size)
    grouped_scales = scales.reshape(weight.shape[0], -1, 1).to(quantized)

    rounded_active = (~grouped_mask) & quantized.eq(0)
    rounded_count = int(rounded_active.sum().item())
    if rounded_count:
        nearest_nonzero = torch.where(
            grouped_weight >= 0, grouped_scales, -grouped_scales
        )
        quantized[rounded_active] = nearest_nonzero.expand_as(quantized)[rounded_active]
    quantized[grouped_mask] = 0
    return quantized.reshape_as(weight), rounded_count, scales, zeros


@torch.no_grad()
def search_awq_scale(
    inspect_module: nn.Module,
    target_modules: Sequence[MyLinear],
    input_feat: torch.Tensor,
    kwargs: Dict[str, Any],
    official_pseudo_quantize_tensor,
    *,
    w_bit: int,
    group_size: int,
    n_grid: int,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """AWQ's activation-aware 20-point channel-scale search for sparse S."""

    device = next(inspect_module.parameters()).device
    x = input_feat.to(device)
    kwargs = move_tree(kwargs, device)
    original_output = tensor_output(inspect_module(x, **kwargs)).detach()
    x_max = x.abs().reshape(-1, x.shape[-1]).mean(dim=0)
    original_weights = [m.sp.weight.detach().clone() for m in target_modules]

    best_error = math.inf
    best_ratio = -1.0
    best_scales = None
    history: List[float] = []
    correction_history: List[int] = []

    try:
        for grid_idx in range(n_grid):
            ratio = grid_idx / n_grid
            scales = x_max.pow(ratio).clamp(min=1e-4).reshape(-1)
            scales = scales / torch.sqrt(scales.max() * scales.min())
            rounded_count = 0
            for module, original in zip(target_modules, original_weights):
                scaled = original * scales.reshape(1, -1).to(original)
                quantized, corrected, _, _ = mask_preserving_awq_quant(
                    scaled,
                    official_pseudo_quantize_tensor,
                    w_bit=w_bit,
                    group_size=group_size,
                )
                rounded_count += corrected
                module.sp.weight.data.copy_(
                    quantized / scales.reshape(1, -1).to(quantized)
                )

            candidate = tensor_output(inspect_module(x, **kwargs))
            error = float(
                (candidate.float() - original_output.float()).pow(2).mean().item()
            )
            history.append(error)
            correction_history.append(rounded_count)
            if error < best_error:
                best_error = error
                best_ratio = ratio
                best_scales = scales.detach().clone()
            for module, original in zip(target_modules, original_weights):
                module.sp.weight.data.copy_(original)
            del candidate
    finally:
        for module, original in zip(target_modules, original_weights):
            module.sp.weight.data.copy_(original)

    if best_scales is None or best_ratio < 0:
        raise RuntimeError(f"AWQ scale search failed; history={history}")
    if torch.isnan(best_scales).any():
        raise RuntimeError("AWQ scale search produced NaN scales")
    del x, original_output, original_weights
    return best_scales.detach(), {
        "best_ratio": best_ratio,
        "best_error": best_error,
        "history": history,
        "rounded_active_history": correction_history,
    }


@torch.no_grad()
def module_equivalence(
    modules: Sequence[MyLinear],
    before_input: torch.Tensor,
    after_input: torch.Tensor,
    before_outputs: Sequence[torch.Tensor],
) -> Dict[str, float]:
    max_abs = 0.0
    numerator = 0.0
    denominator = 0.0
    for module, reference in zip(modules, before_outputs):
        current = module(after_input).float()
        reference = reference.to(current.device).float()
        difference = current - reference
        max_abs = max(max_abs, float(difference.abs().max().item()))
        numerator += float(difference.pow(2).sum().item())
        denominator += float(reference.float().pow(2).sum().item())
    return {
        "max_abs": max_abs,
        "relative_mse": numerator / max(denominator, 1e-30),
    }


@torch.no_grad()
def apply_norm_to_residue_scale(
    norm: nn.Module,
    modules: Sequence[MyLinear],
    scales: torch.Tensor,
) -> None:
    norm_scale = scales.to(norm.weight)
    norm.weight.div_(norm_scale)
    if getattr(norm, "bias", None) is not None:
        norm.bias.div_(norm_scale)
    for module in modules:
        scale = scales.to(module.sp.weight).reshape(1, -1)
        module.sp.weight.mul_(scale)
        module.lr.l1.weight.mul_(scale)
        module.sp._weight_ss = None


@torch.no_grad()
def apply_residue_to_residue_scale(
    previous: MyLinear,
    target: MyLinear,
    scales: torch.Tensor,
) -> None:
    previous_scale = scales.to(previous.sp.weight).reshape(-1, 1)
    previous.sp.weight.div_(previous_scale)
    previous.lr.l2.weight.div_(previous_scale)
    if previous.bias is not None:
        previous.bias.div_(scales.to(previous.bias))
    previous.sp._weight_ss = None

    target_scale = scales.to(target.sp.weight).reshape(1, -1)
    target.sp.weight.mul_(target_scale)
    target.lr.l1.weight.mul_(target_scale)
    target.sp._weight_ss = None


@torch.no_grad()
def auto_clip_sparse_layer(
    weight: torch.Tensor,
    input_feat: torch.Tensor,
    official_pseudo_quantize_tensor,
    *,
    w_bit: int,
    group_size: int,
    n_grid: int,
    max_shrink: float,
    n_sample_token: int,
) -> torch.Tensor:
    """Official AWQ clipping search with fixed-mask fake quantization."""

    original_shape = weight.shape
    features = input_feat.reshape(-1, input_feat.shape[-1])
    features = features.reshape(1, features.shape[0], -1, group_size)
    stride = max(1, features.shape[1] // n_sample_token)
    features = features[:, 0::stride]
    grouped_weight = weight.reshape(weight.shape[0], 1, -1, group_size)

    output_batch = 256 if weight.shape[0] % 256 == 0 else 64
    if weight.shape[0] % output_batch:
        raise ValueError(
            f"Output dimension {weight.shape[0]} is not divisible by {output_batch}"
        )
    all_best: List[torch.Tensor] = []
    for batch_idx in range(weight.shape[0] // output_batch):
        current_weight = grouped_weight[
            batch_idx * output_batch : (batch_idx + 1) * output_batch
        ]
        original_max = current_weight.abs().amax(dim=-1, keepdim=True)
        best_max = original_max.clone()
        # The official code uses ``ones_like * 1e9`` as an infinity sentinel.
        # ``full_like(..., 1e9)`` raises on newer Torch because FP16 cannot
        # represent 1e9, so spell the same sentinel as infinity explicitly.
        min_errors = torch.full_like(original_max, float("inf"))
        device_features = features.to(current_weight.device)
        original_output = (device_features * current_weight).sum(dim=-1)

        for shrink_idx in range(int(max_shrink * n_grid)):
            max_value = original_max * (1 - shrink_idx / n_grid)
            clipped = torch.clamp(current_weight, -max_value, max_value)
            flat = clipped.reshape(-1, original_shape[1])
            quantized, _, _, _ = mask_preserving_awq_quant(
                flat,
                official_pseudo_quantize_tensor,
                w_bit=w_bit,
                group_size=group_size,
            )
            quantized = quantized.reshape_as(current_weight)
            candidate_output = (device_features * quantized).sum(dim=-1)
            errors = (
                (candidate_output - original_output)
                .pow(2)
                .mean(dim=1)
                .reshape_as(min_errors)
            )
            better = errors < min_errors
            min_errors[better] = errors[better]
            best_max[better] = max_value[better]
            del clipped, flat, quantized, candidate_output, errors
        all_best.append(best_max)
        del device_features, original_output, min_errors
    return torch.cat(all_best, dim=0).squeeze(1)


@torch.no_grad()
def apply_clip(weight: torch.Tensor, max_values: torch.Tensor) -> None:
    original_shape = weight.shape
    grouped = weight.reshape(*max_values.shape[:2], -1)
    grouped.clamp_(-max_values.to(grouped), max_values.to(grouped))
    weight.copy_(grouped.reshape(original_shape))


def capture_first_layer_input(
    model: nn.Module,
    samples: torch.Tensor,
    device: torch.device,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    layers = model.model.layers
    captured: List[torch.Tensor] = []
    layer_kwargs: Dict[str, Any] = {}

    class CatcherExit(Exception):
        pass

    class Catcher(nn.Module):
        def __init__(self, module: nn.Module):
            super().__init__()
            self.module = module

        def forward(self, hidden_states, **kwargs):
            captured.append(hidden_states.detach())
            layer_kwargs.update(kwargs)
            raise CatcherExit

    layers[0] = layers[0].to(device)
    model.model.embed_tokens = model.model.embed_tokens.to(device)
    if hasattr(model.model, "rotary_emb"):
        model.model.rotary_emb = model.model.rotary_emb.to(device)
    layers[0] = Catcher(layers[0])
    try:
        model(samples.to(device))
    except CatcherExit:
        pass
    finally:
        layers[0] = layers[0].module
    if not captured:
        raise RuntimeError("Failed to capture input to decoder layer 0")
    layers[0] = layers[0].cpu()
    model.model.embed_tokens = model.model.embed_tokens.cpu()
    if hasattr(model.model, "rotary_emb"):
        model.model.rotary_emb = model.model.rotary_emb.cpu()
    return captured[0], layer_kwargs


def capture_projection_inputs(
    layer: nn.Module,
    layer_input: torch.Tensor,
    layer_kwargs: Dict[str, Any],
) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    features: Dict[str, torch.Tensor] = {}
    handles = []

    def hook(name: str):
        def save_input(_module, args):
            features[name] = args[0].detach().cpu()

        return save_input

    for name in (
        "self_attn.q_proj",
        "self_attn.o_proj",
        "mlp.gate_proj",
        "mlp.down_proj",
    ):
        handles.append(layer.get_submodule(name).register_forward_pre_hook(hook(name)))
    try:
        output = tensor_output(layer(layer_input, **layer_kwargs)).detach()
    finally:
        for handle in handles:
            handle.remove()
    missing = set((
        "self_attn.q_proj",
        "self_attn.o_proj",
        "mlp.gate_proj",
        "mlp.down_proj",
    )) - set(features)
    if missing:
        raise RuntimeError(f"Failed to capture projection inputs: {sorted(missing)}")
    return output, features


def probe_outputs(modules: Sequence[MyLinear], features: torch.Tensor) -> List[torch.Tensor]:
    probe = features.reshape(-1, features.shape[-1])[:32]
    return [module(probe).detach().cpu() for module in modules]


def process_layer(
    layer_idx: int,
    layer: nn.Module,
    features: Dict[str, torch.Tensor],
    layer_kwargs: Dict[str, Any],
    official_pseudo_quantize_tensor,
    args: argparse.Namespace,
) -> Tuple[Dict[str, Any], List[QuantStats]]:
    started = time.time()
    modules = {
        name: require_residue(layer.get_submodule(name), name)
        for name in PROJECTION_NAMES
    }
    result: Dict[str, Any] = {"layer": layer_idx, "scales": {}, "clips": {}}

    groups = [
        (
            "attention_qkv",
            layer.self_attn,
            [modules["self_attn.q_proj"], modules["self_attn.k_proj"], modules["self_attn.v_proj"]],
            features["self_attn.q_proj"],
            layer_kwargs,
            layer.input_layernorm,
            None,
        ),
        (
            "attention_output",
            modules["self_attn.o_proj"],
            [modules["self_attn.o_proj"]],
            features["self_attn.o_proj"],
            {},
            None,
            modules["self_attn.v_proj"],
        ),
        (
            "mlp_gate_up",
            layer.mlp,
            [modules["mlp.gate_proj"], modules["mlp.up_proj"]],
            features["mlp.gate_proj"],
            {},
            layer.post_attention_layernorm,
            None,
        ),
        (
            "mlp_down",
            modules["mlp.down_proj"],
            [modules["mlp.down_proj"]],
            features["mlp.down_proj"],
            {},
            None,
            modules["mlp.up_proj"],
        ),
    ]

    scaled_features: Dict[str, torch.Tensor] = {}
    for group_name, inspect_module, targets, feature, kwargs, norm, previous in groups:
        scales, search = search_awq_scale(
            inspect_module,
            targets,
            feature,
            kwargs,
            official_pseudo_quantize_tensor,
            w_bit=args.w_bit,
            group_size=args.q_group_size,
            n_grid=args.scale_grid,
        )
        probe = feature.reshape(-1, feature.shape[-1])[:32].to(next(targets[0].parameters()).device)
        before = [target(probe).detach().cpu() for target in targets]
        if norm is not None:
            apply_norm_to_residue_scale(norm, targets, scales)
        else:
            if previous is None or len(targets) != 1:
                raise AssertionError(group_name)
            apply_residue_to_residue_scale(previous, targets[0], scales)
        after_probe = probe / scales.to(probe).reshape(1, -1)
        equivalence = module_equivalence(targets, probe, after_probe, before)
        scale_shape = (1,) * (feature.ndim - 1) + (-1,)
        scaled = feature / scales.cpu().to(feature).reshape(scale_shape)
        if group_name == "attention_qkv":
            for name in ("self_attn.q_proj", "self_attn.k_proj", "self_attn.v_proj"):
                scaled_features[name] = scaled
        elif group_name == "attention_output":
            scaled_features["self_attn.o_proj"] = scaled
        elif group_name == "mlp_gate_up":
            for name in ("mlp.gate_proj", "mlp.up_proj"):
                scaled_features[name] = scaled
        elif group_name == "mlp_down":
            scaled_features["mlp.down_proj"] = scaled
        result["scales"][group_name] = {
            **search,
            "min": float(scales.min().item()),
            "max": float(scales.max().item()),
            "equivalence": equivalence,
        }
        print(
            f"[layer {layer_idx:02d}] scale {group_name}: "
            f"ratio={search['best_ratio']:.2f} mse={search['best_error']:.6e} "
            f"equiv_rel_mse={equivalence['relative_mse']:.3e}",
            flush=True,
        )
        del probe, before, after_probe

    if not args.skip_clip:
        for name, module in modules.items():
            if any(token in name for token in ("q_", "k_", "query", "key", "Wqkv")):
                result["clips"][name] = {"skipped": True, "reason": "official_qk_skip"}
                continue
            clip_started = time.time()
            max_values = auto_clip_sparse_layer(
                module.sp.weight,
                scaled_features[name].to(module.sp.weight.device),
                official_pseudo_quantize_tensor,
                w_bit=args.w_bit,
                group_size=args.q_group_size,
                n_grid=args.clip_grid,
                max_shrink=args.clip_max_shrink,
                n_sample_token=args.clip_sample_tokens,
            )
            before = module.sp.weight.detach().clone()
            apply_clip(module.sp.weight, max_values)
            module.sp._weight_ss = None
            changed = int((before != module.sp.weight).sum().item())
            result["clips"][name] = {
                "skipped": False,
                "changed_weights": changed,
                "max_value_min": float(max_values.min().item()),
                "max_value_max": float(max_values.max().item()),
                "seconds": time.time() - clip_started,
            }
            print(
                f"[layer {layer_idx:02d}] clip {name}: changed={changed} "
                f"seconds={time.time() - clip_started:.1f}",
                flush=True,
            )
            del before, max_values

    quant_stats: List[QuantStats] = []
    for name, module in modules.items():
        original = module.sp.weight.detach().clone()
        original_mask = original.eq(0)
        quantized, rounded_count, _, _ = mask_preserving_awq_quant(
            original,
            official_pseudo_quantize_tensor,
            w_bit=args.w_bit,
            group_size=args.q_group_size,
        )
        module.sp.weight.data.copy_(quantized)
        module.sp._weight_ss = None
        groups_2_4, violations = count_2_4(module.sp.weight)
        stat = QuantStats(
            layer=layer_idx,
            name=name,
            numel=original.numel(),
            active=int((~original_mask).sum().item()),
            rounded_active_to_zero_before_projection=rounded_count,
            mask_equal=bool(torch.equal(original_mask, module.sp.weight.eq(0))),
            groups_2_4=groups_2_4,
            violations_2_4=violations,
            mse=float((original.float() - quantized.float()).pow(2).mean().item()),
            max_abs_error=float((original.float() - quantized.float()).abs().max().item()),
        )
        quant_stats.append(stat)
        print(
            f"[layer {layer_idx:02d}] quant {name}: "
            f"mask_equal={stat.mask_equal} violations={violations} "
            f"projected={rounded_count} mse={stat.mse:.6e}",
            flush=True,
        )
        del original, original_mask, quantized

    result["seconds"] = time.time() - started
    return result, quant_stats


def main() -> None:
    args = parse_args()
    if args.w_bit != 4:
        raise ValueError("This experiment is specifically defined as INT4/W4")
    if args.q_group_size <= 0:
        raise ValueError("A positive group size is required")
    if args.scale_grid <= 0 or args.clip_grid <= 0:
        raise ValueError("Search grids must be positive")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for AWQ calibration/search")
    device = torch.device(args.device)
    seed_everything(args.seed)
    official_quantize, get_calib_dataset, awq_commit = import_official_awq(args.awq_repo)

    started = time.time()
    print(f"[awq] repo={args.awq_repo} commit={awq_commit}", flush=True)
    print(
        f"[config] W{args.w_bit} asymmetric group={args.q_group_size} "
        f"PileVal samples={args.n_samples} seqlen={args.seqlen} dtype={args.dtype}",
        flush=True,
    )
    model, tokenizer, source_checkpoint = _load_residue_model(
        args.model, args.checkpoint, args.dtype
    )
    model.eval()
    model.config.use_cache = False
    source_metadata = {
        key: value for key, value in source_checkpoint.items() if key != "state_dict"
    }
    del source_checkpoint
    gc.collect()

    ranks = set()
    initial_violations = 0
    initial_groups = 0
    for layer_idx, layer in enumerate(model.model.layers):
        for name in PROJECTION_NAMES:
            module = require_residue(layer.get_submodule(name), f"{layer_idx}.{name}")
            ranks.add(int(module.lr.rank))
            groups, violations = count_2_4(module.sp.weight)
            initial_groups += groups
            initial_violations += violations
    if len(ranks) != 1 or not ranks.issubset({32, 128}):
        raise ValueError(f"Expected uniform rank 32 or 128, found ranks={sorted(ranks)}")
    rank = next(iter(ranks))
    if initial_violations:
        raise ValueError(
            f"Input checkpoint is not strict 2:4: {initial_violations}/{initial_groups}"
        )

    calibration = get_calib_dataset(
        data="pileval",
        tokenizer=tokenizer,
        n_samples=args.n_samples,
        block_size=args.seqlen,
    )
    if not calibration:
        raise RuntimeError("Official PileVal calibration produced zero blocks")
    samples = torch.cat(calibration, dim=0)
    print(f"[calibration] token_blocks={tuple(samples.shape)}", flush=True)
    layer_input, layer_kwargs = capture_first_layer_input(model, samples, device)
    del samples, calibration
    gc.collect()
    torch.cuda.empty_cache()

    total_layers = len(model.model.layers)
    layers_to_process = total_layers if args.max_layers <= 0 else min(args.max_layers, total_layers)
    layer_results: List[Dict[str, Any]] = []
    quant_stats: List[QuantStats] = []
    for layer_idx in range(layers_to_process):
        layer_started = time.time()
        layer = model.model.layers[layer_idx].to(device)
        layer_input = layer_input.to(device)
        next_input, features = capture_projection_inputs(
            layer, layer_input, move_tree(layer_kwargs, device)
        )
        result, stats = process_layer(
            layer_idx,
            layer,
            features,
            move_tree(layer_kwargs, device),
            official_quantize,
            args,
        )
        layer_results.append(result)
        quant_stats.extend(stats)
        model.model.layers[layer_idx] = layer.cpu()
        layer_input = next_input
        del layer, next_input, features
        gc.collect()
        torch.cuda.empty_cache()
        elapsed = time.time() - started
        rate = elapsed / (layer_idx + 1)
        eta = rate * (layers_to_process - layer_idx - 1)
        print(
            f"[progress] {layer_idx + 1}/{layers_to_process} "
            f"layer_seconds={time.time() - layer_started:.1f} "
            f"elapsed={elapsed / 60:.1f}m eta={eta / 60:.1f}m",
            flush=True,
        )

    mask_equal = all(stat.mask_equal for stat in quant_stats)
    final_violations = sum(stat.violations_2_4 for stat in quant_stats)
    final_groups = sum(stat.groups_2_4 for stat in quant_stats)
    report = {
        "experiment": f"mask-preserving AWQ sparse-W4 + FP16 low-rank r{rank}",
        "rank": rank,
        "accuracy_only_fake_quantization": True,
        "real_int4_kernel": False,
        "model": str(args.model),
        "source_checkpoint": str(args.checkpoint),
        "output_checkpoint": str(args.output_checkpoint) if args.output_checkpoint else None,
        "awq_repo": str(args.awq_repo),
        "awq_commit": awq_commit,
        "official_algorithm_components": {
            "calibration": "mit-han-lab/pile-val-backup, shuffle seed 42",
            "scale_search": True,
            "clipping_search": not args.skip_clip,
            "fake_quantizer": "official asymmetric per-group min/max",
        },
        "adapter": {
            "quantized_branch": "2:4 sparse branch S",
            "low_rank_branch": "FP16 A/B",
            "fixed_mask_projection": True,
            "reason": "official quantization rounds active 2:4 entries to exact zero",
        },
        "config": vars(args) | {
            "checkpoint": str(args.checkpoint),
            "awq_repo": str(args.awq_repo),
            "output_checkpoint": str(args.output_checkpoint) if args.output_checkpoint else None,
            "output_json": str(args.output_json),
        },
        "input_mask": {
            "groups": initial_groups,
            "violations": initial_violations,
        },
        "output_mask_processed_layers": {
            "groups": final_groups,
            "violations": final_violations,
            "all_masks_equal": mask_equal,
        },
        "layers_processed": layers_to_process,
        "layers_total": total_layers,
        "layer_results": layer_results,
        "quantization_stats": [asdict(stat) for stat in quant_stats],
        "seconds": time.time() - started,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")

    if args.output_checkpoint is not None:
        if layers_to_process != total_layers:
            raise ValueError("Refusing to save a partially AWQ-processed checkpoint")
        if not mask_equal or final_violations:
            raise RuntimeError(
                f"Refusing to save: mask_equal={mask_equal}, violations={final_violations}"
            )
        args.output_checkpoint.parent.mkdir(parents=True, exist_ok=True)
        payload = dict(source_metadata)
        payload["state_dict"] = model.state_dict()
        payload["quantization"] = {
            "method": "AWQ",
            "scope": "mask-preserving sparse branch W4; low-rank factors FP16",
            "w_bit": args.w_bit,
            "q_group_size": args.q_group_size,
            "zero_point": True,
            "fake_quantization": True,
            "awq_commit": awq_commit,
            "report": str(args.output_json),
        }
        torch.save(payload, args.output_checkpoint)
        print(f"[saved] {args.output_checkpoint}", flush=True)

    print(
        f"[done] layers={layers_to_process}/{total_layers} "
        f"mask_equal={mask_equal} violations={final_violations}/{final_groups} "
        f"seconds={time.time() - started:.1f}",
        flush=True,
    )


if __name__ == "__main__":
    main()
