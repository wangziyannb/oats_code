#!/usr/bin/env python3
"""Accuracy-only group-wise INT4 weight-only evaluation for dense and Residue Pruning models.

This script intentionally does not benchmark quantized throughput or memory.
It stores signed INT4 values in int8 tensors plus per-group scales, and uses a
dequantized matmul path for reproducible PPL/CMQA quality checks.
"""

import argparse
import importlib.util
import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from addict import Dict as AddictDict
from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer

from lib.eval import eval_ppl, lm_simple_eval
from lib.prune import MyLinear, MyLowRankBranch, MySparseLinear
from main import replace_llama_linears


CMQA_TASKS = [
    "openbookqa",
    "arc_easy",
    "winogrande",
    "hellaswag",
    "arc_challenge",
    "piqa",
    "boolq",
]


@dataclass
class QuantizeStats:
    name: str
    shape: Tuple[int, int]
    group_size: int
    preserve_zero_mask: bool
    numel: int
    original_zeros: int
    quantized_zeros: int
    zero_mask_equal: Optional[bool]
    max_abs_error: float
    mean_abs_error: float
    num_2_4_groups: Optional[int] = None
    num_2_4_violations: Optional[int] = None


def _dtype_from_name(dtype_name: str, model_path: str) -> torch.dtype:
    dtype_name = str(dtype_name).lower()
    if dtype_name in ("fp16", "float16", "half"):
        return torch.float16
    if dtype_name in ("bf16", "bfloat16"):
        return torch.bfloat16
    if dtype_name in ("auto", ""):
        return _dtype_from_config(model_path)
    raise ValueError(f"Unsupported --dtype={dtype_name!r}")


def _dtype_from_config(model_path: str) -> torch.dtype:
    config = AutoConfig.from_pretrained(model_path)
    # Qwen checkpoints in this repo have been evaluated in BF16. Llama2 uses FP16.
    return torch.bfloat16 if config.model_type == "qwen3" else torch.float16


def _model_kwargs(
    model_path: str,
    dtype_name: str,
    attn_implementation: str = "eager",
) -> Dict:
    config = AutoConfig.from_pretrained(model_path)
    del config
    kwargs = {"torch_dtype": _dtype_from_name(dtype_name, model_path), "low_cpu_mem_usage": True}
    # Use eager attention for reproducible accuracy evaluation.  Some fused/SDPA
    # paths have shown intermittent illegal-memory-access failures during
    # long lm-eval runs on this machine, and this experiment is not about speed.
    kwargs["attn_implementation"] = attn_implementation
    return kwargs


def _load_tokenizer(model_path: str, checkpoint_path: Optional[Path] = None):
    tok_src = Path(model_path)
    if checkpoint_path is not None and (checkpoint_path.parent / "tokenizer_config.json").exists():
        tok_src = checkpoint_path.parent
    tokenizer = AutoTokenizer.from_pretrained(tok_src, use_fast=False)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return tokenizer


def _load_dense_model(
    model_path: str,
    dtype_name: str,
    attn_implementation: str = "eager",
):
    tokenizer = _load_tokenizer(model_path)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        **_model_kwargs(model_path, dtype_name, attn_implementation),
    )
    model.seqlen = 2048
    return model, tokenizer


def _load_residue_model(
    model_path: str,
    checkpoint_path: Path,
    dtype_name: str,
    attn_implementation: str = "eager",
):
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    tokenizer = _load_tokenizer(model_path, checkpoint_path)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        **_model_kwargs(model_path, dtype_name, attn_implementation),
    )
    model.seqlen = 2048
    replace_llama_linears(
        model,
        rank_k=int(checkpoint["rank_k"]),
        sparsity_type=str(checkpoint.get("sparsity_type", "2:4")),
        use_semi_structured=False,
    )
    load_result = model.load_state_dict(checkpoint["state_dict"], strict=False)
    print(
        f"[load_residue] missing={len(load_result.missing_keys)} "
        f"unexpected={len(load_result.unexpected_keys)}",
        flush=True,
    )
    if load_result.missing_keys or load_result.unexpected_keys:
        print(f"[missing] {load_result.missing_keys[:20]}", flush=True)
        print(f"[unexpected] {load_result.unexpected_keys[:20]}", flush=True)
    return model, tokenizer, checkpoint


def _pad_last_dim(weight: torch.Tensor, group_size: int) -> Tuple[torch.Tensor, int]:
    in_features = weight.shape[1]
    pad = (-in_features) % group_size
    if pad == 0:
        return weight, 0
    return F.pad(weight, (0, pad), mode="constant", value=0), pad


def _count_2_4_violations(zero_mask: torch.Tensor) -> Tuple[int, int]:
    if zero_mask.dim() != 2 or zero_mask.shape[1] % 4 != 0:
        return 0, 0
    groups = zero_mask.reshape(zero_mask.shape[0], zero_mask.shape[1] // 4, 4)
    zeros_per_group = groups.sum(dim=-1)
    violations = (zeros_per_group != 2).sum().item()
    return zeros_per_group.numel(), int(violations)


def quantize_weight_int4(
    weight: torch.Tensor,
    *,
    group_size: int,
    preserve_zero_mask: bool,
) -> Tuple[torch.Tensor, torch.Tensor, Optional[torch.Tensor], QuantizeStats]:
    """Return qweight int8 in signed INT4 range [-8, 7], scales, original zero mask, and stats."""
    if weight.dim() != 2:
        raise ValueError(f"Expected 2D weight, got shape={tuple(weight.shape)}")
    if group_size <= 0:
        raise ValueError("--group_size must be positive")

    original = weight.detach().cpu()
    original_dtype = original.dtype
    original_float = original.float()
    out_features, in_features = original.shape
    padded, pad = _pad_last_dim(original_float, group_size)
    groups = padded.reshape(out_features, -1, group_size)
    max_abs = groups.abs().amax(dim=-1)
    scales = (max_abs / 7.0).clamp(min=1e-8)
    q = torch.round(groups / scales.unsqueeze(-1)).clamp(-8, 7).to(torch.int8)

    zero_mask = None
    if preserve_zero_mask:
        zero_mask = original.eq(0)
        padded_zero_mask, _ = _pad_last_dim(zero_mask, group_size)
        grouped_zero_mask = padded_zero_mask.reshape(out_features, -1, group_size)
        q[grouped_zero_mask] = 0

        # Preserve the exact mask: nonzero source entries must not become zero after rounding.
        nonzero_mask = ~grouped_zero_mask
        rounded_to_zero = nonzero_mask & (q == 0)
        if rounded_to_zero.any():
            signs = torch.where(groups >= 0, torch.ones_like(q), -torch.ones_like(q))
            q[rounded_to_zero] = signs[rounded_to_zero].to(torch.int8)

    q = q.reshape(out_features, -1)
    if pad:
        q = q[:, :-pad]
    q = q.contiguous()
    scales = scales.to(dtype=torch.float16).contiguous()

    scale_expanded = scales.float().repeat_interleave(group_size, dim=1)[:, :in_features]
    dequant = (q.float() * scale_expanded).to(original_dtype)
    abs_err = (dequant.float() - original_float).abs()

    q_zero_mask = q.eq(0)
    zero_mask_equal = None
    groups_2_4 = None
    violations_2_4 = None
    if zero_mask is not None:
        zero_mask_equal = bool(torch.equal(q_zero_mask, zero_mask))
        groups_2_4, violations_2_4 = _count_2_4_violations(q_zero_mask)

    stats = QuantizeStats(
        name="",
        shape=(int(out_features), int(in_features)),
        group_size=int(group_size),
        preserve_zero_mask=bool(preserve_zero_mask),
        numel=int(original.numel()),
        original_zeros=int(original.eq(0).sum().item()),
        quantized_zeros=int(q_zero_mask.sum().item()),
        zero_mask_equal=zero_mask_equal,
        max_abs_error=float(abs_err.max().item()) if abs_err.numel() else 0.0,
        mean_abs_error=float(abs_err.mean().item()) if abs_err.numel() else 0.0,
        num_2_4_groups=groups_2_4,
        num_2_4_violations=violations_2_4,
    )
    return q, scales, zero_mask, stats


class Int4WeightOnlyLinear(nn.Module):
    """INT4 weight-only module with accuracy-only dequantized matmul."""

    def __init__(
        self,
        qweight: torch.Tensor,
        scales: torch.Tensor,
        *,
        group_size: int,
        bias: Optional[torch.Tensor],
        compute_dtype: torch.dtype,
        zero_mask: Optional[torch.Tensor] = None,
        cache_dequant: bool = True,
    ):
        super().__init__()
        if qweight.dim() != 2:
            raise ValueError(f"qweight must be 2D, got {tuple(qweight.shape)}")
        self.out_features = int(qweight.shape[0])
        self.in_features = int(qweight.shape[1])
        self.group_size = int(group_size)
        self.compute_dtype = compute_dtype
        self.cache_dequant = bool(cache_dequant)
        self.register_buffer("qweight", qweight.to(torch.int8).contiguous())
        self.register_buffer("scales", scales.contiguous())
        if zero_mask is not None:
            self.register_buffer("zero_mask", zero_mask.to(torch.bool).contiguous(), persistent=False)
        else:
            self.zero_mask = None
        if bias is not None:
            self.register_buffer("bias", bias.detach().cpu().to(compute_dtype).contiguous())
        else:
            self.bias = None
        self.register_buffer("_dequant_weight", torch.empty(0, dtype=compute_dtype), persistent=False)
        if self.cache_dequant:
            self.refresh_dequant_cache()

    @classmethod
    def from_linear(
        cls,
        linear: nn.Linear,
        *,
        group_size: int,
        preserve_zero_mask: bool,
        cache_dequant: bool,
    ) -> Tuple["Int4WeightOnlyLinear", QuantizeStats]:
        qweight, scales, zero_mask, stats = quantize_weight_int4(
            linear.weight,
            group_size=group_size,
            preserve_zero_mask=preserve_zero_mask,
        )
        mod = cls(
            qweight,
            scales,
            group_size=group_size,
            bias=linear.bias,
            compute_dtype=linear.weight.dtype,
            zero_mask=zero_mask,
            cache_dequant=cache_dequant,
        )
        return mod, stats

    @classmethod
    def from_weight(
        cls,
        weight: torch.Tensor,
        *,
        bias: Optional[torch.Tensor],
        group_size: int,
        preserve_zero_mask: bool,
        cache_dequant: bool,
    ) -> Tuple["Int4WeightOnlyLinear", QuantizeStats]:
        qweight, scales, zero_mask, stats = quantize_weight_int4(
            weight,
            group_size=group_size,
            preserve_zero_mask=preserve_zero_mask,
        )
        mod = cls(
            qweight,
            scales,
            group_size=group_size,
            bias=bias,
            compute_dtype=weight.dtype,
            zero_mask=zero_mask,
            cache_dequant=cache_dequant,
        )
        return mod, stats

    def dequantize_weight(self) -> torch.Tensor:
        scale_expanded = self.scales.float().repeat_interleave(self.group_size, dim=1)[:, : self.in_features]
        return (self.qweight.float() * scale_expanded).to(dtype=self.compute_dtype)

    @torch.no_grad()
    def refresh_dequant_cache(self) -> None:
        self._dequant_weight = self.dequantize_weight().contiguous()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.cache_dequant and self._dequant_weight.numel() != 0:
            weight = self._dequant_weight
        else:
            weight = self.dequantize_weight()
        if weight.device != x.device:
            weight = weight.to(x.device)
        if weight.dtype != x.dtype:
            weight = weight.to(x.dtype)
        bias = self.bias
        if bias is not None and (bias.device != x.device or bias.dtype != x.dtype):
            bias = bias.to(device=x.device, dtype=x.dtype)
        return F.linear(x, weight, bias)


def _target_linears(model) -> Iterable[Tuple[str, nn.Module, str, nn.Linear]]:
    layers = model.model.layers
    for layer_idx, layer in enumerate(layers):
        attn = layer.self_attn
        for name in ["q_proj", "k_proj", "v_proj", "o_proj"]:
            module = getattr(attn, name)
            if isinstance(module, nn.Linear):
                yield f"model.layers.{layer_idx}.self_attn.{name}", attn, name, module
        mlp = layer.mlp
        for name in ["gate_proj", "up_proj", "down_proj"]:
            module = getattr(mlp, name)
            if isinstance(module, nn.Linear):
                yield f"model.layers.{layer_idx}.mlp.{name}", mlp, name, module


def quantize_dense_model(model, *, group_size: int, cache_dequant: bool) -> List[QuantizeStats]:
    stats: List[QuantizeStats] = []
    for name, parent, child_name, linear in _target_linears(model):
        quantized, st = Int4WeightOnlyLinear.from_linear(
            linear,
            group_size=group_size,
            preserve_zero_mask=False,
            cache_dequant=cache_dequant,
        )
        st.name = name
        setattr(parent, child_name, quantized)
        stats.append(st)
    return stats


def quantize_residue_model(model, *, group_size: int, cache_dequant: bool) -> List[QuantizeStats]:
    stats: List[QuantizeStats] = []
    for name, module in model.named_modules():
        if not isinstance(module, MyLinear):
            continue
        if isinstance(module.sp, MySparseLinear):
            quant_sp, st = Int4WeightOnlyLinear.from_weight(
                module.sp.weight,
                bias=None,
                group_size=group_size,
                preserve_zero_mask=True,
                cache_dequant=cache_dequant,
            )
            st.name = f"{name}.sp"
            module.sp = quant_sp
            stats.append(st)
        if isinstance(module.lr, MyLowRankBranch) and module.lr.rank > 0:
            quant_l1, st_l1 = Int4WeightOnlyLinear.from_linear(
                module.lr.l1,
                group_size=group_size,
                preserve_zero_mask=False,
                cache_dequant=cache_dequant,
            )
            st_l1.name = f"{name}.lr.l1"
            module.lr.l1 = quant_l1
            stats.append(st_l1)

            quant_l2, st_l2 = Int4WeightOnlyLinear.from_linear(
                module.lr.l2,
                group_size=group_size,
                preserve_zero_mask=False,
                cache_dequant=cache_dequant,
            )
            st_l2.name = f"{name}.lr.l2"
            module.lr.l2 = quant_l2
            stats.append(st_l2)
    return stats


def summarize_quant_stats(stats: List[QuantizeStats]) -> Dict:
    sparse_stats = [s for s in stats if s.name.endswith(".sp")]
    report = {
        "num_quantized_tensors": len(stats),
        "num_quantized_params": int(sum(s.numel for s in stats)),
        "max_abs_error_max": max((s.max_abs_error for s in stats), default=0.0),
        "mean_abs_error_param_weighted": (
            sum(s.mean_abs_error * s.numel for s in stats) / max(1, sum(s.numel for s in stats))
        ),
        "sparse_branch_tensors": len(sparse_stats),
        "sparse_branch_mask_equal_all": all(s.zero_mask_equal is True for s in sparse_stats) if sparse_stats else None,
        "sparse_branch_2_4_groups": int(sum(s.num_2_4_groups or 0 for s in sparse_stats)),
        "sparse_branch_2_4_violations": int(sum(s.num_2_4_violations or 0 for s in sparse_stats)),
    }
    return report


def write_quant_report(output: Path, mode: str, group_size: int, stats: List[QuantizeStats]) -> None:
    report = {
        "mode": mode,
        "group_size": group_size,
        "quantizer": "custom_groupwise_symmetric_signed_int4_weight_only_accuracy_path",
        "qrange": [-8, 7],
        "awq_available": importlib.util.find_spec("awq") is not None
        or importlib.util.find_spec("autoawq") is not None,
        "gptq_available": importlib.util.find_spec("auto_gptq") is not None
        or importlib.util.find_spec("gptqmodel") is not None,
        "summary": summarize_quant_stats(stats),
        "tensors": [asdict(s) for s in stats],
    }
    (output / "quant_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("[quant_report]", json.dumps(report["summary"], indent=2), flush=True)


def extract_cmqa_accuracy(path: Path) -> Dict:
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    task_acc = {}
    for task, values in data.get("results", {}).items():
        if "acc_norm,none" in values:
            task_acc[task] = float(values["acc_norm,none"])
        elif "acc,none" in values:
            task_acc[task] = float(values["acc,none"])
    avg = sum(task_acc.values()) / len(task_acc) if task_acc else None
    return {"cmqa_acc": avg, "cmqa_task_acc": task_acc}


def evaluate(model, tokenizer, *, output: Path, device: str, skip_ppl: bool, skip_cmqa: bool, batch_size: int) -> Dict:
    output.mkdir(parents=True, exist_ok=True)
    model.to(device).eval()
    model.seqlen = 2048

    metrics: Dict = {}
    if not skip_ppl:
        class EvalArgs:
            pass

        ppl = eval_ppl(EvalArgs(), model, tokenizer, torch.device(device))
        metrics["wikitext2_ppl"] = float(ppl)
        (output / "ppl.json").write_text(json.dumps({"ppl": float(ppl), "dataset": "wikitext2", "seqlen": 128}, indent=2))
        print(f"[result] wikitext2_ppl={ppl:.8f}", flush=True)

    if not skip_cmqa:
        options = AddictDict(
            {
                "output_path": str(output),
                "tasks": CMQA_TASKS,
                "num_fewshot": [0],
                "max_length": 4096,
                "batch_size": batch_size,
                "apply_chat_template": False,
                "fewshot_as_multiturn": False,
                "enable_thinking": False,
            }
        )
        lm_simple_eval(options, model, tokenizer, "cmqa_zero_shot_result")
        metrics.update(extract_cmqa_accuracy(output / "None_cmqa_zero_shot_result.json"))
        print("[done] CMQA zero-shot evaluation completed", flush=True)

    return metrics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True, choices=["dense_fp", "dense_int4", "residue_fp", "residue_int4"])
    parser.add_argument("--model", required=True)
    parser.add_argument("--checkpoint", default=None, help="Required for residue_fp/residue_int4.")
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--group_size", type=int, default=128)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument(
        "--dtype",
        default="auto",
        choices=["auto", "float16", "bfloat16", "fp16", "bf16"],
        help="Compute dtype for loading the FP/dequantized model.",
    )
    parser.add_argument("--skip_ppl", action="store_true")
    parser.add_argument("--skip_cmqa", action="store_true")
    parser.add_argument("--no_cache_dequant", action="store_true")
    args = parser.parse_args()

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    cache_dequant = not args.no_cache_dequant

    if args.mode.startswith("dense"):
        model, tokenizer = _load_dense_model(args.model, args.dtype)
        checkpoint_meta = None
    else:
        if args.checkpoint is None:
            raise ValueError("--checkpoint is required for residue modes")
        checkpoint_path = Path(args.checkpoint)
        if checkpoint_path.is_dir():
            checkpoint_path = checkpoint_path / "rebuildable_ckpt.pt"
        model, tokenizer, checkpoint_meta = _load_residue_model(args.model, checkpoint_path, args.dtype)

    quant_stats: List[QuantizeStats] = []
    if args.mode == "dense_int4":
        quant_stats = quantize_dense_model(model, group_size=args.group_size, cache_dequant=cache_dequant)
        write_quant_report(output, args.mode, args.group_size, quant_stats)
    elif args.mode == "residue_int4":
        quant_stats = quantize_residue_model(model, group_size=args.group_size, cache_dequant=cache_dequant)
        write_quant_report(output, args.mode, args.group_size, quant_stats)

    metrics = evaluate(
        model,
        tokenizer,
        output=output,
        device=args.device,
        skip_ppl=args.skip_ppl,
        skip_cmqa=args.skip_cmqa,
        batch_size=args.batch_size,
    )

    metrics.update(
        {
            "mode": args.mode,
            "model": args.model,
            "checkpoint": args.checkpoint,
            "group_size": args.group_size if "int4" in args.mode else None,
            "dtype": str(_dtype_from_name(args.dtype, args.model)).replace("torch.", ""),
            "quantized_tensors": len(quant_stats),
        }
    )
    if checkpoint_meta is not None:
        metrics["checkpoint_rank_k"] = int(checkpoint_meta.get("rank_k", -1))
        metrics["checkpoint_sparsity_type"] = str(checkpoint_meta.get("sparsity_type", ""))
        metrics["checkpoint_prune_method"] = str(checkpoint_meta.get("prune_method", ""))
    (output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print("[metrics]", json.dumps(metrics, indent=2), flush=True)


if __name__ == "__main__":
    main()
