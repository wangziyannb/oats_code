#!/usr/bin/env python3
"""Strictly reload a post-hoc AWQ checkpoint and evaluate PPL."""
import argparse
from datetime import datetime, timezone
import gc
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import torch
from transformers import AutoTokenizer
from lib.eval import eval_ppl
from lib.prune import _set_submodule, find_layers
from scripts.run_llama2_ppl_experiment import audit_dual_model, build_composite, load_base


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', required=True)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rank_k', type=int, choices=(32, 128), required=True)
    args = parser.parse_args()
    args.device = 'cuda:0'
    args.attn_implementation = 'sdpa'
    args.seqlen = 2048
    args.ppl_seqlen = 128
    args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(4)
    started = time.monotonic()
    checkpoint = torch.load(args.checkpoint, map_location='cpu', weights_only=False)
    assert checkpoint['rank_k'] == args.rank_k
    quantization = checkpoint['quantization']
    assert quantization['fake_quantization'] is True
    assert quantization['method'] in ('AWQ', 'AWQ-style all-branch fake W4')
    model = load_base(args)
    weights = checkpoint['state_dict']
    replaced = 0
    for layer_idx, layer in enumerate(model.model.layers):
        for name, linear in find_layers(layer).items():
            prefix = f'model.layers.{layer_idx}.{name}'
            sparse = weights[prefix + '.sp.weight'].to(args.device)
            first = weights[prefix + '.lr.l1.weight'].to(args.device)
            second = weights[prefix + '.lr.l2.weight'].to(args.device)
            replacement = build_composite(sparse, first, second, linear.bias, semi=False)
            _set_submodule(layer, name, replacement)
            replaced += 1
    assert replaced == 224
    model.load_state_dict(weights, strict=True)
    audit = audit_dual_model(model, args.rank_k)
    del checkpoint, weights, sparse, first, second, replacement, linear
    gc.collect()
    torch.cuda.empty_cache()
    tokenizer = AutoTokenizer.from_pretrained(args.model, use_fast=False, local_files_only=True)
    print('[checkpoint] strict loading passed; 224 projections; 2:4 and finite-weight audit passed', flush=True)
    load_seconds = time.monotonic() - started
    started = time.monotonic()
    ppl = float(eval_ppl(args, model, tokenizer, torch.device(args.device)))
    if not torch.isfinite(torch.tensor(ppl)):
        raise RuntimeError(f'Non-finite PPL: {ppl}')
    metrics = {
        'method': ('posthoc_sparse' if quantization['method'] == 'AWQ' else 'posthoc_allbranch'), 'rank': args.rank_k,
        'sparsity_type': '2:4', 'actual_sparsity': 0.5,
        'dataset': 'wikitext-2-raw-v1/test', 'ppl_seqlen': 128, 'ppl': ppl,
        'eval_seconds': time.monotonic() - started, 'load_and_audit_seconds': load_seconds,
        'checkpoint': str(args.checkpoint.parent), 'checkpoint_strict_load': True,
        'structure_audit': audit, 'quantization': quantization,
        'finished_at': datetime.now(timezone.utc).isoformat(),
    }
    (args.output / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
    print('[result] ' + json.dumps(metrics), flush=True)


if __name__ == '__main__':
    main()
