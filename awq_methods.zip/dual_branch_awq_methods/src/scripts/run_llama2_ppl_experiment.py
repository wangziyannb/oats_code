#!/usr/bin/env python3
"""Single-GPU, PPL-only reproduction and dual-branch AWQ experiment runner."""
import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import gc
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from lib.data import get_loaders
from lib.dual_awq import AWQConfig, fit_dual_awq
from lib.eval import eval_ppl
from lib.layerwrapper import WrappedGPT
from lib.prune import (MyLinear, MyLowRankBranch, MySparseLinear, _set_submodule,
                       check_sparsity, find_layers, prepare_calibration_input,
                       prune_wanda, prune_wanda_lowrank_alt_alllinear)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def load_base(args):
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.float16, device_map={"": args.device},
        attn_implementation=args.attn_implementation, local_files_only=True,
    ).eval()
    model.seqlen = args.seqlen
    model.config.use_cache = False
    return model


def build_composite(sparse, first, second, bias=None, semi=False):
    sp = MySparseLinear.from_dense(sparse, sparsity_type="2:4",
                                  use_semi_structured=semi, keep_dense_weight=True)
    lr = MyLowRankBranch.from_factors(first, second)
    return MyLinear(sp, lr, bias=bias)


@torch.no_grad()
def audit_dual_model(model, rank):
    modules, groups, violations = 0, 0, 0
    for module in model.modules():
        if not isinstance(module, MyLinear):
            continue
        modules += 1
        if module.lr.l1.weight.shape != (rank, module.in_features):
            raise RuntimeError("Unexpected first-factor shape")
        if module.lr.l2.weight.shape != (module.out_features, rank):
            raise RuntimeError("Unexpected second-factor shape")
        for weight in (module.sp.weight, module.lr.l1.weight, module.lr.l2.weight):
            if not torch.isfinite(weight).all():
                raise RuntimeError("Non-finite compressed weights")
        zeros = (module.sp.weight == 0).reshape(module.out_features, -1, 4).sum(-1)
        groups += zeros.numel()
        violations += int((zeros != 2).sum())
    if modules != 7 * len(model.model.layers) or violations:
        raise RuntimeError(f"Dual AWQ structure audit failed: modules={modules}, 2:4 violations={violations}")
    return {"compressed_projections": modules, "groups_2of4": groups,
            "violations_2of4": violations, "all_weights_finite": True}


@torch.no_grad()
def prune_dual(args, model, tokenizer):
    config = AWQConfig(bits=args.w_bits, group_size=args.group_size,
                       grid=args.scale_grid, sparse_refresh=args.sparse_scale_refresh)
    loader, _ = get_loaders("c4", nsamples=args.nsamples, seed=args.seed,
                            seqlen=args.seqlen, tokenizer=tokenizer)
    inps, outs, attention_mask, position_ids = prepare_calibration_input(
        model, loader, args.nsamples, args.seqlen)[:4]
    metadata = {}
    with (args.output / "iterations.jsonl").open("w") as iterations_log:
        for layer_idx, layer in enumerate(model.model.layers):
            layer_start = time.monotonic()
            subset = find_layers(layer)
            wrappers = {name: WrappedGPT(module) for name, module in subset.items()}
            samples = {name: [] for name in subset}
            per_sequence = max(1, (args.awq_tokens + args.nsamples - 1) // args.nsamples)

            def make_hook(name):
                def hook(_, inp, out):
                    wrappers[name].add_batch(inp[0].detach(), out.detach())
                    flat = inp[0].detach().reshape(-1, inp[0].shape[-1])
                    indices = torch.linspace(0, flat.shape[0] - 1, per_sequence,
                                             device=flat.device).round().long()
                    samples[name].append(flat.index_select(0, indices).cpu())
                return hook

            def forward_samples():
                for j in range(args.nsamples):
                    pe = model.model.rotary_emb(inps[j], position_ids)
                    outs[j] = layer(inps[j].unsqueeze(0), attention_mask=attention_mask,
                                    position_ids=position_ids, position_embeddings=pe)[0]

            handles = [module.register_forward_hook(make_hook(name))
                       for name, module in subset.items()]
            try:
                forward_samples()
            finally:
                for handle in handles:
                    handle.remove()
            for name, linear in subset.items():
                module_start = time.monotonic()
                x = torch.cat(samples.pop(name), 0)[:args.awq_tokens].to(linear.weight.device)

                def report(record):
                    record = {"layer": layer_idx, "module": name, **record}
                    iterations_log.write(json.dumps(record) + "\n")
                    iterations_log.flush()
                    if record["iteration"] == 1 or record["iteration"] % 20 == 0 or record["stopped"]:
                        print(f"[dual-awq] layer={layer_idx} module={name} "
                              f"iter={record['iteration']} mse={record['output_mse']:.8g} "
                              f"rel_frob={record['rel_frob_err']:.8g}", flush=True)

                result = fit_dual_awq(linear.weight.detach(),
                    wrappers[name].scaler_row.sqrt().reshape(1, -1), x,
                    args.rank_k, args.alt_iters, args.alt_tol, config, report,
                    selection=args.dual_selection)
                replacement = build_composite(result["sparse"], result["first"], result["second"], linear.bias)
                _set_submodule(layer, name, replacement)
                metadata[f"model.layers.{layer_idx}.{name}"] = {
                    key: value for key, value in result.items()
                    if key not in ("sparse", "first", "second", "scales")}
                metadata[f"model.layers.{layer_idx}.{name}"]["scales"] = {
                    key: value.cpu() for key, value in result["scales"].items()}
                print(f"[module-done] layer={layer_idx} module={name} "
                      f"selected_iter={result['selected_iteration']} "
                      f"seconds={time.monotonic()-module_start:.2f}", flush=True)
                del result, x
            forward_samples()
            inps, outs = outs, inps
            del subset, wrappers, samples
            gc.collect()
            torch.cuda.empty_cache()
            print(f"[layer-done] layer={layer_idx} seconds={time.monotonic()-layer_start:.2f}", flush=True)
    return {"method": "custom dual-branch AWQ-style fake quantization",
            "config": asdict(config), "coordinate_system": "effective_original",
            "scales_already_folded": True, "packed_int4": False,
            "sparse_mask_projection": True, "clipping": False,
            "pair_scale_refresh": "every_refit",
            "pair_candidate_selection": "full_branch_calibration_output_mse",
            "selection": ("relative_frobenius" if args.dual_selection == "frobenius"
                          else "full_branch_calibration_output_mse"),
            "official_reference_commit": "d6e797a42b9ef7778de8ee2352116e0f48a78d61",
            "modules": metadata}


def reload_checkpoint(args, checkpoint_path):
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    model = load_base(args)
    for layer_idx, layer in enumerate(model.model.layers):
        for name, linear in find_layers(layer).items():
            prefix = f"model.layers.{layer_idx}.{name}"
            if prefix + ".sp.weight" not in ckpt["state_dict"]:
                continue
            weights = ckpt["state_dict"]
            sp = weights[prefix + ".sp.weight"].to(args.device)
            first = weights[prefix + ".lr.l1.weight"].to(args.device)
            second = weights[prefix + ".lr.l2.weight"].to(args.device)
            replacement = build_composite(sp, first, second, linear.bias,
                                          semi=ckpt["method"] == "ours")
            _set_submodule(layer, name, replacement)
    model.load_state_dict(ckpt["state_dict"], strict=True)
    del ckpt
    gc.collect()
    return model


def parse_args():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--model", default="/home/lzhang45/Llama-2-7b-hf")
    p.add_argument("--method", choices=["dense", "wanda", "ours", "dual_awq"], required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--save_ckpt", type=Path)
    p.add_argument("--rank_k", type=int, default=32)
    p.add_argument("--sparsity_type", choices=["2:4", "unstructured"], default="2:4")
    p.add_argument("--sparsity_ratio", type=float, default=0.5)
    p.add_argument("--nsamples", type=int, default=128)
    p.add_argument("--seqlen", type=int, default=2048)
    p.add_argument("--ppl_seqlen", type=int, default=128)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--alt_iters", type=int, default=200)
    p.add_argument("--alt_tol", type=float, default=1e-8)
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--attn_implementation", choices=["eager", "sdpa"], default="sdpa")
    p.add_argument("--w_bits", type=int, default=4)
    p.add_argument("--group_size", type=int, default=128)
    p.add_argument("--scale_grid", type=int, default=20)
    p.add_argument("--sparse_scale_refresh", type=int, default=10)
    p.add_argument("--awq_tokens", type=int, default=512)
    p.add_argument("--dual-selection", choices=("output_mse", "frobenius"), default="output_mse",
                   help="Final iterate criterion; pair scale search always uses output MSE")
    args = p.parse_args()
    if args.method in ("ours", "dual_awq") and (args.rank_k <= 0 or args.sparsity_type != "2:4"):
        p.error("ours and dual_awq require positive rank and 2:4")
    if args.save_ckpt and args.method in ("dense", "wanda"):
        p.error("The requested baseline runs retain logs only")
    args.use_variant = False
    args.disable_semi_structured = False
    args.save = str(args.output)
    args.prune_method = {"ours": "lr_wanda_iter_alllinear", "dual_awq": "lr_wanda_iter_dual_awq"}.get(args.method, args.method)
    return args


@torch.no_grad()
def main():
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()}
    manifest.update(started_at=stamp(), torch=torch.__version__, cuda=torch.version.cuda,
                    gpu=torch.cuda.get_device_name(), argv=sys.argv,
                    base_revision="01c7f73d771dfac7d292323805ebc428287df4f9",
                    repository_base_revision="941e2cf1d9d73ae78beaa5e126070e7d6a7608df")
    manifest["source_sha256"] = {
        name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        for name in ("lib/prune.py", "lib/dual_awq.py", "lib/data.py", "lib/eval.py",
                     "scripts/run_llama2_ppl_experiment.py")}
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2), flush=True)
    torch.set_num_threads(4)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    model = load_base(args)
    tokenizer = AutoTokenizer.from_pretrained(args.model, use_fast=False, local_files_only=True)
    start = time.monotonic()
    quantization = None
    if args.method == "wanda":
        n, m = (2, 4) if args.sparsity_type == "2:4" else (0, 0)
        prune_wanda(args, model, tokenizer, torch.device(args.device), prune_n=n, prune_m=m)
    elif args.method == "ours":
        prune_wanda_lowrank_alt_alllinear(args, model, tokenizer, torch.device(args.device), prune_n=2, prune_m=4)
    elif args.method == "dual_awq":
        quantization = prune_dual(args, model, tokenizer)
        quantization["structure_audit"] = audit_dual_model(model, args.rank_k)
    prune_seconds = time.monotonic() - start
    sparsity = check_sparsity(model)
    roundtrip = None
    if args.save_ckpt:
        args.save_ckpt.mkdir(parents=True, exist_ok=True)
        path = args.save_ckpt / "rebuildable_ckpt.pt"
        probe = tokenizer("The purpose of this experiment is to measure perplexity.", return_tensors="pt").input_ids.to(args.device)
        expected = model(probe).logits.cpu()
        ckpt = {"base_model": args.model, "method": args.method, "prune_method": args.prune_method,
                "rank_k": args.rank_k, "sparsity_type": args.sparsity_type,
                "sparsity_ratio": args.sparsity_ratio, "meta": manifest,
                "quantization": quantization,
                "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()}}
        torch.save(ckpt, str(path) + ".tmp")
        os.replace(str(path) + ".tmp", path)
        tokenizer.save_pretrained(args.save_ckpt)
        model.config.save_pretrained(args.save_ckpt)
        del ckpt, model, quantization
        gc.collect()
        torch.cuda.empty_cache()
        model = reload_checkpoint(args, path)
        actual = model(probe).logits.cpu()
        roundtrip = float((expected.float() - actual.float()).abs().max())
        if not torch.equal(expected, actual):
            raise RuntimeError(f"Checkpoint roundtrip changed logits: max_abs={roundtrip}")
        print(f"[checkpoint] strict reload and identical logits verified: {path}", flush=True)
    start = time.monotonic()
    ppl = eval_ppl(args, model, tokenizer, torch.device(args.device))
    metrics = {"method": args.method, "rank": args.rank_k if args.method in ("ours", "dual_awq") else None,
               "sparsity_type": args.sparsity_type, "actual_sparsity": sparsity,
               "dataset": "wikitext-2-raw-v1/test", "ppl_seqlen": args.ppl_seqlen,
               "ppl": ppl, "prune_seconds": prune_seconds, "eval_seconds": time.monotonic()-start,
               "checkpoint": str(args.save_ckpt) if args.save_ckpt else None,
               "checkpoint_roundtrip_max_abs_logit_diff": roundtrip, "finished_at": stamp()}
    (args.output / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    print("[result] " + json.dumps(metrics), flush=True)


if __name__ == "__main__":
    main()
