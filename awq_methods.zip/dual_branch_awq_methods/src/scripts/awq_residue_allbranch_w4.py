#!/usr/bin/env python3
"""AWQ-style fake W4 quantization of every Residue Pruning branch.

Configuration for a rank-32 checkpoint:

* fixed-mask sparse S: asymmetric W4-g128;
* low-rank input factor A: asymmetric W4-g128; and
* low-rank output factor B: asymmetric W4-g32.

The implementation uses the official llm-awq fake quantizer, PileVal
calibration, activation-aware 20-point scale search, and clipping objective.
It adds the minimum topology-aware operations needed for y=Sx+B(Ax): external
channel scaling acts on S and A together, and an internal rank-channel gauge
search jointly quantizes A and B using the complete Residue output error.

This is an accuracy-only fake-quantization experiment.  It does not implement
or claim a packed INT4 sparse/low-rank kernel.
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import random
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.awq_residue_sparse_w4 import (  # noqa: E402
    PROJECTION_NAMES,
    apply_clip,
    apply_norm_to_residue_scale,
    apply_residue_to_residue_scale,
    auto_clip_sparse_layer,
    capture_first_layer_input,
    capture_projection_inputs,
    count_2_4,
    import_official_awq,
    mask_preserving_awq_quant,
    module_equivalence,
    move_tree,
    require_residue,
    tensor_output,
)
from scripts.eval_int4_weightonly_ppl_cmqa import _load_residue_model  # noqa: E402


@dataclass
class BranchQuantStats:
    layer: int
    module: str
    branch: str
    shape: Tuple[int, int]
    group_size: int
    numel: int
    mse: float
    max_abs_error: float
    rounded_active_to_zero_before_projection: int = 0
    mask_equal: Any = None
    groups_2_4: int = 0
    violations_2_4: int = 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--awq_repo", type=Path, default=Path("/mnt/llm-awq"))
    parser.add_argument("--output_checkpoint", type=Path)
    parser.add_argument("--output_json", type=Path, required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--dtype", default="fp16", choices=("fp16", "bf16"))
    parser.add_argument("--w_bit", type=int, default=4)
    parser.add_argument("--sparse_group_size", type=int, default=128)
    parser.add_argument("--a_group_size", type=int, default=128)
    parser.add_argument("--b_group_size", type=int, default=32)
    parser.add_argument("--n_samples", type=int, default=128)
    parser.add_argument("--seqlen", type=int, default=512)
    parser.add_argument("--external_scale_grid", type=int, default=20)
    parser.add_argument("--rank_scale_grid", type=int, default=20)
    parser.add_argument("--clip_grid", type=int, default=20)
    parser.add_argument("--clip_max_shrink", type=float, default=0.5)
    parser.add_argument("--clip_sample_tokens", type=int, default=512)
    parser.add_argument("--max_layers", type=int, default=0)
    parser.add_argument("--skip_clip", action="store_true")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


@torch.no_grad()
def dense_awq_quant(
    weight: torch.Tensor,
    official_pseudo_quantize_tensor,
    *,
    w_bit: int,
    group_size: int,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if weight.ndim != 2:
        raise ValueError(f"Expected a matrix, got {tuple(weight.shape)}")
    if group_size <= 0 or weight.shape[1] % group_size:
        raise ValueError(
            f"Invalid group size {group_size} for weight {tuple(weight.shape)}"
        )
    quantized, scales, zeros = official_pseudo_quantize_tensor(
        weight,
        n_bit=w_bit,
        zero_point=True,
        q_group_size=group_size,
        get_scale_zp=True,
    )
    return quantized, scales, zeros


@torch.no_grad()
def prebalance_factors(module, probe: torch.Tensor) -> Dict[str, float]:
    """Exact gauge initialization that equalizes A-row and B-column maxima."""

    reference = module(probe).detach().float()
    a = module.lr.l1.weight
    b = module.lr.l2.weight
    amax = a.float().abs().amax(dim=1).clamp_min(1e-8)
    bmax = b.float().abs().amax(dim=0).clamp_min(1e-8)
    scale = torch.sqrt(amax / bmax).clamp(1e-4, 1e4).to(a)
    a.div_(scale.reshape(-1, 1))
    b.mul_(scale.reshape(1, -1).to(b))
    current = module(probe).float()
    difference = current - reference
    return {
        "scale_min": float(scale.min().item()),
        "scale_max": float(scale.max().item()),
        "max_abs": float(difference.abs().max().item()),
        "relative_mse": float(
            difference.pow(2).sum().item()
            / max(reference.pow(2).sum().item(), 1e-30)
        ),
    }


@torch.no_grad()
def search_external_allbranch_scale(
    inspect_module: nn.Module,
    target_modules: Sequence,
    input_feat: torch.Tensor,
    kwargs: Dict[str, Any],
    official_pseudo_quantize_tensor,
    args: argparse.Namespace,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """AWQ input-channel search with S, A, and B all fake-quantized."""

    device = next(inspect_module.parameters()).device
    x = input_feat.to(device)
    kwargs = move_tree(kwargs, device)
    original_output = tensor_output(inspect_module(x, **kwargs)).detach()
    x_max = x.abs().reshape(-1, x.shape[-1]).mean(dim=0)
    originals = [
        (
            module.sp.weight.detach().clone(),
            module.lr.l1.weight.detach().clone(),
            module.lr.l2.weight.detach().clone(),
        )
        for module in target_modules
    ]
    quantized_b = [
        dense_awq_quant(
            b,
            official_pseudo_quantize_tensor,
            w_bit=args.w_bit,
            group_size=args.b_group_size,
        )[0]
        for _, _, b in originals
    ]

    best_error = math.inf
    best_ratio = -1.0
    best_scales = None
    history: List[float] = []
    sparse_projection_history: List[int] = []
    try:
        for grid_idx in range(args.external_scale_grid):
            ratio = grid_idx / args.external_scale_grid
            scales = x_max.pow(ratio).clamp(min=1e-4).reshape(-1)
            scales = scales / torch.sqrt(scales.max() * scales.min())
            projected = 0
            for module, (s, a, _b), qb in zip(target_modules, originals, quantized_b):
                input_scale = scales.reshape(1, -1).to(s)
                qs, corrected, _, _ = mask_preserving_awq_quant(
                    s * input_scale,
                    official_pseudo_quantize_tensor,
                    w_bit=args.w_bit,
                    group_size=args.sparse_group_size,
                )
                qa, _, _ = dense_awq_quant(
                    a * input_scale.to(a),
                    official_pseudo_quantize_tensor,
                    w_bit=args.w_bit,
                    group_size=args.a_group_size,
                )
                projected += corrected
                module.sp.weight.data.copy_(qs / input_scale)
                module.lr.l1.weight.data.copy_(qa / input_scale.to(qa))
                module.lr.l2.weight.data.copy_(qb)

            candidate = tensor_output(inspect_module(x, **kwargs))
            error = float(
                (candidate.float() - original_output.float()).pow(2).mean().item()
            )
            history.append(error)
            sparse_projection_history.append(projected)
            if error < best_error:
                best_error = error
                best_ratio = ratio
                best_scales = scales.detach().clone()
            for module, (s, a, b) in zip(target_modules, originals):
                module.sp.weight.data.copy_(s)
                module.lr.l1.weight.data.copy_(a)
                module.lr.l2.weight.data.copy_(b)
            del candidate
    finally:
        for module, (s, a, b) in zip(target_modules, originals):
            module.sp.weight.data.copy_(s)
            module.lr.l1.weight.data.copy_(a)
            module.lr.l2.weight.data.copy_(b)

    if best_scales is None:
        raise RuntimeError(f"External AWQ search failed: {history}")
    return best_scales, {
        "best_ratio": best_ratio,
        "best_error": best_error,
        "history": history,
        "sparse_projection_history": sparse_projection_history,
    }


@torch.no_grad()
def search_rank_gauge_scale(
    module,
    input_feat: torch.Tensor,
    official_pseudo_quantize_tensor,
    args: argparse.Namespace,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """Search A<-D^-1 A, B<-BD using the complete quantized Residue output."""

    device = module.sp.weight.device
    x = input_feat.to(device)
    s = module.sp.weight.detach()
    a = module.lr.l1.weight.detach()
    b = module.lr.l2.weight.detach()
    original_output = module(x).detach()
    qs, sparse_projected, _, _ = mask_preserving_awq_quant(
        s,
        official_pseudo_quantize_tensor,
        w_bit=args.w_bit,
        group_size=args.sparse_group_size,
    )
    sparse_output = F.linear(x, qs)
    hidden = F.linear(x, a)
    hidden_scale = hidden.abs().reshape(-1, hidden.shape[-1]).mean(dim=0)

    best_error = math.inf
    best_ratio = -1.0
    best_scales = None
    history: List[float] = []
    for grid_idx in range(args.rank_scale_grid):
        ratio = grid_idx / args.rank_scale_grid
        scales = hidden_scale.pow(ratio).clamp(min=1e-4).reshape(-1)
        scales = scales / torch.sqrt(scales.max() * scales.min())
        qa, _, _ = dense_awq_quant(
            a / scales.reshape(-1, 1).to(a),
            official_pseudo_quantize_tensor,
            w_bit=args.w_bit,
            group_size=args.a_group_size,
        )
        qb, _, _ = dense_awq_quant(
            b * scales.reshape(1, -1).to(b),
            official_pseudo_quantize_tensor,
            w_bit=args.w_bit,
            group_size=args.b_group_size,
        )
        candidate = sparse_output + F.linear(F.linear(x, qa), qb)
        if module.bias is not None:
            candidate = candidate + module.bias
        error = float(
            (candidate.float() - original_output.float()).pow(2).mean().item()
        )
        history.append(error)
        if error < best_error:
            best_error = error
            best_ratio = ratio
            best_scales = scales.detach().clone()
        del qa, qb, candidate
    if best_scales is None:
        raise RuntimeError(f"Rank gauge AWQ search failed: {history}")
    return best_scales, {
        "best_ratio": best_ratio,
        "best_error": best_error,
        "history": history,
        "sparse_projected": sparse_projected,
    }


@torch.no_grad()
def apply_rank_gauge_scale(module, scales: torch.Tensor) -> None:
    module.lr.l1.weight.div_(scales.to(module.lr.l1.weight).reshape(-1, 1))
    module.lr.l2.weight.mul_(scales.to(module.lr.l2.weight).reshape(1, -1))


@torch.no_grad()
def rank_gauge_equivalence(module, feature: torch.Tensor, scales: torch.Tensor) -> Dict[str, float]:
    probe = feature.reshape(-1, feature.shape[-1])[:32].to(module.sp.weight.device)
    reference = module(probe).detach().float()
    apply_rank_gauge_scale(module, scales)
    current = module(probe).float()
    difference = current - reference
    return {
        "max_abs": float(difference.abs().max().item()),
        "relative_mse": float(
            difference.pow(2).sum().item()
            / max(reference.pow(2).sum().item(), 1e-30)
        ),
    }


@torch.no_grad()
def auto_clip_dense_layer(
    weight: torch.Tensor,
    input_feat: torch.Tensor,
    official_pseudo_quantize_tensor,
    *,
    w_bit: int,
    group_size: int,
    n_grid: int,
    max_shrink: float,
    n_sample_token: int,
) -> torch.Tensor:
    """Official AWQ clipping objective with support for rank-32 A matrices."""

    features = input_feat.reshape(-1, input_feat.shape[-1])
    features = features.reshape(1, features.shape[0], -1, group_size)
    stride = max(1, features.shape[1] // n_sample_token)
    features = features[:, 0::stride]
    grouped_weight = weight.reshape(weight.shape[0], 1, -1, group_size)
    if weight.shape[0] % 256 == 0:
        output_batch = 256
    elif weight.shape[0] % 64 == 0:
        output_batch = 64
    else:
        output_batch = weight.shape[0]

    best_values: List[torch.Tensor] = []
    for batch_idx in range(weight.shape[0] // output_batch):
        current = grouped_weight[
            batch_idx * output_batch : (batch_idx + 1) * output_batch
        ]
        original_max = current.abs().amax(dim=-1, keepdim=True)
        best_max = original_max.clone()
        min_errors = torch.full_like(original_max, float("inf"))
        device_features = features.to(current.device)
        original_output = (device_features * current).sum(dim=-1)
        for shrink_idx in range(int(max_shrink * n_grid)):
            max_value = original_max * (1 - shrink_idx / n_grid)
            clipped = torch.clamp(current, -max_value, max_value)
            flat = clipped.reshape(-1, weight.shape[1])
            quantized, _, _ = dense_awq_quant(
                flat,
                official_pseudo_quantize_tensor,
                w_bit=w_bit,
                group_size=group_size,
            )
            quantized = quantized.reshape_as(current)
            candidate_output = (device_features * quantized).sum(dim=-1)
            errors = (
                (candidate_output - original_output)
                .pow(2)
                .mean(dim=1)
                .reshape_as(min_errors)
            )
            better = errors < min_errors
            min_errors[better] = errors[better]
            best_max[better] = max_value[better]
            del clipped, flat, quantized, candidate_output, errors
        best_values.append(best_max)
        del device_features, original_output, min_errors
    return torch.cat(best_values, dim=0).squeeze(1)


def process_layer(
    layer_idx: int,
    layer: nn.Module,
    features: Dict[str, torch.Tensor],
    layer_kwargs: Dict[str, Any],
    official_pseudo_quantize_tensor,
    args: argparse.Namespace,
) -> Tuple[Dict[str, Any], List[BranchQuantStats]]:
    started = time.time()
    modules = {
        name: require_residue(layer.get_submodule(name), name)
        for name in PROJECTION_NAMES
    }
    result: Dict[str, Any] = {
        "layer": layer_idx,
        "prebalance": {},
        "external_scales": {},
        "rank_scales": {},
        "clips": {},
    }

    for name, module in modules.items():
        feature_name = (
            "self_attn.q_proj"
            if name in ("self_attn.q_proj", "self_attn.k_proj", "self_attn.v_proj")
            else "mlp.gate_proj"
            if name in ("mlp.gate_proj", "mlp.up_proj")
            else name
        )
        probe = features[feature_name].reshape(-1, features[feature_name].shape[-1])[:32]
        probe = probe.to(module.sp.weight.device)
        result["prebalance"][name] = prebalance_factors(module, probe)

    groups = [
        (
            "attention_qkv",
            layer.self_attn,
            [modules["self_attn.q_proj"], modules["self_attn.k_proj"], modules["self_attn.v_proj"]],
            features["self_attn.q_proj"],
            layer_kwargs,
            layer.input_layernorm,
            None,
        ),
        (
            "attention_output",
            modules["self_attn.o_proj"],
            [modules["self_attn.o_proj"]],
            features["self_attn.o_proj"],
            {},
            None,
            modules["self_attn.v_proj"],
        ),
        (
            "mlp_gate_up",
            layer.mlp,
            [modules["mlp.gate_proj"], modules["mlp.up_proj"]],
            features["mlp.gate_proj"],
            {},
            layer.post_attention_layernorm,
            None,
        ),
        (
            "mlp_down",
            modules["mlp.down_proj"],
            [modules["mlp.down_proj"]],
            features["mlp.down_proj"],
            {},
            None,
            modules["mlp.up_proj"],
        ),
    ]

    scaled_features: Dict[str, torch.Tensor] = {}
    for group_name, inspect_module, targets, feature, kwargs, norm, previous in groups:
        scales, search = search_external_allbranch_scale(
            inspect_module,
            targets,
            feature,
            kwargs,
            official_pseudo_quantize_tensor,
            args,
        )
        probe = feature.reshape(-1, feature.shape[-1])[:32].to(targets[0].sp.weight.device)
        before = [target(probe).detach().cpu() for target in targets]
        if norm is not None:
            apply_norm_to_residue_scale(norm, targets, scales)
        else:
            apply_residue_to_residue_scale(previous, targets[0], scales)
        after_probe = probe / scales.to(probe).reshape(1, -1)
        equivalence = module_equivalence(targets, probe, after_probe, before)
        scale_shape = (1,) * (feature.ndim - 1) + (-1,)
        scaled = feature / scales.cpu().to(feature).reshape(scale_shape)
        if group_name == "attention_qkv":
            for name in ("self_attn.q_proj", "self_attn.k_proj", "self_attn.v_proj"):
                scaled_features[name] = scaled
        elif group_name == "attention_output":
            scaled_features["self_attn.o_proj"] = scaled
        elif group_name == "mlp_gate_up":
            for name in ("mlp.gate_proj", "mlp.up_proj"):
                scaled_features[name] = scaled
        else:
            scaled_features["mlp.down_proj"] = scaled
        result["external_scales"][group_name] = {
            **search,
            "min": float(scales.min().item()),
            "max": float(scales.max().item()),
            "equivalence": equivalence,
        }
        print(
            f"[layer {layer_idx:02d}] external {group_name}: "
            f"ratio={search['best_ratio']:.2f} mse={search['best_error']:.6e} "
            f"equiv={equivalence['relative_mse']:.3e}",
            flush=True,
        )

    for name, module in modules.items():
        scales, search = search_rank_gauge_scale(
            module,
            scaled_features[name],
            official_pseudo_quantize_tensor,
            args,
        )
        equivalence = rank_gauge_equivalence(module, scaled_features[name], scales)
        result["rank_scales"][name] = {
            **search,
            "min": float(scales.min().item()),
            "max": float(scales.max().item()),
            "equivalence": equivalence,
        }
        print(
            f"[layer {layer_idx:02d}] rank {name}: "
            f"ratio={search['best_ratio']:.2f} mse={search['best_error']:.6e} "
            f"equiv={equivalence['relative_mse']:.3e}",
            flush=True,
        )

    if not args.skip_clip:
        for name, module in modules.items():
            if any(token in name for token in ("q_", "k_", "query", "key", "Wqkv")):
                result["clips"][name] = {"skipped": True, "reason": "official_qk_skip"}
                continue
            clip_started = time.time()
            x = scaled_features[name].to(module.sp.weight.device)
            sparse_max = auto_clip_sparse_layer(
                module.sp.weight,
                x,
                official_pseudo_quantize_tensor,
                w_bit=args.w_bit,
                group_size=args.sparse_group_size,
                n_grid=args.clip_grid,
                max_shrink=args.clip_max_shrink,
                n_sample_token=args.clip_sample_tokens,
            )
            apply_clip(module.sp.weight, sparse_max)
            a_max = auto_clip_dense_layer(
                module.lr.l1.weight,
                x,
                official_pseudo_quantize_tensor,
                w_bit=args.w_bit,
                group_size=args.a_group_size,
                n_grid=args.clip_grid,
                max_shrink=args.clip_max_shrink,
                n_sample_token=args.clip_sample_tokens,
            )
            apply_clip(module.lr.l1.weight, a_max)
            qa, _, _ = dense_awq_quant(
                module.lr.l1.weight,
                official_pseudo_quantize_tensor,
                w_bit=args.w_bit,
                group_size=args.a_group_size,
            )
            quantized_hidden = F.linear(x, qa)
            b_max = auto_clip_dense_layer(
                module.lr.l2.weight,
                quantized_hidden,
                official_pseudo_quantize_tensor,
                w_bit=args.w_bit,
                group_size=args.b_group_size,
                n_grid=args.clip_grid,
                max_shrink=args.clip_max_shrink,
                n_sample_token=args.clip_sample_tokens,
            )
            apply_clip(module.lr.l2.weight, b_max)
            module.sp._weight_ss = None
            result["clips"][name] = {
                "skipped": False,
                "sparse_max_min": float(sparse_max.min().item()),
                "sparse_max_max": float(sparse_max.max().item()),
                "a_max_min": float(a_max.min().item()),
                "a_max_max": float(a_max.max().item()),
                "b_max_min": float(b_max.min().item()),
                "b_max_max": float(b_max.max().item()),
                "b_activation": "Q(A)X",
                "seconds": time.time() - clip_started,
            }
            print(
                f"[layer {layer_idx:02d}] clip all {name}: "
                f"seconds={time.time() - clip_started:.1f}",
                flush=True,
            )
            del x, sparse_max, a_max, qa, quantized_hidden, b_max

    stats: List[BranchQuantStats] = []
    for name, module in modules.items():
        sparse_original = module.sp.weight.detach().clone()
        sparse_mask = sparse_original.eq(0)
        qs, corrected, _, _ = mask_preserving_awq_quant(
            sparse_original,
            official_pseudo_quantize_tensor,
            w_bit=args.w_bit,
            group_size=args.sparse_group_size,
        )
        module.sp.weight.data.copy_(qs)
        module.sp._weight_ss = None
        groups_2_4, violations = count_2_4(module.sp.weight)
        stats.append(
            BranchQuantStats(
                layer=layer_idx,
                module=name,
                branch="S",
                shape=tuple(sparse_original.shape),
                group_size=args.sparse_group_size,
                numel=sparse_original.numel(),
                mse=float((sparse_original.float() - qs.float()).pow(2).mean().item()),
                max_abs_error=float((sparse_original.float() - qs.float()).abs().max().item()),
                rounded_active_to_zero_before_projection=corrected,
                mask_equal=bool(torch.equal(sparse_mask, qs.eq(0))),
                groups_2_4=groups_2_4,
                violations_2_4=violations,
            )
        )

        for branch, weight, group_size in (
            ("A", module.lr.l1.weight, args.a_group_size),
            ("B", module.lr.l2.weight, args.b_group_size),
        ):
            original = weight.detach().clone()
            quantized, _, _ = dense_awq_quant(
                original,
                official_pseudo_quantize_tensor,
                w_bit=args.w_bit,
                group_size=group_size,
            )
            weight.data.copy_(quantized)
            stats.append(
                BranchQuantStats(
                    layer=layer_idx,
                    module=name,
                    branch=branch,
                    shape=tuple(original.shape),
                    group_size=group_size,
                    numel=original.numel(),
                    mse=float((original.float() - quantized.float()).pow(2).mean().item()),
                    max_abs_error=float((original.float() - quantized.float()).abs().max().item()),
                )
            )
            del original, quantized
        print(
            f"[layer {layer_idx:02d}] quant {name}: "
            f"S-mask={stats[-3].mask_equal} violations={violations} "
            f"projected={corrected} A=W4G{args.a_group_size} B=W4G{args.b_group_size}",
            flush=True,
        )
        del sparse_original, sparse_mask, qs

    result["seconds"] = time.time() - started
    return result, stats


def main() -> None:
    args = parse_args()
    if args.w_bit != 4:
        raise ValueError("This experiment is defined as W4")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    device = torch.device(args.device)
    seed_everything(args.seed)
    official_quantize, get_calib_dataset, awq_commit = import_official_awq(args.awq_repo)
    started = time.time()
    print(f"[awq] repo={args.awq_repo} commit={awq_commit}", flush=True)
    print(
        f"[config] S=W4G{args.sparse_group_size} A=W4G{args.a_group_size} "
        f"B=W4G{args.b_group_size} samples={args.n_samples} seqlen={args.seqlen}",
        flush=True,
    )

    model, tokenizer, source_checkpoint = _load_residue_model(
        args.model, args.checkpoint, args.dtype
    )
    model.eval()
    model.config.use_cache = False
    source_metadata = {
        key: value for key, value in source_checkpoint.items() if key != "state_dict"
    }
    del source_checkpoint
    gc.collect()

    ranks = set()
    initial_groups = 0
    initial_violations = 0
    for layer in model.model.layers:
        for name in PROJECTION_NAMES:
            module = require_residue(layer.get_submodule(name), name)
            ranks.add(int(module.lr.rank))
            if module.sp.weight.shape[1] % args.sparse_group_size:
                raise ValueError(f"{name}: S input not divisible by group size")
            if module.lr.l1.weight.shape[1] % args.a_group_size:
                raise ValueError(f"{name}: A input not divisible by group size")
            if module.lr.l2.weight.shape[1] % args.b_group_size:
                raise ValueError(f"{name}: B input not divisible by group size")
            groups, violations = count_2_4(module.sp.weight)
            initial_groups += groups
            initial_violations += violations
    if len(ranks) != 1 or not ranks.issubset({32, 128}):
        raise ValueError(f"Expected uniform rank 32 or 128, got {sorted(ranks)}")
    if initial_violations:
        raise ValueError(f"Source checkpoint violates 2:4: {initial_violations}")

    calibration = get_calib_dataset(
        data="pileval",
        tokenizer=tokenizer,
        n_samples=args.n_samples,
        block_size=args.seqlen,
    )
    if not calibration:
        raise RuntimeError("PileVal produced no calibration blocks")
    samples = torch.cat(calibration, dim=0)
    print(f"[calibration] token_blocks={tuple(samples.shape)}", flush=True)
    layer_input, layer_kwargs = capture_first_layer_input(model, samples, device)
    del samples, calibration
    gc.collect()
    torch.cuda.empty_cache()

    total_layers = len(model.model.layers)
    layers_to_process = total_layers if args.max_layers <= 0 else min(args.max_layers, total_layers)
    layer_results: List[Dict[str, Any]] = []
    quant_stats: List[BranchQuantStats] = []
    for layer_idx in range(layers_to_process):
        layer_started = time.time()
        layer = model.model.layers[layer_idx].to(device)
        layer_input = layer_input.to(device)
        next_input, features = capture_projection_inputs(
            layer, layer_input, move_tree(layer_kwargs, device)
        )
        result, stats = process_layer(
            layer_idx,
            layer,
            features,
            move_tree(layer_kwargs, device),
            official_quantize,
            args,
        )
        layer_results.append(result)
        quant_stats.extend(stats)
        model.model.layers[layer_idx] = layer.cpu()
        layer_input = next_input
        del layer, next_input, features
        gc.collect()
        torch.cuda.empty_cache()
        elapsed = time.time() - started
        eta = elapsed / (layer_idx + 1) * (layers_to_process - layer_idx - 1)
        print(
            f"[progress] {layer_idx + 1}/{layers_to_process} "
            f"layer_seconds={time.time() - layer_started:.1f} "
            f"elapsed={elapsed / 60:.1f}m eta={eta / 60:.1f}m",
            flush=True,
        )

    sparse_stats = [stat for stat in quant_stats if stat.branch == "S"]
    mask_equal = all(stat.mask_equal is True for stat in sparse_stats)
    final_groups = sum(stat.groups_2_4 for stat in sparse_stats)
    final_violations = sum(stat.violations_2_4 for stat in sparse_stats)
    report = {
        "experiment": f"AWQ-style all-branch W4 Residue 2:4+r{next(iter(ranks))}",
        "rank": next(iter(ranks)),
        "accuracy_only_fake_quantization": True,
        "real_int4_kernel": False,
        "model": args.model,
        "source_checkpoint": str(args.checkpoint),
        "output_checkpoint": str(args.output_checkpoint) if args.output_checkpoint else None,
        "awq_repo": str(args.awq_repo),
        "awq_commit": awq_commit,
        "quantization": {
            "S": f"asymmetric W4G{args.sparse_group_size}, fixed 2:4 mask",
            "A": f"asymmetric W4G{args.a_group_size}",
            "B": f"asymmetric W4G{args.b_group_size}",
            "zero_point": True,
        },
        "algorithm": {
            "calibration": "official PileVal shuffle seed 42",
            "external_activation_aware_scale_search": True,
            "internal_rank_gauge_scale_search": True,
            "rank_search_objective": "full Q(S)X + Q(B)Q(A)X output MSE",
            "clipping": not args.skip_clip,
            "B_clipping_activation": "Q(A)X",
        },
        "config": {
            **{
                key: value
                for key, value in vars(args).items()
                if key not in ("checkpoint", "awq_repo", "output_checkpoint", "output_json")
            },
            "checkpoint": str(args.checkpoint),
            "awq_repo": str(args.awq_repo),
            "output_checkpoint": str(args.output_checkpoint) if args.output_checkpoint else None,
            "output_json": str(args.output_json),
        },
        "input_mask": {"groups": initial_groups, "violations": initial_violations},
        "output_mask_processed_layers": {
            "groups": final_groups,
            "violations": final_violations,
            "all_masks_equal": mask_equal,
        },
        "layers_processed": layers_to_process,
        "layers_total": total_layers,
        "quantized_tensors": len(quant_stats),
        "layer_results": layer_results,
        "quantization_stats": [asdict(stat) for stat in quant_stats],
        "seconds_before_checkpoint_save": time.time() - started,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(report, indent=2) + "\n")

    if args.output_checkpoint is not None:
        if layers_to_process != total_layers:
            raise ValueError("Refusing to save a partial checkpoint")
        if not mask_equal or final_violations:
            raise RuntimeError("Refusing to save a checkpoint with a broken sparse mask")
        args.output_checkpoint.parent.mkdir(parents=True, exist_ok=True)
        payload = dict(source_metadata)
        payload["state_dict"] = model.state_dict()
        payload["quantization"] = {
            "method": "AWQ-style all-branch fake W4",
            "S": f"W4G{args.sparse_group_size} fixed 2:4 mask",
            "A": f"W4G{args.a_group_size}",
            "B": f"W4G{args.b_group_size}",
            "zero_point": True,
            "fake_quantization": True,
            "awq_commit": awq_commit,
            "report": str(args.output_json),
        }
        torch.save(payload, args.output_checkpoint)
        print(f"[saved] {args.output_checkpoint}", flush=True)
    print(
        f"[done] layers={layers_to_process}/{total_layers} tensors={len(quant_stats)} "
        f"mask_equal={mask_equal} violations={final_violations}/{final_groups} "
        f"seconds={time.time() - started:.1f}",
        flush=True,
    )


if __name__ == "__main__":
    main()
