#!/usr/bin/env python3
"""Serial, explicit entry points for the two archived dual-branch methods."""
import argparse
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile

BUNDLE = Path(__file__).resolve().parent
SRC = BUNDLE / 'src'

def stamp():
    return datetime.now(timezone.utc).isoformat()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('method', choices=['prepare_fp16', 'posthoc_allbranch', 'inloop_frobenius'])
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--ranks', nargs='+', type=int, choices=[32, 128], default=[32, 128])
    p.add_argument('--output-root', type=Path, default=BUNDLE / 'runs')
    p.add_argument('--fp16-root', type=Path,
                   help='Contains ours_r32/rebuildable_ckpt.pt and ours_r128/rebuildable_ckpt.pt')
    p.add_argument('--awq-repo', type=Path, default=BUNDLE / 'third_party/llm-awq')
    p.add_argument('--gpu', default='0', help='Single physical CUDA device index')
    p.add_argument('--dry-run', action='store_true', help='Print commands; do not load or run models')
    args = p.parse_args()
    if len(args.ranks) != len(set(args.ranks)):
        p.error('Ranks must not be repeated')
    if not args.gpu.isdigit():
        p.error('--gpu must be one physical device index')
    model = args.model.resolve()
    output = args.output_root.resolve()
    fp16 = (args.fp16_root or output / 'prepare_fp16').resolve()
    awq = args.awq_repo.resolve()
    jobs = []
    for rank in args.ranks:
        tag = f'ours_r{rank}' if args.method == 'prepare_fp16' else f'r{rank}'
        dest = output / args.method / tag
        checkpoint = dest / 'rebuildable_ckpt.pt'
        metrics = dest / 'metrics'
        common = [sys.executable, '-u']
        if args.method == 'posthoc_allbranch':
            source = fp16 / f'ours_r{rank}/rebuildable_ckpt.pt'
            if not args.dry_run and not source.is_file():
                p.error(f'Missing FP16 checkpoint: {source}; use --fp16-root or prepare_fp16')
            commands = [
                ('quantize', common + ['scripts/awq_residue_allbranch_w4.py',
                 '--model', str(model), '--checkpoint', str(source), '--awq_repo', str(awq),
                 '--output_checkpoint', str(checkpoint), '--output_json', str(metrics / 'quant_report.json'),
                 '--device', 'cuda:0', '--dtype', 'fp16', '--w_bit', '4',
                 '--sparse_group_size', '128', '--a_group_size', '128', '--b_group_size', '32',
                 '--n_samples', '128', '--seqlen', '512', '--seed', '42']),
                ('ppl', common + ['scripts/eval_posthoc_awq_ppl.py', '--model', str(model),
                 '--checkpoint', str(checkpoint), '--rank_k', str(rank), '--output', str(metrics)])]
        else:
            method = 'ours' if args.method == 'prepare_fp16' else 'dual_awq'
            command = common + ['scripts/run_llama2_ppl_experiment.py', '--model', str(model),
                       '--method', method, '--rank_k', str(rank), '--sparsity_type', '2:4',
                       '--sparsity_ratio', '0.5', '--nsamples', '128', '--seqlen', '2048',
                       '--ppl_seqlen', '128', '--seed', '0', '--alt_iters', '200', '--alt_tol', '1e-8',
                       '--attn_implementation', 'sdpa', '--device', 'cuda:0',
                       '--output', str(metrics), '--save_ckpt', str(dest)]
            if method == 'dual_awq':
                command += ['--dual-selection', 'frobenius', '--w_bits', '4', '--group_size', '128',
                            '--scale_grid', '20', '--sparse_scale_refresh', '10', '--awq_tokens', '512']
            commands = [('prune_and_ppl', command)]
        if not args.dry_run and dest.exists():
            p.error(f'Refusing to overwrite existing run directory: {dest}')
        jobs.append((rank, dest, commands))
    if args.dry_run:
        print(f'Working directory: {SRC}')
        for rank, _, commands in jobs:
            for stage, command in commands:
                print(f'[{args.method} rank={rank} {stage}] {shlex.join(command)}')
        return
    if not (model / 'config.json').is_file():
        p.error(f'Model directory is incomplete: {model}')
    environment = dict(os.environ, CUDA_VISIBLE_DEVICES=args.gpu, OMP_NUM_THREADS='4',
                       MKL_NUM_THREADS='4', TOKENIZERS_PARALLELISM='false', MPLBACKEND='Agg',
                       HF_HUB_OFFLINE='0', HF_DATASETS_OFFLINE='0')
    lockfile = Path(tempfile.gettempdir()) / f'wanda_awq_methods_{os.getuid()}_gpu{args.gpu}.lock'
    with lockfile.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for rank, dest, commands in jobs:
            dest.mkdir(parents=True)
            state = {'method': args.method, 'rank': rank, 'status': 'running',
                     'started_at': stamp(), 'stages': []}
            def save():
                (dest / 'run_state.json').write_text(json.dumps(state, indent=2)+'\n')
            save()
            try:
                for stage, command in commands:
                    record = {'stage': stage, 'argv': command, 'started_at': stamp()}
                    state['stages'].append(record)
                    save()
                    print(f'[{stamp()}] rank={rank} {stage}: {dest / (stage + ".log")}', flush=True)
                    with (dest / (stage + '.log')).open('w') as log:
                        process = subprocess.Popen(command, cwd=SRC, env=environment,
                                                   stdout=log, stderr=subprocess.STDOUT)
                        try:
                            code = process.wait()
                        except BaseException:
                            process.terminate()
                            try:
                                process.wait(timeout=30)
                            except subprocess.TimeoutExpired:
                                process.kill()
                                process.wait()
                            raise
                    record.update(exit_code=code, finished_at=stamp())
                    save()
                    if code:
                        raise RuntimeError(f'{stage} failed with exit {code}; see {dest}')
                result = json.loads((dest / 'metrics/metrics.json').read_text())
                state.update(status='complete', ppl=result['ppl'])
                print(f'[{stamp()}] rank={rank} PPL={result["ppl"]}', flush=True)
            except BaseException as error:
                state.update(status='failed', error=str(error))
                raise
            finally:
                state['finished_at'] = stamp()
                save()

if __name__ == '__main__':
    main()
